"""claude CLI 플래그 조립과 기동 자기점검 게이트.

무엇을 하는가
    1. argv 를 만든다. 순서와 구성은 설계 5-1 표 그대로다.
    2. 받은 system/init 이벤트가 그 argv 와 맞는지 검사한다(설계 3-4).

포스처는 두 개다(설계 3-3).
    R (읽기, 기본)  내장 5개 노출 + 내장 읽기 3종과 qgis 읽기 도구 정확명 사전승인
    W (변경 허용)   R + Write/Edit 노출 + 변경 도구 정확명 사전승인
    두 포스처의 `--disallowedTools` 는 **같다**. W 에서도 임의 코드와 SQL 은 열지 않는다.

차단은 세 갈래다(설계 3-3-1, 장부 V28-A14/A15/A16/A17 종결).
    1. 내장 노출 축소 = `--tools`. MCP 에는 무효다.
    2. MCP 노출 제거 = `--disallowedTools`. `--allowedTools` 를 이기고 init.tools 에서
       이름이 사라진다. 그래서 게이트 3이 매 기동 단정이 된다.
    3. 기본 거부 = allowlist 에 없는 프롬프트 유발 도구. MCP 쓰기/읽기, 내장
       Write/Bash 전부 decision_reason_type="mode" 로 거부됐다.
    `--allowedTools` 는 차단하지 않고 사전승인만 한다. R 에서 그것은 안전장치가
    아니라 **기능 장치**다. 비우면 MCP 읽기도 거부된다(A16).

게이트가 왜 사후 차단인가
    입력을 보내기 전에는 init 이 오지 않는다(D06 FAIL). 그래서 spawn 만으로는
    포스처를 확인할 수 없고, 게이트는 첫 턴의 init 에서 돈다. 이 모듈은 판정만
    돌려주고 입력 차단과 재시작은 process/dock 이 한다(S5-1).

설계 정본: docs/1.mvp_design_v1.md 3-3, 3-3-1, 3-4, 5-1, 5-2
"""

import json
import os
import uuid

# 포스처 R 의 내장 도구 노출 목록(설계 3-3). 실측 28개 이름 중에서 골랐고
# `--tools` 가 init.tools 를 그대로 줄이는 것은 D12 PASS 다(S0 ln91).
# ToolSearch 와 Skill 은 빼지 않는다 - 빼면 MCP 스키마 조회와 스킬 경로가 죽는다.
BUILTIN_TOOLS_R = ("Read", "Glob", "Grep", "ToolSearch", "Skill")

# 포스처 W 는 R 에 내장 쓰기 2개만 더한다(설계 3-3). Bash 와 PowerShell 은
# MVP 에서 넣지 않는다 - 임의 셸은 QGIS 독의 범위가 아니다.
BUILTIN_TOOLS_W = BUILTIN_TOOLS_R + ("Write", "Edit")

# 0.1.4 사양 개정(사용자 결정 2026-10-10, 장부 V28-A49).
#
# 내장 읽기 3종을 **양쪽 포스처의 `--allowedTools` 에 사전승인**한다. 0.1.3
# 까지는 이 셋이 `--tools` 로 노출만 돼 있고 어느 포스처의 allowlist 에도
# 없었다. `--allowedTools` 는 차단이 아니라 사전승인이고(설계 3-3-0), 노출만
# 된 도구는 프롬프트를 유발하므로 `--permission-mode dontAsk` 아래에서는
# decision_reason_type="mode" 로 **거부**된다(A16 과 같은 기전).
#
# 실측 배경: 실사용에서 collect 스킬이 실습 패키지 파일을 읽으려 한
# Read/Glob/Grep 호출이 전부 거부돼 스킬이 반복 실패했다(한 세션에서 Glob
# 13회 거부, V28-A49).
#
# 이것은 완화가 아니라 **사양 개정**이다. 변경 범위는 읽기 전용 3개뿐이고,
# Write/Edit 와 위험 MCP 도구의 승인 경로는 그대로다. DISALLOWED_TOOLS 도
# 불변이다. 와일드카드는 쓰지 않는다 - 와일드카드의 실행 권한 부여는 이
# 프로젝트에서 미측이다(V28-A11).
BUILTIN_READ_TOOLS = ("Read", "Glob", "Grep")

# 설계 3-2 결정. 보안 때문이 아니라 게이트 검증 가능성 때문에 명시한다.
# 무지정이면 init 이 default 를 주는데, 그것은 플래그가 조용히 무시된 경우와
# 구분되지 않는다(A07 ln15 대 ln105). W 도 같은 값이다 - 모드는 레버가 아니다.
PERMISSION_MODE = "dontAsk"

# 툴킷 `.mcp.json` 의 서버 키. 도구 이름 접두사가 여기서 나온다(설계 3-3 의
# mcp__qgis__execute_code 와 같은 표기).
QGIS_MCP_SERVER_NAME = "qgis"
MCP_PREFIX = "mcp__%s__" % QGIS_MCP_SERVER_NAME

# 툴킷 `.mcp.json` 과 같은 구성(설계 5-2, F11). 태그 고정이다. 사용자 등록본과
# 버전이 어긋나면 세션이 스스로 degraded 를 보고한 강의 실측이 있어서,
# 플러그인이 자기 설정을 소유한다.
QGIS_MCP_COMMAND = "uvx"
QGIS_MCP_ARGS = (
    "--from",
    "https://github.com/nkarasiak/qgis-mcp/archive/refs/tags/v0.15.0.zip",
    "qgis-mcp-server",
)


def _mcp(names):
    """도구 base 이름들에 mcp__qgis__ 접두를 붙인다."""
    return tuple(MCP_PREFIX + n for n in names)


# 포스처 R 의 사전승인 목록(설계 3-3 "qgis 읽기 도구의 정확한 이름").
# 출처: 툴킷 v2.1.0 이 광고하는 도구 이름. 와일드카드를 쓰지 않는다 -
# 와일드카드는 파싱/등록까지만 확인됐고 실행 권한 부여는 미측이다(장부 V28-A11).
# 분류 기준: QGIS 프로젝트/레이어/디스크 상태를 바꾸지 않고 질의만 하는 것.
# 파일을 쓰는 export_*/render_map/save_*/*_screenshot 은 R 에서 제외했다
# (프로젝트는 안 바뀌어도 디스크에 쓰는 것은 변경이다 - 보수적으로 잡았다).
QGIS_READ_TOOLS = _mcp((
    "ping",
    "diagnose",
    "find_layer",
    "get_active_layer",
    "get_algorithm_help",
    "get_bookmarks",
    "get_canvas_extent",
    "get_canvas_scale",
    "get_edit_status",
    "get_field_statistics",
    "get_layer_crs",
    "get_layer_extent",
    "get_layer_features",
    "get_layer_labeling",
    "get_layer_tree",
    "get_layers",
    "get_layout_info",
    "get_map_themes",
    "get_message_log",
    "get_plugin_info",
    "get_processing_job",
    "get_processing_providers",
    "get_project_info",
    "get_project_variables",
    "get_qgis_info",
    "get_raster_info",
    "get_selection",
    "get_setting",
    "get_unique_values",
    "identify_features",
    "list_checkpoints",
    "list_connection_tables",
    "list_connections",
    "list_layouts",
    "list_plugins",
    "list_processing_algorithms",
    "list_processing_models",
    "list_qgis_instances",
    "sample_raster_values",
    "transform_coordinates",
    "validate_expression",
))

# 포스처 W 가 R 에 더하는 변경 도구(설계 3-3 W 열). 체크포인트 2종을 먼저 두는
# 이유는 설계 3-7 의 완화책(상태 변경 전 create_checkpoint)이 실제로 호출
# 가능해야 하기 때문이다. 임의 코드/SQL 계열은 여기에 없다 - 9장 비범위다.
QGIS_WRITE_TOOLS = _mcp((
    "create_checkpoint",
    "restore_checkpoint",
    "add_vector_layer",
    "add_raster_layer",
    "add_web_layer",
    "add_features",
    "add_field",
    "add_table_join",
    "apply_style_qml",
    "commit_edits",
    "create_layer_group",
    "create_memory_layer",
    "delete_features",
    "delete_field",
    "execute_processing",
    "field_calculator",
    "move_layer_to_group",
    "raster_calculator",
    "remove_layer",
    "rename_field",
    "rollback_edits",
    "save_project",
    "select_features",
    "set_active_layer",
    "set_layer_crs",
    "set_layer_labeling",
    "set_layer_order",
    "set_layer_property",
    "set_layer_style",
    "set_layer_visibility",
    "set_project_crs",
    "set_raster_style",
    "spatial_join",
    "start_editing",
    "undo_edits",
    "update_feature_geometry",
    "update_features",
    "zonal_statistics",
))

# 두 포스처가 공유하는 노출 제거 목록(설계 3-3, 9장). A14 축3 이 이 플래그를
# "거부" 가 아니라 "init.tools 에서 이름 제거" 로 확정했으므로, 게이트 3 에서
# 매 기동 단정할 수 있다. 정확명만 쓴다.
DISALLOWED_TOOLS = _mcp((
    "execute_code",
    "execute_sql",
    "execute_connection_sql",
    "import_layer_to_connection",
))

POSTURE_R = "R"
POSTURE_W = "W"

# 독 프리앰블(설계 6-6 항목 2, 3-7). cwd 자동 탐색에 의존하지 않는 최소 규칙만
# 담는다. 툴킷 리포에 AGENTS.md 가 없으므로(F8) 이것이 유일한 플러그인 소유 지침이다.
DOCK_PREAMBLE = (
    "너는 QGIS 안의 UPWISE Chat 독에서 실행된다. 다음 규칙을 지켜라.\n"
    "1. 사용자에게는 한국어로 답한다.\n"
    "2. 상태를 바꾸는 작업 전에 create_checkpoint 를 먼저 호출한다.\n"
    "3. QGIS MCP 도구는 한 번에 하나만 호출한다.\n"
    "4. 스킬을 쓸 때는 스킬이 요구하는 첫 줄 마커를 그대로 남긴다.\n"
    "5. 임의 코드 실행과 SQL 실행은 하지 않는다.\n"
)

# 상승 재전송 때 원래 요청 앞에 붙이는 한 줄(설계 3-5 항목 3). 재개 세션에는
# 직전 거부 대화가 남아 있으므로(D01) 같은 요청을 그대로 다시 보내면 모델이
# "이미 거부됐다" 로 답할 수 있다. 그래서 포스처가 바뀌었음을 알린다.
ELEVATION_NOTICE = "(사용자가 변경 허용 포스처로 올렸습니다. 같은 요청을 다시 수행하세요.)"


def new_session_id():
    """spawn 마다 새로 만드는 세션 식별자(설계 5-2)."""
    return str(uuid.uuid4())


class PostureSpec(object):
    """포스처 하나가 argv 에 주는 값 묶음.

    게이트가 기대값으로 쓰는 것과 argv 조립이 쓰는 것이 같은 객체여야 한다.
    둘이 갈라지면 "플래그는 줬는데 게이트는 다른 것을 기대" 하는 구멍이 생긴다.
    """

    __slots__ = ("name", "tools", "allowed_tools", "disallowed_tools")

    def __init__(self, name, tools, allowed_tools, disallowed_tools):
        """세 목록을 튜플로 굳혀 둔다.

        가변 리스트로 들고 있으면 호출자가 argv 조립 뒤에 목록을 바꿀 수 있고,
        그러면 게이트의 기대값과 실제로 준 플래그가 갈라진다.

        Args:
            name: 포스처 이름("R" 또는 "W").
            tools: `--tools` 내장 도구 이름들.
            allowed_tools: `--allowedTools` 정확명들.
            disallowed_tools: `--disallowedTools` 정확명들.
        """
        self.name = name
        self.tools = tuple(tools)
        self.allowed_tools = tuple(allowed_tools)
        self.disallowed_tools = tuple(disallowed_tools)

    def __repr__(self):
        """진단 로그용 한 줄. 목록 원문이 아니라 개수만 적는다."""
        return "<PostureSpec %s tools=%d allowed=%d disallowed=%d>" % (
            self.name, len(self.tools), len(self.allowed_tools),
            len(self.disallowed_tools))


def posture_spec(name=POSTURE_R):
    """포스처 이름으로 PostureSpec 을 만든다(설계 3-3 표).

    Args:
        name: "R" 또는 "W".

    Returns:
        PostureSpec

    Raises:
        ValueError: 모르는 포스처 이름.
    """
    # 0.1.4: 양쪽 allowlist 가 BUILTIN_READ_TOOLS 로 시작한다. 두 포스처에
    # 같은 셋을 더하므로 "W 의 allowlist 는 R 의 진부분집합" 관계는 유지된다.
    if name == POSTURE_R:
        return PostureSpec(POSTURE_R, BUILTIN_TOOLS_R,
                           BUILTIN_READ_TOOLS + QGIS_READ_TOOLS,
                           DISALLOWED_TOOLS)
    if name == POSTURE_W:
        return PostureSpec(POSTURE_W, BUILTIN_TOOLS_W,
                           BUILTIN_READ_TOOLS + QGIS_READ_TOOLS
                           + QGIS_WRITE_TOOLS,
                           DISALLOWED_TOOLS)
    raise ValueError("unknown posture: %r" % (name,))


def mcp_config_obj(command=None):
    """`--mcp-config` 에 넣을 설정 객체(설계 5-2, F11).

    툴킷 `.mcp.json` 과 같은 내용이다. 태그를 고정해 두는 것이 핵심이고,
    사용자 등록본을 상속하지 않는 것은 `--strict-mcp-config` 가 맡는다.

    0.1.1: command 를 인자로 받는다. 제품 경로(plugin.py)는 항상
    detect.find_uvx_exe 가 해석한 **절대경로**를 준다. 맨이름 "uvx" 는
    QGIS 프로세스의 PATH 에 uvx 가 없으면 브리지가 뜨지 않아 게이트 4 가
    FAIL 했다(0.1.1 수정 대상). 이 모듈이 직접 해석하지 않는 이유는 detect 가
    posture 를 import 하기 때문이다 - 반대 방향 import 는 순환이 된다.

    Args:
        command: 브리지 런처 경로. 빈 값이면 QGIS_MCP_COMMAND(맨이름)로
            떨어뜨린다. 해석 실패 환경에서도 설정 파일 자체는 0.1.0 과 같은
            내용으로 남게 하려는 것이다 - 설정을 비우면 사용자가 손으로
            고칠 기준도 사라진다. 그 경우 전제조건 바가 uvx 미발견을 띄운다.

    Returns:
        dict
    """
    return {
        "mcpServers": {
            QGIS_MCP_SERVER_NAME: {
                "command": str(command) if command else QGIS_MCP_COMMAND,
                "args": list(QGIS_MCP_ARGS),
            }
        }
    }


def write_mcp_config(path, config=None, command=None):
    """MCP 설정을 파일로 쓰고 경로를 돌려준다.

    `--mcp-config` 는 JSON 문자열도 받지만(측정 스크립트가 그렇게 썼다) 제품은
    파일로 쓴다. argv 에 수백 바이트 JSON 이 들어가면 진단 로그가 읽히지 않고,
    사용자가 설정을 눈으로 확인할 경로도 없어진다.

    Args:
        path: 쓸 파일 경로.
        config: 설정 객체. None 이면 mcp_config_obj(command).
        command: 브리지 런처 경로(0.1.1). config 를 직접 준 경우에는 쓰이지
            않는다 - 그때 command 를 또 적용하면 호출자가 준 설정을 몰래
            덮어쓰는 것이 된다.

    Returns:
        str: 쓴 파일 경로.
    """
    path = str(path)
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    body = json.dumps(config if config is not None else mcp_config_obj(command),
                      ensure_ascii=False, indent=2)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(body + "\n")
    return path


def build_argv(
    claude_exe,
    session_id=None,
    resume_session_id=None,
    tools=BUILTIN_TOOLS_R,
    mcp_config_path=None,
    allowed_tools=(),
    disallowed_tools=(),
    add_dirs=(),
    model=None,
    append_system_prompt=DOCK_PREAMBLE,
    debug_file=None,
):
    """설계 5-1 순서대로 argv 리스트를 만든다.

    Args:
        claude_exe: claude 실행 파일 경로.
        session_id: `--session-id` 값. resume_session_id 가 있으면 무시한다.
        resume_session_id: 재spawn 시 이어붙일 세션. 주면 `--session-id` 대신
            `--resume` 를 쓴다. 두 플래그를 같이 주는 조합은 측정된 적이 없고,
            S0 ln253 의 실측 재개 argv 가 `--resume` 단독이었다.
        tools: `--tools` 에 넘길 내장 도구 이름들. 빈 값이면 플래그를 생략한다.
        mcp_config_path: `--mcp-config` 값. 제품은 파일 경로를 준다.
        allowed_tools: `--allowedTools` 정확명 목록. 사전승인이고 노출 축소가
            아니다(설계 3-3-0). R 에서도 비우면 MCP 읽기가 거부된다(A16).
        disallowed_tools: `--disallowedTools` 정확명 목록. MCP 노출 제거이고
            allowedTools 를 이긴다(A14 축3). 순서는 무관하다(A17).
        add_dirs: `--add-dir` 로 더할 폴더들.
        model: `--model` 값. 기본은 None(사용자 settings 의 model 키를
            덮어쓰지 않는다, F6).
        append_system_prompt: 프리앰블. None 이면 플래그를 생략한다.
        debug_file: `--debug-file` 값. 진단 모드에서만 준다.

    Returns:
        list[str]: argv.

    Raises:
        ValueError: session_id 와 resume_session_id 가 모두 없을 때.
    """
    if not resume_session_id and not session_id:
        raise ValueError("session_id or resume_session_id required")

    argv = [
        str(claude_exe),
        "-p",
        "--input-format",
        "stream-json",
        "--output-format",
        "stream-json",
        "--verbose",
        "--include-partial-messages",
        "--replay-user-messages",
        # strict 와 mcp-config 는 한 세트다(설계 5-2). mcp-config 를 주지 않는
        # 개발 구성에서도 strict 는 남긴다. 사용자가 등록한 MCP 서버를
        # 상속하지 않아야 측정 구성과 같아진다(S0 G2 argv 와 동일).
        "--strict-mcp-config",
    ]
    if mcp_config_path:
        argv += ["--mcp-config", str(mcp_config_path)]
    if resume_session_id:
        argv += ["--resume", str(resume_session_id)]
    else:
        argv += ["--session-id", str(session_id)]
    argv += ["--permission-mode", PERMISSION_MODE]
    if tools:
        argv += ["--tools", ",".join(tools)]
    if allowed_tools:
        argv += ["--allowedTools", ",".join(allowed_tools)]
    if disallowed_tools:
        argv += ["--disallowedTools", ",".join(disallowed_tools)]
    if append_system_prompt:
        argv += ["--append-system-prompt", append_system_prompt]
    for d in add_dirs:
        argv += ["--add-dir", str(d)]
    if model:
        argv += ["--model", str(model)]
    if debug_file:
        argv += ["--debug-file", str(debug_file)]
    return argv


def build_posture_argv(claude_exe, spec, session_id=None, resume_session_id=None,
                       mcp_config_path=None, add_dirs=(), model=None,
                       debug_file=None):
    """PostureSpec 하나로 제품 argv 를 만든다(설계 5-1 완전 조합).

    build_argv 를 직접 부르는 자리를 줄이려는 것이다. 포스처의 세 목록이
    따로 전달되다가 하나가 빠지는 것이 이 구조에서 가장 비싼 실수다.
    """
    return build_argv(
        claude_exe,
        session_id=session_id,
        resume_session_id=resume_session_id,
        tools=spec.tools,
        mcp_config_path=mcp_config_path,
        allowed_tools=spec.allowed_tools,
        disallowed_tools=spec.disallowed_tools,
        add_dirs=add_dirs,
        model=model,
        debug_file=debug_file,
    )


def build_dev_argv(claude_exe, session_id=None, resume_session_id=None, model=None):
    """S2~S4 개발 구성 argv(설계 10-1 조건 1).

    `--mcp-config` 와 `--allowedTools` 를 주지 않는다. 그래서 MCP 도구가 0개이고
    내장 쓰기 도구는 기본 거부(A07)로 막힌다. S5 이후에도 무과금 하네스가 이
    구성을 쓰므로 남겨 둔다.
    """
    return build_argv(
        claude_exe,
        session_id=session_id or new_session_id(),
        resume_session_id=resume_session_id,
        tools=BUILTIN_TOOLS_R,
        mcp_config_path=None,
        allowed_tools=(),
        disallowed_tools=(),
        model=model,
    )


def _item(check, status, expected, observed):
    """게이트 판정 한 항목."""
    return {
        "check": check,
        "status": status,
        "expected": expected,
        "observed": observed,
    }


def check_init(init_event, expect_tools=BUILTIN_TOOLS_R, expect_mcp_server=None,
               first_init=None, expect_disallowed=()):
    """system/init 이벤트가 포스처와 맞는지 검사한다(설계 3-4 게이트 5개).

        1. permissionMode 가 dontAsk 인가. default 면 플래그가 무시된 경우와
           구분되지 않으므로 실패로 본다.
        2. tools 의 **내장 부분**이 `--tools` 목록과 집합으로 일치하는가.
           init.tools 는 알파벳 정렬로 오므로(장부 V28-17) 순서를 보지 않는다.
           MCP 도구는 `--tools` 로 줄지 않으므로(A14 축2) 이 비교에서 뺀다.
        3. `--disallowedTools` 의 이름이 tools 에 하나도 없는가. A14 축3 이
           "노출 제거" 를 확정했으므로 매 기동 단정이다. 임의 코드와 SQL 의
           가드가 이 한 항목에 걸려 있다.
        4. mcp_servers 상태. expect_mcp_server 가 None 이면 빈 배열을 요구한다
           (개발 구성). 이름을 주면 그 서버의 status 가 connected 여야 한다.
        5. 2번째 이후 init 이 첫 init 과 (session_id, permissionMode, len(tools))
           에서 같은가. 턴마다 init 이 재발행되는 것은 정상이고 세션 리셋이
           아니지만(설계 4-2), 값이 바뀌면 권한 상태가 바뀐 것이다.

    Args:
        init_event: 파싱된 init 이벤트 dict.
        expect_tools: 기대 내장 도구 이름들.
        expect_mcp_server: 기대 MCP 서버 이름. None 이면 미연결을 기대한다.
        first_init: 첫 init 의 요약 dict. None 이면 5번 검사를 건너뛴다.
        expect_disallowed: `--disallowedTools` 로 준 이름들. 빈 값이면 3번
            검사를 건너뛴다(개발 구성).

    Returns:
        dict: ok(bool), items(list), 그리고 관측값 요약(session_id,
            permission_mode, tools, mcp_servers).
    """
    mode = init_event.get("permissionMode")
    tools = init_event.get("tools")
    tools = list(tools) if isinstance(tools, list) else []
    mcp = init_event.get("mcp_servers")
    mcp = list(mcp) if isinstance(mcp, list) else []
    session_id = init_event.get("session_id")

    items = []

    # 1. 권한 모드
    items.append(
        _item(
            "permission_mode",
            "PASS" if mode == PERMISSION_MODE else "FAIL",
            PERMISSION_MODE,
            mode,
        )
    )

    # 2. 내장 노출 정확 일치. MCP 이름은 `--tools` 의 소관이 아니므로 뺀다.
    want = set(expect_tools)
    got = set(t for t in tools if not t.startswith("mcp__"))
    items.append(
        _item(
            "tools_exact",
            "PASS" if got == want else "FAIL",
            "n=%d %s" % (len(want), ",".join(sorted(want))),
            "n=%d %s" % (len(got), ",".join(sorted(got))),
        )
    )

    # 3. 제외 이름 부재. 하나라도 보이면 플래그가 안 먹은 것이다.
    if expect_disallowed:
        leaked = sorted(set(expect_disallowed) & set(tools))
        items.append(
            _item(
                "disallowed_absent",
                "PASS" if not leaked else "FAIL",
                "none of n=%d in init.tools" % len(set(expect_disallowed)),
                "leaked=%s" % (",".join(leaked) if leaked else "(none)"),
            )
        )

    # 4. MCP 연결 상태
    if expect_mcp_server is None:
        items.append(
            _item("mcp_servers_empty", "PASS" if not mcp else "FAIL", "[]", mcp)
        )
    else:
        hit = None
        for entry in mcp:
            if isinstance(entry, dict) and entry.get("name") == expect_mcp_server:
                hit = entry
                break
        ok = bool(hit) and hit.get("status") == "connected"
        items.append(
            _item(
                "mcp_server_connected",
                "PASS" if ok else "FAIL",
                "%s=connected" % expect_mcp_server,
                hit if hit else mcp,
            )
        )

    # 5. 턴 간 드리프트
    summary = {
        "session_id": session_id,
        "permission_mode": mode,
        "tools_n": len(tools),
    }
    if first_init is not None:
        same = all(first_init.get(k) == summary[k] for k in summary)
        items.append(
            _item("no_drift_from_first_init", "PASS" if same else "FAIL", first_init, summary)
        )

    return {
        "ok": all(i["status"] == "PASS" for i in items),
        "items": items,
        "session_id": session_id,
        "permission_mode": mode,
        "tools": tools,
        "mcp_servers": mcp,
        "summary": summary,
    }


def format_gate(result):
    """게이트 판정을 한 줄 문자열로. 진단 로그와 보고에 쓴다."""
    parts = ["%s=%s" % (i["check"], i["status"]) for i in result["items"]]
    return "ok=%s %s" % (result["ok"], " ".join(parts))


def failed_checks(result):
    """어긋난 항목 이름들. UI 문구와 진단 로그가 같은 값을 쓰게 한다."""
    if not isinstance(result, dict):
        return []
    return [i.get("check") for i in (result.get("items") or ())
            if i.get("status") != "PASS"]
