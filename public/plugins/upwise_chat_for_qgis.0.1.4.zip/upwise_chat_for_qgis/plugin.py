"""UPWISE Chat for QGIS 플러그인 본체.

이 모듈이 하는 일은 네 가지뿐이다.

    1. 툴바 아이콘과 플러그인 메뉴 항목 1개 등록 (체크 가능한 토글 액션)
    2. 독 위젯을 오른쪽 독 영역에 등록
    3. 액션 체크 상태와 독 가시성 양방향 동기화
    4. unload() 에서 독의 백엔드를 끝내고 시그널, 독, 액션을 전부 되돌림

채팅 UI 는 독(ui/dock.py)이 가지고 있다. S5 가 여기에 붙인 것은 **백엔드 공장**
하나다. 공장이 포스처(설계 3-3)와 argv(5-1), MCP 설정 파일, cwd 를 묶어
SpawnSpec 을 만든다. 독은 claude 실행 파일을 직접 찾지 않는다.

S5 가 꽂는 지점 3개(설계 10-2 S5-2).
    1. UpwiseChatDock(backend_factory=...) 주입
    2. denial_retry_requested -> dock.elevate_and_resend + set_denial_retry_enabled(True)
    3. set_cwd(spec.cwd)

S6 이 붙인 것은 꽂는 지점 하나다. `dock.set_prerequisites(self.prereq)`.
탐지 객체는 독보다 오래 살아야 하므로(cwd 가 바뀌면 다시 계산한다, 설계 6-3)
플러그인이 소유하고 독은 읽는다.

브랜딩은 아직 없다(S7).

금지 API(설계 3-5): QMessageBox, QDialog.exec(), QProgressDialog, 중첩 이벤트 루프.
모달은 자동화를 정지시키므로 골격 단계에서도 쓰지 않는다. 상태 보고는
QgsMessageLog 로만 한다.

설계 정본: docs/1.mvp_design_v1.md 7-1(독 레이아웃), 7-4(리포 레이아웃), 10(S1)
"""

from pathlib import Path

from qgis.core import Qgis, QgsMessageLog, QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon

# NOTE(Claude): Qt6 에서 QAction 은 QtGui 로 옮겨갔다. 이 플러그인은 Qt5 에서만
# 검증됐고 metadata 에 supportsQt6 를 선언하지 않는다(설계 7-4, D16). Qt6 지원을
# 선언하기 전에 이 import 경로를 재확인한다.
from qgis.PyQt.QtWidgets import QAction

from .backend import detect, posture, process
from .backend.logbook import qgis_profile_root
from .ui.dock import UpwiseChatDock

# QgsMessageLog 패널에서 이 플러그인 메시지를 묶는 태그.
LOG_TAG = "UPWISE Chat"

# Plugins 메뉴 하위 그룹 이름. removePluginToMenu 가 같은 문자열로 짝을 찾으므로
# 등록과 제거가 반드시 같은 상수를 써야 한다.
MENU_GROUP = "UPWISE Chat for QGIS"

ACTION_TEXT = "UPWISE Chat"
ACTION_TOOLTIP = "UPWISE Chat 독을 열거나 닫는다"

# metadata.txt 의 icon= 과 같은 상대경로를 가리킨다. 둘이 어긋나면 플러그인
# 관리자 아이콘과 툴바 아이콘이 달라진다.
ICON_RELPATH = "resources/icon.png"

# 플러그인이 소유하는 MCP 설정 파일 위치(QGIS 사용자 프로필 아래).
# 사용자 등록본을 상속하지 않는다 - 버전 불일치 시 세션이 degraded 를 보고한
# 강의 실측이 있다(설계 5-3).
MCP_CONFIG_SUBPATH = ("upwise_chat", "qgis_mcp.json")


class UpwiseChatPlugin:
    """QGIS 플러그인 객체. QGIS 는 initGui 와 unload 만 호출한다."""

    def __init__(self, iface):
        """참조만 잡아 둔다. 위젯 생성은 initGui 에서 한다.

        Args:
            iface: QgisInterface 인스턴스.
        """
        self.iface = iface
        self.action = None
        self.dock = None
        # 탐지 결과는 독보다 오래 산다. cwd 가 바뀌면 프리셋 판정을 다시 계산해야
        # 하므로(설계 6-3) 플러그인이 들고 있는다.
        self.prereq = None

    # ------------------------------------------------------------------
    # QGIS 수명주기
    # ------------------------------------------------------------------

    def initGui(self):  # noqa: N802 - QGIS 가 요구하는 고정 이름
        """툴바/메뉴 액션과 독을 등록한다.

        독을 여기서 만들고 숨겨 둔다. 지연 생성(첫 토글에서 생성)으로 하면
        unload 경로가 "만들어졌는가" 에 따라 갈라져 왕복 테스트의 분기가 늘어난다.
        백엔드 프로세스는 이 시점에 띄우지 않는다(설계 2-1: 첫 메시지 또는
        연결 버튼에서 spawn). 공장만 넘기고 spawn 은 첫 전송에서 일어난다.
        """
        self.action = QAction(self._icon(), ACTION_TEXT, self.iface.mainWindow())
        self.action.setObjectName("UpwiseChatToggleAction")
        self.action.setToolTip(ACTION_TOOLTIP)
        self.action.setCheckable(True)
        self.action.toggled.connect(self._on_action_toggled)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(MENU_GROUP, self.action)

        cwd, cwd_why = process.resolve_cwd()
        self.prereq = detect.Prerequisites(cwd=str(cwd))
        self._log("cwd=%s (%s) prereq=%s" % (cwd, cwd_why, self.prereq.summary()))

        self.dock = UpwiseChatDock(
            self.iface.mainWindow(), backend_factory=self._make_backend
        )
        # S5-2 꽂는 지점 2, 3.
        self.dock.denial_retry_requested.connect(self._on_denial_retry)
        self.dock.set_denial_retry_enabled(True)
        self.dock.set_cwd(str(cwd))
        # S6 꽂는 지점. 탐지 결과는 플러그인이 소유하고 독은 읽어서 바와
        # 버튼에 반영한다(설계 6-4). 첫 init 뒤의 갱신은 독이 gate_result
        # 슬롯에서 백엔드의 init 원본을 읽어 스스로 한다.
        self.dock.set_prerequisites(self.prereq)
        self.dock.visibilityChanged.connect(self._on_dock_visibility_changed)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)

        # 프로젝트 전환 감지(설계 8). cleared 와 readProject 양쪽을 듣는다.
        # 새 프로젝트와 기존 프로젝트 열기가 서로 다른 신호로 오기 때문이다.
        project = QgsProject.instance()
        project.cleared.connect(self._on_project_changed)
        project.readProject.connect(self._on_project_read)

        # addDockWidget 은 독을 보이게 만든다. 플러그인 적재만으로 패널이
        # 열리지 않도록 숨긴 상태에서 시작한다. 사용자가 액션으로 연다.
        self.dock.hide()
        self._sync_action_checked(False)

    def unload(self):
        """등록한 것을 역순으로 전부 되돌린다.

        순서가 중요하다. 시그널을 먼저 끊지 않으면 removeDockWidget 이
        visibilityChanged 를 발화해서, 정리 중인 액션을 다시 건드린다.
        """
        self._teardown_project_signals()
        self._teardown_dock()
        self._teardown_action()

    def _teardown_project_signals(self):
        """프로젝트 전환 시그널을 끊는다. 독보다 먼저 끊어야 한다.

        QgsProject 는 플러그인보다 오래 살기 때문에, 끊지 않으면 unload 뒤에도
        삭제된 독을 가리키는 슬롯이 남는다.
        """
        project = QgsProject.instance()
        self._safe_disconnect(project.cleared, self._on_project_changed)
        self._safe_disconnect(project.readProject, self._on_project_read)

    # ------------------------------------------------------------------
    # 내부 - 백엔드 공장 (S5-2, S5-6)
    # ------------------------------------------------------------------

    def _mcp_config_path(self):
        """플러그인 소유 MCP 설정 파일 경로. 매 spawn 전에 다시 쓴다.

        사용자가 지운 경우와 툴킷 태그가 올라간 경우를 같은 경로로 흡수한다.
        내용은 posture.mcp_config_obj() 가 정본이다.
        """
        return qgis_profile_root().joinpath(*MCP_CONFIG_SUBPATH)

    def _make_spec(self, resume_session_id=None, posture_name=None, cwd=None):
        """SpawnSpec 하나를 만든다. BackendProcess 가 재시작마다 다시 부른다.

        플래그는 세션에 붙어 다니지 않으므로(설계 2-5, D01 실측) 매번 전량을
        다시 조립한다. 포스처와 cwd 를 인자로 받는 이유가 그것이다 -
        상승(S5-4)과 폴더 변경(S5-3)이 같은 경로를 쓴다.

        Args:
            resume_session_id: 있으면 `--resume`, 없으면 새 `--session-id`.
            posture_name: "R" 또는 "W". None 이면 R.
            cwd: 작업 폴더. None 이면 지금 QGIS 프로젝트 기준으로 다시 정한다.

        Returns:
            process.SpawnSpec
        """
        spec_posture = posture.posture_spec(posture_name or posture.POSTURE_R)
        if cwd:
            work_dir = str(cwd)
        else:
            resolved, _why = process.resolve_cwd()
            work_dir = str(resolved)
        # 브리지 런처는 절대경로로 적는다(0.1.1). 맨이름 "uvx" 는 QGIS 가 띄운
        # claude 의 PATH 에서 해석되지 않는 설치가 있고, 그때 init 의
        # mcp_servers 가 status=failed 로 와서 게이트 4 가 FAIL 했다.
        # 해석 실패(빈 문자열)면 write_mcp_config 가 맨이름으로 떨어뜨리고
        # 전제조건 바가 uvx 미발견을 띄운다.
        uvx_exe = self.prereq.uvx_exe if self.prereq else ""
        mcp_path = posture.write_mcp_config(self._mcp_config_path(),
                                            command=uvx_exe)
        session_id = posture.new_session_id()
        argv = posture.build_posture_argv(
            self.prereq.claude_exe if self.prereq else "claude",
            spec_posture,
            session_id=session_id,
            resume_session_id=resume_session_id,
            mcp_config_path=mcp_path,
        )
        env, stripped, api_key = process.child_env()
        if self.prereq is not None:
            self.prereq.set_cwd(work_dir)
        return process.SpawnSpec(
            argv,
            work_dir,
            resume_session_id or session_id,
            env=env,
            env_stripped=stripped,
            api_key_present=api_key,
        )

    def _make_backend(self):
        """독이 첫 전송에서 부르는 공장. 포스처 R 로 시작한다(설계 3-3)."""
        spec_posture = posture.posture_spec(posture.POSTURE_R)
        backend = process.BackendProcess(
            self._make_spec,
            expect_tools=spec_posture.tools,
            expect_mcp_server=posture.QGIS_MCP_SERVER_NAME,
            expect_disallowed=spec_posture.disallowed_tools,
            posture_name=spec_posture.name,
        )
        backend.gate_result.connect(self._on_gate_result)
        return backend

    def _on_gate_result(self, result):
        """첫 init 으로 전제조건을 채운다(설계 6-4). 판정은 독이 쓴다."""
        if self.prereq is None or not isinstance(result, dict):
            return
        # check_init 이 돌려주는 요약에는 plugins/skills 가 없다. 그래서 탐지
        # 전량은 독이 백엔드의 init 원본(process.last_init_event)으로 돌린다
        # (S6, dock._note_init_detect). 여기서는 MCP 축만 로그로 남긴다 -
        # 같은 값을 쓰므로 충돌하지 않고, 플러그인 로그에 기동 시점 상태가
        # 한 줄 남는 것이 진단에 쓰인다.
        servers = result.get("mcp_servers")
        if servers is not None:
            status, detail, why = detect.mcp_status_from_init(
                {"mcp_servers": servers}
            )
            self.prereq.mcp_status = status
            self.prereq.mcp_detail = detail
            self.prereq.mcp_why = why
            self._log("mcp detect: %s (%s) %s" % (status, detail, why))

    def _on_project_read(self, _doc=None):
        """readProject 는 QDomDocument 를 넘긴다. 인자를 삼키고 공통부로 보낸다."""
        self._on_project_changed()

    def _on_project_changed(self):
        """프로젝트가 바뀌었다(설계 8). 독에 알리고 자동 재시작은 하지 않는다."""
        if self.dock is None:
            return
        project = QgsProject.instance()
        name = project.baseName() or project.fileName() or "(제목 없음)"
        resolved, why = process.resolve_cwd()
        # 여기서 prereq.set_cwd 를 부르지 않는다. 프로젝트가 바뀌어도 백엔드는
        # 아직 이전 폴더를 보고 있고(자동 재시작하지 않는다, 설계 8), 프리셋
        # 폴더 판정은 **백엔드의 cwd** 기준이어야 한다(설계 6-3 마지막 줄).
        # 실제 갱신은 재spawn 경로(dock.set_cwd, _make_spec)가 한다.
        shown = self.dock.note_project_changed(name, str(resolved))
        self._log("project changed: %s cwd=%s (%s) stale_bar=%s"
                  % (name, resolved, why, shown))

    def _on_denial_retry(self):
        """거부 바의 "허용하고 다시 요청"(S5-2 지점 2, S5-4).

        상승은 재spawn 이고 같은 요청을 1회 재전송하는 것까지가 독의 일이다.
        """
        if self.dock is None:
            return
        ok = self.dock.elevate_and_resend()
        self._log("denial retry elevate_and_resend -> %s" % ok,
                  None if ok else Qgis.Warning)

    # ------------------------------------------------------------------
    # 내부 - 정리
    # ------------------------------------------------------------------

    def _teardown_dock(self):
        """독의 백엔드를 끝내고 시그널을 끊은 뒤 QGIS 에서 떼어낸다.

        순서가 중요하다. 백엔드를 먼저 끝낸다. claude 가 MCP 브리지를 자식으로
        띄우므로 독 위젯만 지우면 고아 프로세스가 남는다(설계 7-1, 2-1).
        """
        dock = self.dock
        self.dock = None
        if dock is None:
            return
        try:
            dock.shutdown()
        except Exception as exc:  # noqa: BLE001 - unload 는 끝까지 진행해야 한다
            self._log("dock shutdown failed: %r" % (exc,), Qgis.Warning)
        self._safe_disconnect(dock.visibilityChanged, self._on_dock_visibility_changed)
        self._safe_disconnect(dock.denial_retry_requested, self._on_denial_retry)
        try:
            self.iface.removeDockWidget(dock)
        except Exception as exc:  # noqa: BLE001 - unload 는 끝까지 진행해야 한다
            self._log("removeDockWidget failed: %r" % (exc,), Qgis.Warning)
        # setParent(None) 으로 mainWindow 자식 목록에서 먼저 빼낸다. deleteLater
        # 는 이벤트 루프 한 바퀴 뒤에 실제 삭제되므로, 그 사이 QGIS 가 자식을
        # 훑어도 떼어낸 위젯이 걸리지 않게 하기 위함이다.
        dock.setParent(None)
        dock.deleteLater()

    def _teardown_action(self):
        """액션의 시그널을 끊고 툴바/메뉴에서 제거한 뒤 삭제 예약한다."""
        action = self.action
        self.action = None
        if action is None:
            return
        self._safe_disconnect(action.toggled, self._on_action_toggled)
        try:
            self.iface.removePluginToMenu(MENU_GROUP, action)
            self.iface.removeToolBarIcon(action)
        except Exception as exc:  # noqa: BLE001 - 위와 같은 이유
            self._log("action removal failed: %r" % (exc,), Qgis.Warning)
        action.setParent(None)
        action.deleteLater()

    # ------------------------------------------------------------------
    # 내부 - 가시성 동기화
    # ------------------------------------------------------------------

    def _on_action_toggled(self, checked):
        """액션 체크 변화를 독 가시성에 반영한다."""
        if self.dock is not None:
            self.dock.setVisible(bool(checked))

    def _on_dock_visibility_changed(self, visible):
        """독 가시성 변화를 액션 체크 상태에 반영한다.

        사용자가 독의 X 를 눌러 닫은 경우에도 액션 체크가 풀려야 한다.
        """
        self._sync_action_checked(bool(visible))

    def _sync_action_checked(self, checked):
        """시그널을 막은 채 체크 상태만 맞춘다.

        blockSignals 없이 setChecked 를 호출하면 toggled -> setVisible ->
        visibilityChanged -> setChecked 로 되돌아오는 왕복이 생긴다.
        """
        if self.action is None:
            return
        blocked = self.action.blockSignals(True)
        try:
            self.action.setChecked(bool(checked))
        finally:
            self.action.blockSignals(blocked)

    # ------------------------------------------------------------------
    # 내부 - 유틸
    # ------------------------------------------------------------------

    def _icon(self):
        """툴바 아이콘. 파일이 없으면 빈 QIcon 으로 떨어뜨린다.

        아이콘 부재로 플러그인 적재가 실패하면 안 되므로 존재 여부를 확인한다.
        """
        path = Path(__file__).resolve().parent / ICON_RELPATH
        if path.is_file():
            return QIcon(str(path))
        self._log("icon not found: %s" % (path,), Qgis.Warning)
        return QIcon()

    @staticmethod
    def _safe_disconnect(signal, slot):
        """이미 끊긴 시그널에 disconnect 를 불러도 unload 가 깨지지 않게 한다.

        Qt 는 연결이 없을 때 TypeError, 수신 객체가 이미 삭제됐을 때
        RuntimeError 를 던진다. 둘 다 정리 경로에서는 정상 상황이다.
        """
        try:
            signal.disconnect(slot)
        except (TypeError, RuntimeError):
            pass

    @staticmethod
    def _log(message, level=None):
        """QgsMessageLog 로만 보고한다. 콘솔 print 는 cp949 에서 깨진다(설계 8)."""
        QgsMessageLog.logMessage(
            message, LOG_TAG, Qgis.Info if level is None else level
        )
