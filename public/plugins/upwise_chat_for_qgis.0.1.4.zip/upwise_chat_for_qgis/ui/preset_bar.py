"""전제조건 바, 프리셋 행, 스킬 마커 안내 바 (S6).

설계 7-1 의 레이아웃 중 이 모듈이 맡는 것

    [2] 전제조건 바  PrereqBar. 미충족 항목만 적는다. 다 충족이면 숨는다
    [3] 프리셋 행    PresetRow. 버튼 5개, 비활성 시 이유를 툴팁으로 붙인다

그리고 설계 6-2 의 사후 판정 안내가 하나 더 있다.

    SkillMarkerBar  마커가 안 보인 프리셋 턴에 "스킬이 호출되지 않았습니다" 와
                    [자연어로 다시 요청] 버튼을 띄운다

왜 버튼이 입력 박스에 넣기만 하는가
    프리셋 5개 중 4개가 대상(어느 pN, 어느 레이어)을 암묵 인자로 받는다(F10).
    자동 전송하면 범위가 틀린 실행이 된다. 그래서 주입 + 포커스가 기본이고
    자동 전송은 전제조건이 없는 connect-check 하나뿐이다(설계 6-1). 어느 것을
    자동 전송하는지는 이 모듈이 정하지 않는다 - detect.PRESET_AUTOSEND 가 정본이고
    독이 읽는다.

왜 비활성 이유를 툴팁으로 두는가
    모달을 쓸 수 없다(설계 3-5: 모달 팝업이 자동화를 정지시킨다). 눌렀을 때
    대화상자로 알리는 경로가 막혀 있으므로, 누르기 전에 읽을 수 있는 자리에
    이유를 둔다. 버튼이 왜 꺼져 있는지 모른 채로 두지 않는 것이 요구사항이다
    (설계 7-1 [3] "비활성 시 이유 툴팁").

금지 API(설계 3-5): QMessageBox, QDialog.exec(), QProgressDialog, QFileDialog,
중첩 이벤트 루프. Qt import 는 전부 qgis.PyQt 셰임 경로로 한다(설계 7-4).

설계 정본: docs/1.mvp_design_v1.md 6-1, 6-2, 6-3, 7-1
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from ..backend import detect

# 전제조건 바 머리말. 항목이 여러 개면 줄로 나눈다.
PREREQ_HEADER = "준비되지 않은 항목"

# 프리셋 행 머리말. 버튼만 있으면 무엇을 누르는 것인지 알기 어렵다.
PRESET_HEADER = "프리셋"

# 활성 프리셋 버튼의 툴팁. 슬래시 명령 원문을 보여 준다 - 수강생이 터미널에서
# 같은 것을 쓸 수 있어야 하고, 주입된 문자열과 보이는 것이 같아야 한다.
PRESET_TIP_READY = "%s\n입력 박스에 넣습니다. 대상을 적고 보내세요."
PRESET_TIP_AUTOSEND = "%s\n바로 보냅니다."

# 마커 안내 바 문구(설계 6-2). detect 의 상수를 그대로 쓴다.
MARKER_MISS_TEXT = "%s: " + detect.MARKER_FAIL_TEXT


class PrereqBar(QFrame):
    """[2] 전제조건 바. 미충족 항목만 적고, 없으면 숨는다(설계 7-1).

    시그널을 내지 않는다. 안내 전용이고 행동 버튼은 프리셋 행과 입력 영역이
    가지고 있다.
    """

    def __init__(self, parent=None):
        """숨은 상태로 만든다. show_items() 가 띄운다."""
        super().__init__(parent)
        self.setObjectName("UpwiseChatPrereqBar")
        self.setFrameShape(QFrame.StyledPanel)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(2)

        self._label = QLabel("", self)
        self._label.setObjectName("UpwiseChatPrereqText")
        self._label.setWordWrap(True)
        self._label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self._label)

        self._codes = ()
        self.setVisible(False)

    def show_items(self, items):
        """미충족 항목을 적는다. 빈 목록이면 바를 내린다.

        Args:
            items: (코드, 한 줄) 튜플 목록. detect.Prerequisites.unmet_items()
                의 반환형이고, 독이 백엔드 기동 실패 항목을 앞에 더해 넘긴다.

        Returns:
            bool: 지금 바가 보이는가.
        """
        items = [i for i in (items or ()) if i]
        if not items:
            self._codes = ()
            self._label.setText("")
            self.setVisible(False)
            return False
        self._codes = tuple(str(code) for code, _text in items)
        body = [PREREQ_HEADER]
        for _code, text in items:
            body.append("- " + str(text))
        self._label.setText("\n".join(body))
        self.setVisible(True)
        return True

    def codes(self):
        """지금 적혀 있는 항목 코드들. 검증 하네스가 읽는다."""
        return tuple(self._codes)

    def label_text(self):
        """바에 적힌 글. 검증 하네스가 읽는다."""
        return self._label.text()


class PresetRow(QFrame):
    """[3] 프리셋 행. 버튼 5개를 설계 6-1 의 순서로 둔다.

    시그널 하나만 낸다.

        preset_clicked(str)  눌린 프리셋 이름(스킬 front matter name)
    """

    preset_clicked = pyqtSignal(str)

    def __init__(self, parent=None):
        """버튼 5개를 만든다. 전부 비활성에서 시작한다.

        전제조건을 모르는 상태에서 활성으로 두면 누를 수 있는 것이 되고, 그때
        눌리면 claude 경로도 없이 전송을 시도한다. set_states() 가 켠다.
        """
        super().__init__(parent)
        self.setObjectName("UpwiseChatPresetRow")
        self.setFrameShape(QFrame.NoFrame)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        head = QLabel(PRESET_HEADER, self)
        head.setObjectName("UpwiseChatPresetHeader")
        layout.addWidget(head)

        row = QFrame(self)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(4)

        self._buttons = {}
        for preset in detect.PRESET_ORDER:
            button = QPushButton(detect.PRESET_LABELS.get(preset, preset), row)
            button.setObjectName("UpwiseChatPreset_" + preset)
            button.setEnabled(False)
            # 눌린 프리셋 이름을 그대로 올린다. clicked 의 bool 인자를 삼키려고
            # 기본값으로 묶어 둔다(늦은 바인딩을 피한다).
            button.clicked.connect(
                lambda _checked=False, name=preset: self.preset_clicked.emit(name)
            )
            row_layout.addWidget(button)
            self._buttons[preset] = button
        row_layout.addStretch(1)
        layout.addWidget(row)

        self._reasons = {}

    def set_states(self, states):
        """프리셋별 활성 여부와 이유를 반영한다(설계 7-1 [3]).

        Args:
            states: (프리셋, 활성 여부, 이유) 목록.
                detect.Prerequisites.preset_states() 의 반환형이다.

        Returns:
            int: 활성인 버튼 수.
        """
        enabled_n = 0
        for preset, enabled, reason in states or ():
            button = self._buttons.get(preset)
            if button is None:
                continue
            button.setEnabled(bool(enabled))
            self._reasons[preset] = str(reason or "")
            command = detect.slash_command(preset)
            if enabled:
                enabled_n += 1
                tip_fmt = (PRESET_TIP_AUTOSEND if preset in detect.PRESET_AUTOSEND
                           else PRESET_TIP_READY)
                tip = tip_fmt % command
                # 활성이지만 "확인 중" 같은 단서가 있으면 함께 적는다.
                if reason:
                    tip += "\n" + str(reason)
            else:
                tip = str(reason or "지금은 쓸 수 없습니다")
            button.setToolTip(tip)
        return enabled_n

    def button(self, preset):
        """버튼 하나. 검증 하네스가 눌러 본다."""
        return self._buttons.get(preset)

    def states(self):
        """프리셋별 (활성, 툴팁) 요약. 검증 하네스가 읽는다."""
        return {
            preset: (button.isEnabled(), button.toolTip())
            for preset, button in self._buttons.items()
        }

    def reason(self, preset):
        """마지막으로 반영한 비활성 이유."""
        return self._reasons.get(preset, "")


class SkillMarkerBar(QFrame):
    """마커가 안 보인 프리셋 턴의 안내 바(설계 6-2).

    시그널 둘을 낸다.

        fallback_requested(str)  자연어로 다시 요청. 인자는 프리셋 이름
        dismissed()              닫기

    이 바는 승인/권한과 무관하다. 거부 바(approval_bar.DenialRetryBar)와 문구와
    버튼이 달라야 한다 - 여기서 막힌 것은 권한이 아니라 **슬래시 명령이 스킬로
    해석되지 않은 것**(D02)이고, 포스처를 올려도 풀리지 않는다.
    """

    fallback_requested = pyqtSignal(str)
    dismissed = pyqtSignal()

    def __init__(self, parent=None):
        """숨은 상태로 만든다. show_miss() 가 띄운다."""
        super().__init__(parent)
        self.setObjectName("UpwiseChatSkillMarkerBar")
        self.setFrameShape(QFrame.StyledPanel)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)

        self._label = QLabel("", self)
        self._label.setWordWrap(True)
        self._label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self._label, 1)

        self._retry = QPushButton(detect.MARKER_FALLBACK_BUTTON, self)
        self._retry.clicked.connect(self._on_retry)
        layout.addWidget(self._retry)

        self._close = QPushButton("확인", self)
        self._close.clicked.connect(self._on_close)
        layout.addWidget(self._close)

        self._turn_no = None
        self._preset = ""
        self.setVisible(False)

    def show_miss(self, turn_no, preset):
        """마커 미검출을 알린다.

        Args:
            turn_no: 턴 번호.
            preset: 그 턴을 띄운 프리셋 이름.

        Returns:
            bool: 지금 바가 보이는가.
        """
        self._turn_no = turn_no
        self._preset = str(preset or "")
        self._label.setText(
            MARKER_MISS_TEXT % detect.PRESET_LABELS.get(self._preset, self._preset)
        )
        self._retry.setToolTip(detect.fallback_prompt(self._preset))
        self.setVisible(True)
        return True

    def hide_bar(self):
        """바를 내린다."""
        self._turn_no = None
        self._preset = ""
        self.setVisible(False)

    def turn_no(self):
        """지금 바가 가리키는 턴 번호."""
        return self._turn_no

    def preset(self):
        """지금 바가 가리키는 프리셋 이름."""
        return self._preset

    def label_text(self):
        """바에 적힌 글. 검증 하네스가 읽는다."""
        return self._label.text()

    def _on_retry(self):
        """자연어 재요청. 프리셋 이름을 실어 올린다."""
        preset = self._preset
        self.hide_bar()
        self.fallback_requested.emit(preset)

    def _on_close(self):
        """닫기. 그 턴은 다시 띄우지 않는다(판단은 독이 한다)."""
        self.dismissed.emit()
