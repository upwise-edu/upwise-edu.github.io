"""브랜드 팔레트, 테마 판정, 독 루트 스타일시트 조립 (S7 브랜딩).

이 모듈이 맡는 것 세 가지(설계 7-3)

    1. 테마 판정   현재 팔레트의 Window 색 상대 휘도로 다크/라이트를 가른다.
                   QGIS 에 공식 "다크 여부" API 가 없어서 쓰는 표준 관용구다.
    2. 팔레트 토큰 설계 7-3 표의 색을 테마별 dict 로 돌려준다.
    3. qss 조립    resources/style.qss 템플릿을 읽어 토큰을 끼운다.

왜 qss 를 파일로 두고 토큰만 끼우는가
    설계 7-4 가 `resources/style.qss` 를 S7 산출물로 적고 있다. 그런데 토큰은
    테마마다 다르므로 정적 qss 한 장으로는 두 테마를 담을 수 없다. 그래서
    **규칙(선택자)은 파일에, 값(색)은 이 모듈에** 둔다. 파일을 고치면 선택자가,
    이 모듈을 고치면 색이 바뀐다.

왜 독 내용 위젯에만 적용하는가
    설계 7-3 첫 줄이 QGIS 전역 스타일시트를 금지한다. 더 좁혀서 QDockWidget
    자체가 아니라 그 내용 위젯에 건다. QDockWidget 에 스타일시트를 걸면 Qt 가
    제목 줄까지 스타일시트 스타일로 그려서 플랫폼 기본 제목 줄과 버튼 모양이
    바뀐다. 내용 위젯에 걸면 그 위험이 없고 적용 범위는 같다.

색의 근거(실측)
    * 주 버튼 글자색은 네이비다. `#f7931e` 위 흰색은 대비 2.296 으로 소형 텍스트
      AA(4.5) 미달이고 네이비 `#0a1929` 는 7.726 으로 통과한다(V28-27 실계산).
    * 라이트 카드 `#f8fafc` 위 보조 텍스트는 `#475569` 다. 설계 7-3 표의
      `#94a3b8` 는 같은 배경에서 2.451 로 AA 미달이었다(V28-28). 후보를
      `#475569` -> `#334155` 순으로 두고 4.5 를 처음 넘는 것을 채택했다.
    * 다크 카드 `#1e3a5f` 위 `#cbd5e1` 는 7.747 로 통과한다. 그대로 쓴다.

글꼴 크기를 px 로 고정하지 않는다(설계 7-3 마지막 줄). qss 에 font-size 가
없는 것은 하네스가 검사한다.

설계 정본: docs/1.mvp_design_v1.md 7-1, 7-3, 7-4
"""

from pathlib import Path

from qgis.PyQt.QtGui import QColor, QPalette

# ----------------------------------------------------------------------
# 브랜드 자산과 문자열
# ----------------------------------------------------------------------

# 헤더 로고를 누르면 여는 주소(설계 7-1 [1]). 툴팁에는 호스트만 적는다.
BRAND_URL = "https://upwise.co.kr"
BRAND_TOOLTIP = "upwise.co.kr"

# 로고 옆 글자. 타일만으로는 24-32 px 에서 상표를 읽기 어렵다.
WORDMARK_TEXT = "UPWISE"

# 패키지 루트 기준 상대경로. metadata.txt 의 icon= 과 같은 방식이다.
LOGO_ASSET_RELPATH = "resources/logo_upwise@2x.png"
QSS_ASSET_RELPATH = "resources/style.qss"

# ----------------------------------------------------------------------
# 색 토큰 (설계 7-3 표 + V28-27/V28-28 실측 정정)
# ----------------------------------------------------------------------

NAVY = "#0a1929"
ORANGE = "#f7931e"
ORANGE_HOVER = "#ff6b35"
ACCENT = "#ffa756"
WHITE = "#ffffff"

CARD_BG_LIGHT = "#f8fafc"
CARD_BORDER_LIGHT = "#e2e8f0"
CARD_BG_DARK = "#1e3a5f"
CARD_BORDER_DARK = "#2c4870"

# 라이트 보조 텍스트 후보. 앞에서부터 `#f8fafc` 위 대비 4.5 를 처음 넘는 것을
# 쓴다(V28-28 의 사전 명세). 실계산에서 `#475569` 가 첫 통과였다.
MUTED_LIGHT_CANDIDATES = ("#475569", "#334155")
MUTED_LIGHT = MUTED_LIGHT_CANDIDATES[0]
MUTED_DARK = "#cbd5e1"

# 다크/라이트 경계. WCAG 상대 휘도 0.5 를 기준으로 가른다. QGIS 다크 테마의
# Window 는 `#1e1e1e` 계열(L 약 0.012)이고 라이트는 `#f0f0f0` 계열(L 약 0.87)로
# 두 분포가 멀어서 경계 위치에 결과가 민감하지 않다.
DARK_LUMINANCE_THRESHOLD = 0.5

# WCAG 2.x sRGB 선형화 분기점.
SRGB_LINEAR_CUTOFF = 0.03928


def srgb_channel_to_linear(byte_value):
    """sRGB 채널 1개(0-255)를 선형 값으로 바꾼다 (WCAG 2.x).

    Args:
        byte_value: 0-255 정수.

    Returns:
        float: 선형화된 채널 값.
    """
    c = byte_value / 255.0
    if c <= SRGB_LINEAR_CUTOFF:
        return c / 12.92
    return ((c + 0.055) / 1.055) ** 2.4


def relative_luminance(color):
    """QColor 의 WCAG 2.x 상대 휘도.

    Args:
        color: QColor 또는 QColor 가 받는 색 문자열.

    Returns:
        float: 0.0(검정) ~ 1.0(흰색).
    """
    qc = color if isinstance(color, QColor) else QColor(color)
    return (0.2126 * srgb_channel_to_linear(qc.red())
            + 0.7152 * srgb_channel_to_linear(qc.green())
            + 0.0722 * srgb_channel_to_linear(qc.blue()))


def contrast_ratio(color_a, color_b):
    """두 색의 WCAG 2.x 대비. 밝은 쪽이 분자다.

    Args:
        color_a: QColor 또는 색 문자열.
        color_b: QColor 또는 색 문자열.

    Returns:
        float: 1.0 ~ 21.0.
    """
    la = relative_luminance(color_a)
    lb = relative_luminance(color_b)
    lighter, darker = (la, lb) if la >= lb else (lb, la)
    return (lighter + 0.05) / (darker + 0.05)


def is_dark_palette(palette):
    """팔레트가 다크 테마인가 (설계 7-3).

    QGIS 는 "다크 테마인가" 를 묻는 API 를 주지 않는다. 그래서 Window 색의
    상대 휘도로 가르는 표준 관용구를 쓴다.

    Args:
        palette: QPalette.

    Returns:
        bool: 다크면 True.
    """
    window = palette.color(QPalette.Window)
    return relative_luminance(window) < DARK_LUMINANCE_THRESHOLD


def tokens(dark):
    """테마별 색 토큰 (설계 7-3 표).

    배경과 본문 색을 브랜드색으로 덮지 않는다. 그 둘은 QGIS 팔레트가 가지고
    있고 여기서 정하는 것은 **액센트와 카드/헤더 면**뿐이다. 다크 테마에서
    넓은 오렌지 면을 만들지 않는 것도 같은 이유다(설계 7-3 마지막 불릿).

    Args:
        dark: 다크 테마인가.

    Returns:
        dict: qss 템플릿에 끼울 토큰.
    """
    return {
        # 헤더는 양 테마 공통 네이비다. 로고 타일과 같은 계열이어야 한다.
        "header_bg": NAVY,
        "header_fg": WHITE,
        "header_accent": ACCENT,
        "primary_bg": ORANGE,
        "primary_fg": NAVY,
        "primary_hover_bg": ORANGE_HOVER,
        "card_bg": CARD_BG_DARK if dark else CARD_BG_LIGHT,
        "card_border": CARD_BORDER_DARK if dark else CARD_BORDER_LIGHT,
        "muted_fg": MUTED_DARK if dark else MUTED_LIGHT,
    }


def package_dir():
    """플러그인 패키지 루트 경로.

    Returns:
        Path: `upwise_chat_for_qgis/` 폴더.
    """
    return Path(__file__).resolve().parent.parent


def asset_path(relpath):
    """패키지 루트 기준 자산 경로.

    Args:
        relpath: `resources/...` 같은 상대경로 문자열.

    Returns:
        Path: 절대경로.
    """
    return package_dir() / relpath


def load_qss_template():
    """style.qss 템플릿 원문을 읽는다.

    Returns:
        str: 템플릿. 파일이 없으면 빈 문자열(스타일 없이도 독은 동작한다).
    """
    path = asset_path(QSS_ASSET_RELPATH)
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        # 자산이 빠진 설치본에서도 독은 떠야 한다. 스타일만 포기한다.
        return ""


def build_qss(dark):
    """테마에 맞는 독 스타일시트 문자열.

    Args:
        dark: 다크 테마인가.

    Returns:
        str: 토큰이 채워진 qss. 템플릿이 없으면 빈 문자열.
    """
    template = load_qss_template()
    if not template:
        return ""
    return template % tokens(dark)


def apply_dock_theme(widget):
    """독 내용 위젯에 스타일시트를 건다 (설계 7-3).

    QGIS 전역(`QgsApplication.setStyleSheet`)을 건드리지 않는다. 또한
    QDockWidget 자체가 아니라 내용 위젯에 거는 것이 이 함수의 계약이다.

    Args:
        widget: 독 내용 루트 위젯.

    Returns:
        bool: 다크 테마로 판정했는가.
    """
    dark = is_dark_palette(widget.palette())
    widget.setStyleSheet(build_qss(dark))
    return dark
