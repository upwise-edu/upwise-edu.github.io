"""UPWISE Chat 독 위젯 (S4 채팅 UI).

설계 7-1 의 7개 영역 중 S4 가 만드는 것

    [1] 헤더      상태 칩(모델/도구 수/MCP)과 권한 배지
    [4] 전사 영역  chat_view.ChatView
    [5] 승인 바    거부 재시도 바(approval_bar.DenialRetryBar)와 제외 안내 바
                   (approval_bar.ExclusionNoticeBar). 둘은 신호가 다르다.
                   포스처 토글과 턴 승인 바는 S5 범위 목록에 없어 만들지 않는다
    [6] 입력 영역  멀티라인 입력, [전송](Ctrl+Enter), [취소], cwd 표시
    [7] 상태 바    상태/턴 경과/침묵/stderr 줄 수, 침묵 워치독 행

S6 이 더한 것
    [2] 전제조건 바  preset_bar.PrereqBar. 미충족 항목만 적는다
    [3] 프리셋 행    preset_bar.PresetRow. 버튼 5개. 주입 + 포커스가 기본이고
                     connect-check 만 자동 전송한다(설계 6-1)
    마커 안내 바     preset_bar.SkillMarkerBar. 프리셋 턴이 닫힐 때 첫
                     assistant 텍스트 블록의 첫 줄로 스킬 호출을 판정한다
                     (설계 6-2). 슬래시가 stdin 경로에서 먹는지는 미측(D02)이고
                     이 판정이 그것을 우회한다
    헤더 1줄         터미널 Claude Code 동시 사용 경고(설계 8). 탐지할 수 없는
                     상황이라 상시 표시다

S7 이 더한 것
    [1] 헤더 브랜드  BrandLink. 흰 패널 로고 타일 + 'UPWISE' 글자. 전체가 한
                     클릭 영역이고 누르면 기본 브라우저로 upwise.co.kr 을 연다
                     (설계 7-1 [1]). 모달을 쓰지 않는 외부 링크 경로다.
    팔레트 적용      theme.apply_dock_theme 으로 독 내용 위젯에만 qss 를 건다.
                     QGIS 전역 스타일시트를 건드리지 않는다(설계 7-3).
                     주 버튼, 승인 바, 카드, 보조 텍스트가 토큰을 받는다.

권한 배지는 "권한 미확인" 에서 시작한다. **입력을 보내기 전에는 init 이 오지
않는다(D06 FAIL, S0 ln32/ln62-63/ln152-153).** 그래서 무과금 사전점검이 없고,
첫 턴의 init 에서 게이트 결과가 와서 배지를 갱신한다(설계 3-4).

S5 가 더한 것 네 가지.
    게이트 실패 차단  판정이 깨지면 입력을 막고 백엔드를 다시 띄운다(S5-1).
                      재시작이 끝나면 차단을 푼다 - 안 풀면 교착이다(init 은
                      턴을 보낸 뒤에만 온다).
    제외 안내 바      거부와 제외의 문구를 가른다(설계 3-5 표).
    cwd 변경          표시를 눌러 인라인으로 바꾸고 재spawn 한다(S5-3).
                      대화상자를 쓰지 않는다.
    상승 재전송        거부 바의 "허용하고 다시 요청" = W 포스처 재spawn +
                      `--resume` + 같은 요청 1회(S5-4, D23 측정 대상).

백엔드는 주입받는다. argv 조립(설계 5장)과 포스처가 S5 범위이므로, 독은
claude 실행 파일을 직접 찾지 않는다. `backend_factory` 를 받으면 첫 전송에서
그것으로 백엔드를 만들고, 없으면 입력 영역을 잠근 채로 전사만 그린다.

취소는 턴 중단이 아니라 백엔드 재시작이다(설계 2-5). 그렇게 표시한다.

금지 API(설계 3-5): QMessageBox, QDialog.exec(), QProgressDialog, 중첩 이벤트 루프.
Qt import 는 전부 qgis.PyQt 셰임 경로로 한다(설계 7-4).

설계 정본: docs/1.mvp_design_v1.md 2-4, 2-5, 3-4, 3-5, 4-1 ~ 4-5, 7-1
"""

import collections
import time

from qgis.PyQt.QtCore import Qt, QTimer, QUrl, pyqtSignal
from qgis.PyQt.QtGui import QDesktopServices, QKeySequence, QPixmap

# NOTE(Claude): Qt6 에서 QShortcut 은 QtGui 로 옮겨갔다. 이 플러그인은 Qt5 에서만
# 검증됐고 metadata 에 supportsQt6 를 선언하지 않는다(설계 7-4, D16).
from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QShortcut,
    QVBoxLayout,
    QWidget,
)

from ..backend import detect as detect_mod
from ..backend import machine as machine_mod
from ..backend import posture as posture_mod
from . import theme as theme_mod
from .approval_bar import DenialRetryBar, ExclusionNoticeBar, StaleCwdBar
from .chat_view import ChatView
from .preset_bar import PrereqBar, PresetRow, SkillMarkerBar

# QGIS 는 독의 위치와 표시 상태를 objectName 으로 저장하고 복원한다.
# 이름이 비어 있으면 세션 간 복원이 되지 않고 Qt 경고가 뜬다.
DOCK_OBJECT_NAME = "UpwiseChatDock"

DOCK_TITLE = "UPWISE Chat"

# 독 루트 레이아웃 여백(px). Qt 기본 여백은 독 안에서 과하게 넓다.
LAYOUT_MARGIN = 8

# 헤더 로고 타일의 표시 높이(논리 px). 설계 7-2 는 독 헤더를 24-32 px 로 두고,
# S7a 미리보기도 28 px 를 대표값으로 재서 이 값을 쓴다.
BRAND_TILE_HEIGHT = 28

# @2x 자산 배율. 자산은 56 px 로 넣고 devicePixelRatio 2 로 표시 치수를 반으로
# 접는다. HiDPI 에서 또렷하고 1x 에서는 Qt 가 스무스 축소한다(설계 7-2).
BRAND_TILE_SCALE = 2

# 헤더 네이비 면의 내부 여백(px). 로고 타일이 면에 붙지 않게 한다.
HEADER_PADDING = 8

# 로고 타일과 글자 사이 간격(px).
BRAND_SPACING = 6


def brand_tile_pixmap(logical_height=BRAND_TILE_HEIGHT):
    """헤더 로고 타일 pixmap 하나 (설계 7-2).

    @2x 자산을 읽어 devicePixelRatio 를 걸어 돌려준다. 자산 높이가 기대와
    다르면 스무스 축소로 맞춘다 - 자산을 바꿔도 헤더 높이가 흔들리지 않게
    하기 위함이다.

    Args:
        logical_height: 화면에 보일 논리 높이(px).

    Returns:
        QPixmap: 자산이 없으면 isNull() 인 pixmap. 호출자가 판단한다.
    """
    path = theme_mod.asset_path(theme_mod.LOGO_ASSET_RELPATH)
    pix = QPixmap(str(path))
    if pix.isNull():
        return pix
    want = int(logical_height) * BRAND_TILE_SCALE
    if pix.height() != want:
        pix = pix.scaledToHeight(want, Qt.SmoothTransformation)
    pix.setDevicePixelRatio(float(BRAND_TILE_SCALE))
    return pix


class BrandLink(QWidget):
    """헤더의 로고 타일과 'UPWISE' 글자. 전체가 한 클릭 영역이다(설계 7-1 [1]).

    타일만으로는 28 px 에서 상표를 읽기 어렵고, 글자만으로는 로고가 사라진다.
    그래서 둘을 한 위젯에 넣고 영역 전체에 손 커서와 툴팁을 붙인다.

    왜 QPushButton 이 아닌가
        버튼 모양(테두리, 눌림 효과)이 헤더 네이비 면 위에서 상표를 액자처럼
        가둔다. 링크의 성질은 커서와 툴팁으로 충분히 드러난다.

    시그널 하나를 낸다.

        clicked()  왼쪽 버튼을 위젯 안에서 눌러 안에서 뗐을 때.
    """

    clicked = pyqtSignal()

    def __init__(self, parent=None):
        """타일과 글자를 올리고 커서, 툴팁을 붙인다."""
        super().__init__(parent)
        self.setObjectName("UpwiseChatBrand")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(theme_mod.BRAND_TOOLTIP)

        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(BRAND_SPACING)

        self.tile_label = QLabel(self)
        self.tile_label.setObjectName("UpwiseChatBrandTile")
        pix = brand_tile_pixmap()
        if not pix.isNull():
            self.tile_label.setPixmap(pix)
        row.addWidget(self.tile_label)

        self.wordmark_label = QLabel(theme_mod.WORDMARK_TEXT, self)
        self.wordmark_label.setObjectName("UpwiseChatBrandWordmark")
        row.addWidget(self.wordmark_label)

    def mouseReleaseEvent(self, event):
        """클릭 판정. 누른 뒤 밖으로 끌어 놓으면 열지 않는다.

        press 가 아니라 release 에서 내는 이유는 그것이 플랫폼 공통의 "클릭"
        정의이고, 실수로 누른 것을 끌어서 취소할 수 있어야 하기 때문이다.
        """
        if event.button() == Qt.LeftButton and self.rect().contains(event.pos()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)

    def tile_pixmap(self):
        """타일에 걸린 pixmap. 하네스가 실치수를 잰다."""
        return self.tile_label.pixmap()

    def wordmark_text(self):
        """글자 라벨 문구."""
        return self.wordmark_label.text()

# 워치독 표시 갱신 주기(ms). 침묵 판정 자체는 상태머신이 하고(설계 4-5) 여기서는
# 남은 시간 카운트다운을 1초마다 다시 쓴다. 드레인(50 ms)과 별개의 타이머다.
WATCHDOG_TICK_MS = 1000

# 입력 영역 높이 상한(줄). 긴 텍스트를 붙여 넣어도 전사 영역을 먹지 않게 한다.
INPUT_MAX_LINES = 6

# 진단용 stderr 보관 줄 수. 전사에 섞지 않는다(설계 4-2 stderr 행).
STDERR_TAIL_MAX = 200

BADGE_UNKNOWN = "권한 미확인"
CWD_PREFIX = "작업 폴더: "
CWD_UNSET = "(미지정)"

PLACEHOLDER_NO_BACKEND = "백엔드가 연결되지 않았습니다."
PLACEHOLDER_READY = "메시지를 입력하고 Ctrl+Enter 로 보냅니다."
# 게이트가 깨진 동안의 placeholder. 입력을 아예 막는 이유를 그 자리에 쓴다.
PLACEHOLDER_GATE_BLOCKED = "권한 점검이 어긋나 전송을 막았습니다. 백엔드를 다시 띄웁니다."

# 게이트 실패 공지. 설계 3-4 는 입력을 열지 않는 것까지 요구하고, 사용자에게는
# 왜 막혔는지가 보여야 한다.
NOTICE_GATE_BLOCKED = (
    "기동 자기점검이 어긋났습니다(%s). 이 턴의 결과를 버리고 백엔드를 "
    "다시 띄웁니다. 그동안 전송이 막힙니다."
)
NOTICE_GATE_BLOCKED_FINAL = (
    "기동 자기점검이 다시 어긋났습니다(%s). 자동 재시작을 멈춥니다. "
    "QGIS 를 다시 시작하거나 claude CLI 설정을 확인하세요."
)
NOTICE_ELEVATED = "변경 허용 포스처로 올려 같은 요청을 다시 보냅니다."
NOTICE_ELEVATE_FAILED = "포스처 상승에 실패했습니다. 읽기 포스처를 유지합니다."
NOTICE_CWD_CHANGED = "작업 폴더를 바꾸고 백엔드를 다시 띄웠습니다: %s"
NOTICE_CWD_FAILED = "작업 폴더 변경에 실패했습니다: %s"
NOTICE_PROJECT_CHANGED = (
    "QGIS 프로젝트가 %s 으로 바뀌었습니다. 이전 프로젝트의 레이어 설명은 더 이상 "
    "맞지 않습니다."
)
# 다음 사용자 메시지 앞에 붙이는 한 줄. 모델이 들고 있는 레이어 지식이 무효가
# 됐음을 알려야 한다(설계 8).
PREFIX_PROJECT_CHANGED = "(프로젝트가 %s 으로 바뀌었습니다)"

# 헤더 상시 1줄(설계 8 "독과 터미널 세션 동시 사용" 행). 탐지할 방법이 없다.
# MCP 소켓이 단일 직렬이고 브리지가 둘이면 경합한다(F11).
TERMINAL_NOTICE = "터미널 Claude Code 와 동시에 QGIS 를 조작하지 마세요."

# 백엔드 기동 실패 전제조건 항목(설계 7-1 [2] 의 "기동 실패"). 로그인 상태를
# 탐지하지 않으므로(D07) 사용자에게 터미널 확인을 안내하는 것이 전부다.
PREREQ_BACKEND_DEAD = (
    "백엔드가 종료되었습니다 (rc=%s). 터미널에서 claude 를 한 번 실행해 "
    "로그인 상태를 확인하세요."
)

# 마커 판정 공지(설계 6-2). 성공은 전사에 한 줄, 실패는 바까지 띄운다.
NOTICE_MARKER_OK = "스킬 응답을 확인했습니다: %s"


def _mmss(seconds):
    """초를 mm:ss 로. 상태 바와 워치독 카운트다운이 쓴다."""
    try:
        total = int(max(0, seconds))
    except (TypeError, ValueError):
        return "--:--"
    return "%02d:%02d" % (total // 60, total % 60)


class UpwiseChatDock(QDockWidget):
    """채팅 독 하나. 백엔드 하나와 상태머신 하나를 소유한다(설계 2-1).

    시그널 하나만 밖으로 낸다.

        denial_retry_requested()  거부 재시도 바의 "허용하고 다시 요청".
            포스처 상승은 재spawn 이라 S5 가 받아서 처리한다. 받는 쪽이
            붙기 전에는 버튼이 비활성이다.
    """

    denial_retry_requested = pyqtSignal()

    def __init__(self, parent=None, backend_factory=None):
        """독을 만들고 위젯을 세운다. 백엔드는 띄우지 않는다.

        Args:
            parent: 보통 QGIS 메인 윈도우.
            backend_factory: callable() -> backend.process.BackendProcess.
                None 이면 입력 영역이 잠긴 채로 전사만 그린다. 백엔드 spawn
                시점은 첫 전송이다(설계 2-1: 플러그인 활성화만으로 띄우지 않는다).
        """
        super().__init__(DOCK_TITLE, parent)
        self.setObjectName(DOCK_OBJECT_NAME)
        # 독을 왼쪽/오른쪽에만 붙인다. 채팅은 세로로 긴 레이아웃이라
        # 상단/하단 영역에서는 전사 영역이 읽을 수 없게 눌린다.
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)

        self._backend_factory = backend_factory
        self.backend = None
        self.machine = machine_mod.TurnMachine(on_note=self._on_machine_note)

        self._stderr_tail = collections.deque(maxlen=STDERR_TAIL_MAX)
        self._stderr_count = 0
        self._cwd = ""
        self._gate = None
        self._denial_dismissed = set()
        # "계속 기다리기" 를 누른 시점의 침묵 길이. 그보다 120 s 더 조용해지면
        # 다시 띄운다. 영구 침묵 무시를 만들지 않는다(설계 4-5).
        self._silence_ack_s = 0.0
        self._cancel_elapsed_ms = None
        self._last_batch_n = 0
        # 상승 재전송(S5-4)이 다시 보낼 원문. 전송 시점에 기억한다.
        self._last_user_text = ""
        self._exclusion_dismissed = set()
        self._gate_blocked = False
        self._gate_failed_checks = []
        self._posture_name = posture_mod.POSTURE_R
        self._elevate_count = 0

        # S6. 전제조건 탐지 결과는 플러그인이 소유하고 독은 읽기만 한다
        # (독이 claude 실행 파일을 직접 찾지 않는 것과 같은 이유다).
        self._prereq = None
        # 어느 턴이 어느 프리셋에서 났는가. 마커 판정을 프리셋 턴에만 걸기
        # 위함이다 - 평소 대화에까지 "스킬이 호출되지 않았습니다" 를 붙이면
        # 안내가 소음이 된다.
        self._preset_turns = {}
        self._judged_turns = set()
        self._marker_verdicts = []
        self._marker_dismissed = set()
        # 백엔드 사망 종료코드. 전제조건 바의 "기동 실패" 항목이 읽는다.
        self._backend_rc = None

        self.body = self._build_body()
        self.setWidget(self.body)
        # 팔레트 적용은 위젯이 다 선 다음이다(설계 7-3). 내용 위젯에만 건다 -
        # QDockWidget 자체에 걸면 Qt 가 제목 줄까지 스타일시트로 그린다.
        self.theme_dark = theme_mod.apply_dock_theme(self.body)

        self._watchdog_timer = QTimer(self)
        self._watchdog_timer.setInterval(WATCHDOG_TICK_MS)
        self._watchdog_timer.timeout.connect(self._on_watchdog_tick)
        self._watchdog_timer.start()

        self._update_controls()
        self._update_status()
        # 프리셋은 비활성 + 이유 툴팁에서 시작한다. 전제조건이 붙기 전에
        # 누를 수 있게 두지 않는다(설계 7-1 [3]).
        self.refresh_prerequisites()

    # ------------------------------------------------------------------
    # 위젯 구성
    # ------------------------------------------------------------------

    def _build_body(self):
        """독 내용 위젯을 만들어 돌려준다."""
        body = QWidget(self)
        body.setObjectName("UpwiseChatDockBody")
        layout = QVBoxLayout(body)
        layout.setContentsMargins(
            LAYOUT_MARGIN, LAYOUT_MARGIN, LAYOUT_MARGIN, LAYOUT_MARGIN
        )
        layout.setSpacing(6)

        layout.addWidget(self._build_header(body))

        # [2] 전제조건 바와 [3] 프리셋 행(설계 7-1). 둘 다 헤더 바로 아래다.
        self.prereq_bar = PrereqBar(body)
        layout.addWidget(self.prereq_bar)

        self.preset_row = PresetRow(body)
        self.preset_row.preset_clicked.connect(self._on_preset_clicked)
        layout.addWidget(self.preset_row)

        self.chat_view = ChatView(body)
        self.chat_view.setObjectName("UpwiseChatTranscript")
        layout.addWidget(self.chat_view, 1)

        self.denial_bar = DenialRetryBar(body)
        self.denial_bar.retry_requested.connect(self._on_denial_retry)
        self.denial_bar.keep_denied.connect(self._on_denial_keep)
        layout.addWidget(self.denial_bar)

        # 제외 바는 거부 바와 따로 있다. 둘이 같은 턴에 날 수 있고 문구와
        # 버튼이 달라야 한다(설계 3-5 표).
        self.exclusion_bar = ExclusionNoticeBar(body)
        self.exclusion_bar.dismissed.connect(self._on_exclusion_dismissed)
        layout.addWidget(self.exclusion_bar)

        # 마커 안내 바(설계 6-2). 거부/제외와 다른 축이라 바를 따로 둔다 -
        # 여기서 막힌 것은 권한이 아니라 슬래시 명령의 해석(D02)이다.
        self.marker_bar = SkillMarkerBar(body)
        self.marker_bar.fallback_requested.connect(self._on_marker_fallback)
        self.marker_bar.dismissed.connect(self._on_marker_dismissed)
        layout.addWidget(self.marker_bar)

        # 프로젝트 전환 stale 바(설계 8). cwd 변경과 같은 재spawn 경로를 쓴다.
        self.stale_bar = StaleCwdBar(body)
        self.stale_bar.restart_requested.connect(self._on_stale_restart)
        self.stale_bar.dismissed.connect(self.stale_bar.hide_bar)
        layout.addWidget(self.stale_bar)

        layout.addWidget(self._build_input(body))
        layout.addWidget(self._build_status(body))
        return body

    def _build_header(self, parent):
        """[1] 헤더. 브랜드, 상태 칩과 권한 배지, 상시 경고 1줄(설계 7-1, 3-4, 8).

        경고 줄은 접거나 끄지 않는다. 터미널 세션과의 동시 사용은 탐지할 방법이
        없고(설계 8 표), 경합하면 MCP 소켓이 단일 직렬이라 둘 다 막힌다(F11).

        S7: 네이비 면(qss `#UpwiseChatHeader`) 위에 로고 타일 + 'UPWISE' 글자를
        왼쪽에 둔다. 설계 7-1 [1] 의 설정/진단 아이콘은 MVP 범위가 아니다
        (설정 UI 를 만들지 않는다, 설계 7-4 마지막 줄).
        """
        header = QWidget(parent)
        header.setObjectName("UpwiseChatHeader")
        outer = QVBoxLayout(header)
        outer.setContentsMargins(
            HEADER_PADDING, HEADER_PADDING, HEADER_PADDING, HEADER_PADDING
        )
        outer.setSpacing(2)

        chip_row = QWidget(header)
        row = QHBoxLayout(chip_row)
        row.setContentsMargins(0, 0, 0, 0)

        self.brand_link = BrandLink(chip_row)
        self.brand_link.clicked.connect(self._on_brand_clicked)
        row.addWidget(self.brand_link)

        self.chip_label = QLabel("모델 -  ·  도구 -  ·  MCP -", chip_row)
        self.chip_label.setObjectName("UpwiseChatChip")
        self.chip_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        row.addWidget(self.chip_label, 1)

        self.badge_label = QLabel(BADGE_UNKNOWN, chip_row)
        self.badge_label.setObjectName("UpwiseChatGateBadge")
        self.badge_label.setToolTip(
            "첫 턴의 init 에서 권한 점검 결과가 옵니다. 보내기 전에는 알 수 없습니다."
        )
        row.addWidget(self.badge_label)
        outer.addWidget(chip_row)

        self.terminal_notice_label = QLabel(TERMINAL_NOTICE, header)
        self.terminal_notice_label.setObjectName("UpwiseChatTerminalNotice")
        self.terminal_notice_label.setWordWrap(True)
        outer.addWidget(self.terminal_notice_label)
        return header

    def _build_input(self, parent):
        """[6] 입력 영역. 멀티라인 입력, 전송, 취소, cwd 표시(설계 7-1)."""
        area = QWidget(parent)
        layout = QVBoxLayout(area)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        self.input_edit = QPlainTextEdit(area)
        self.input_edit.setObjectName("UpwiseChatInput")
        self.input_edit.setPlaceholderText(PLACEHOLDER_NO_BACKEND)
        # 줄 높이에서 상한을 잡는다. 글꼴 크기를 px 로 고정하지 않기 위해
        # 폰트 메트릭에서 계산한다(설계 7-3).
        line_h = self.input_edit.fontMetrics().lineSpacing()
        self.input_edit.setMaximumHeight(line_h * INPUT_MAX_LINES + 12)
        self.input_edit.textChanged.connect(self._update_controls)
        layout.addWidget(self.input_edit)

        row = QWidget(area)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)

        # cwd 표시는 클릭 가능해야 한다(설계 7-1 [6], S5-3). 평평한 버튼으로
        # 둔다. QFileDialog 를 쓰지 않는 이유는 그것이 모달이고, 모달 팝업이
        # 자동화를 정지시키기 때문이다(설계 3-5 금지 목록의 취지).
        self.cwd_label = QPushButton(CWD_PREFIX + CWD_UNSET, row)
        self.cwd_label.setObjectName("UpwiseChatCwd")
        self.cwd_label.setFlat(True)
        self.cwd_label.setToolTip("클릭하면 작업 폴더를 바꿉니다(백엔드를 다시 띄웁니다)")
        self.cwd_label.clicked.connect(self._on_cwd_clicked)
        row_layout.addWidget(self.cwd_label, 1)

        self.send_button = QPushButton("전송", row)
        # 주 버튼. qss 가 이 이름으로 브랜드 오렌지를 건다(설계 7-3).
        self.send_button.setObjectName("UpwiseChatSendButton")
        self.send_button.setToolTip("Ctrl+Enter")
        # clicked 는 bool(checked) 를 넘긴다. send_message(text=...) 에 그대로
        # 연결하면 그 bool 이 보낼 텍스트 자리에 들어간다. 그래서 래퍼를 둔다.
        self.send_button.clicked.connect(self._on_send_clicked)
        row_layout.addWidget(self.send_button)

        self.cancel_button = QPushButton("취소", row)
        self.cancel_button.setToolTip(
            "턴을 중단하는 것이 아니라 백엔드를 재시작합니다. 맥락은 이어집니다."
        )
        self.cancel_button.clicked.connect(self.cancel)
        row_layout.addWidget(self.cancel_button)
        layout.addWidget(row)

        # cwd 인라인 편집 행(S5-3). 기본은 숨어 있고 cwd 표시를 누르면 열린다.
        # 대화상자를 띄우지 않으므로 떠 있는 동안에도 QGIS 조작이 된다.
        self.cwd_edit_row = QWidget(area)
        cwd_layout = QHBoxLayout(self.cwd_edit_row)
        cwd_layout.setContentsMargins(0, 0, 0, 0)
        self.cwd_edit = QLineEdit(self.cwd_edit_row)
        self.cwd_edit.setObjectName("UpwiseChatCwdEdit")
        self.cwd_edit.setPlaceholderText("폴더 경로를 붙여 넣고 적용을 누릅니다")
        self.cwd_edit.returnPressed.connect(self._on_cwd_apply)
        cwd_layout.addWidget(self.cwd_edit, 1)
        self.cwd_apply_button = QPushButton("적용", self.cwd_edit_row)
        self.cwd_apply_button.clicked.connect(self._on_cwd_apply)
        cwd_layout.addWidget(self.cwd_apply_button)
        self.cwd_cancel_button = QPushButton("취소", self.cwd_edit_row)
        self.cwd_cancel_button.clicked.connect(self._on_cwd_edit_cancel)
        cwd_layout.addWidget(self.cwd_cancel_button)
        self.cwd_edit_row.setVisible(False)
        layout.addWidget(self.cwd_edit_row)

        # Ctrl+Enter 전송. 입력 위젯 안에서만 듣는다.
        self._send_shortcut = QShortcut(QKeySequence("Ctrl+Return"), self.input_edit)
        self._send_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        self._send_shortcut.activated.connect(self.send_message)
        self._send_shortcut_enter = QShortcut(QKeySequence("Ctrl+Enter"), self.input_edit)
        self._send_shortcut_enter.setContext(Qt.WidgetWithChildrenShortcut)
        self._send_shortcut_enter.activated.connect(self.send_message)
        return area

    def _build_status(self, parent):
        """[7] 상태 바와 침묵 워치독 행(설계 7-1, 4-5)."""
        area = QWidget(parent)
        layout = QVBoxLayout(area)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        self.status_label = QLabel("", area)
        self.status_label.setObjectName("UpwiseChatStatus")
        self.status_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.status_label)

        self.watchdog_row = QWidget(area)
        row = QHBoxLayout(self.watchdog_row)
        row.setContentsMargins(0, 0, 0, 0)
        self.watchdog_label = QLabel("", self.watchdog_row)
        self.watchdog_label.setWordWrap(True)
        row.addWidget(self.watchdog_label, 1)
        self.wait_button = QPushButton("계속 기다리기", self.watchdog_row)
        self.wait_button.clicked.connect(self._on_keep_waiting)
        row.addWidget(self.wait_button)
        self.watchdog_cancel_button = QPushButton("취소", self.watchdog_row)
        self.watchdog_cancel_button.clicked.connect(self.cancel)
        row.addWidget(self.watchdog_cancel_button)
        self.watchdog_row.setVisible(False)
        layout.addWidget(self.watchdog_row)
        return area

    # ------------------------------------------------------------------
    # 백엔드 배선
    # ------------------------------------------------------------------

    def attach_backend(self, backend):
        """백엔드의 시그널 4개를 독에 연결한다.

        Args:
            backend: backend.process.BackendProcess.
        """
        self.backend = backend
        backend.events_drained.connect(self._on_events)
        backend.stderr_line.connect(self._on_stderr)
        backend.backend_died.connect(self._on_died)
        backend.gate_result.connect(self._on_gate)
        self.machine.note_starting()
        self._update_controls()
        self._update_status()

    def detach_backend(self):
        """시그널을 끊는다. 독을 버리거나 백엔드를 바꿀 때 쓴다."""
        backend = self.backend
        if backend is None:
            return
        for signal, slot in (
            (backend.events_drained, self._on_events),
            (backend.stderr_line, self._on_stderr),
            (backend.backend_died, self._on_died),
            (backend.gate_result, self._on_gate),
        ):
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                # 이미 끊긴 연결과 삭제된 수신자는 정리 경로의 정상 상황이다.
                pass

    def shutdown(self):
        """독을 버릴 때 호출한다. 백엔드를 트리 종료하고 타이머를 멈춘다.

        unload() 에서 백엔드까지 끝내는 것이 설계 7-1 의 요구다. 부모만 죽이면
        claude 가 띄운 MCP 브리지가 고아로 남는다(F11).
        """
        self._watchdog_timer.stop()
        backend = self.backend
        self.detach_backend()
        self.backend = None
        if backend is not None:
            try:
                backend.stop("dock_shutdown")
            except Exception:  # noqa: BLE001 - 정리 경로는 끝까지 진행해야 한다
                pass

    # ------------------------------------------------------------------
    # 사용자 동작
    # ------------------------------------------------------------------

    def _on_brand_clicked(self):
        """헤더 브랜드를 눌렀다. 기본 브라우저로 upwise.co.kr 을 연다(설계 7-1).

        QDesktopServices 를 쓰는 이유는 QGIS 안에 브라우저 위젯을 띄우지 않고
        모달도 만들지 않는 유일한 외부 링크 경로이기 때문이다(설계 3-5).

        Returns:
            bool: 운영체제가 처리를 받아들였는가.
        """
        return bool(QDesktopServices.openUrl(QUrl(theme_mod.BRAND_URL)))

    def _on_send_clicked(self):
        """전송 버튼. clicked 의 bool 인자를 삼키고 입력 위젯 내용을 보낸다."""
        self.send_message()

    def send_message(self, text=None):
        """입력을 보낸다. 턴 중에는 보내지 않는다(설계 2-4).

        Args:
            text: 보낼 문자열. None 이면 입력 위젯에서 가져온다.

        Returns:
            bool: 실제로 보냈는가.
        """
        body = self.input_edit.toPlainText() if text is None else text
        body = (body or "").strip()
        if not body:
            return False
        backend = self._ensure_backend()
        if backend is None:
            return False
        if backend.is_busy():
            return False
        if not backend.send(body):
            return False
        self._last_user_text = body
        self.machine.note_sent(body)
        # 이 턴이 프리셋에서 났는지 기억한다(설계 6-2 마커 판정의 대상 선별).
        # 버튼이 아니라 **보낸 문장**으로 판정한다 - 사용자가 버튼으로 넣은 뒤
        # 손으로 고쳐 보낼 수 있고(자동 전송은 하나뿐이다), 터미널 습관대로
        # 슬래시 명령을 직접 타이핑할 수도 있다.
        preset = detect_mod.preset_for_text(body)
        turn = self.machine.current_turn
        if preset and turn is not None:
            self._preset_turns[turn.turn_no] = preset
        # 사용자 말풍선은 전송 즉시 그린다. replay 이벤트는 렌더하지 않는다
        # (설계 4-2 user 행).
        self.chat_view.add_user_message(body)
        if text is None:
            self.input_edit.clear()
        self._update_controls()
        self._update_status()
        return True

    def cancel(self):
        """취소. 턴을 "취소됨" 으로 마감하고 백엔드를 재시작한다(설계 2-5).

        Returns:
            bool: 재spawn 성공 여부. 백엔드가 없으면 False.
        """
        backend = self.backend
        if backend is None:
            return False
        t0 = time.perf_counter()
        self.machine.note_cancelled()
        self.chat_view.add_notice("요청을 취소했습니다. 백엔드를 재시작합니다.")
        ok = backend.request_cancel()
        if ok:
            self.machine.note_starting()
        else:
            self.machine.note_died(-1, "cancel respawn failed")
            self.chat_view.add_notice("백엔드 재시작에 실패했습니다.")
        self._cancel_elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self._silence_ack_s = 0.0
        self.watchdog_row.setVisible(False)
        self._update_controls()
        self._update_status()
        return ok

    def set_cwd(self, path):
        """cwd 표시를 갱신하고 프리셋 활성 상태를 다시 계산한다(설계 7-1 [6], 6-3).

        폴더 판정이 cwd 기준이므로(설계 6-3 마지막 줄) 표시만 바꾸고 끝내면
        프리셋이 이전 폴더 기준으로 남는다.
        """
        self._cwd = str(path or "")
        self.cwd_label.setText(CWD_PREFIX + (self._cwd or CWD_UNSET))
        self.cwd_label.setToolTip(self._cwd)
        if self._prereq is not None:
            self._prereq.set_cwd(self._cwd)
        self.refresh_prerequisites()

    def set_denial_retry_enabled(self, enabled):
        """거부 재시도 버튼을 쓸 수 있게 한다. 상승 배선(S5)이 부른다."""
        self.denial_bar.set_retry_enabled(enabled)

    # ------------------------------------------------------------------
    # 전제조건과 프리셋 (S6)
    # ------------------------------------------------------------------

    def set_prerequisites(self, prereq):
        """탐지 결과 객체를 붙인다(설계 6-4).

        독이 직접 탐지하지 않는다. claude 경로 탐색과 설정 읽기는 플러그인이
        하고 독은 그 결과를 읽어 바와 버튼에 반영한다.

        Args:
            prereq: backend.detect.Prerequisites. None 이면 프리셋이 전부
                비활성인 채로 둔다 - 전제조건을 모르는데 누를 수 있게 두지 않는다.
        """
        self._prereq = prereq
        if prereq is not None and self._cwd:
            prereq.set_cwd(self._cwd)
        self.refresh_prerequisites()

    def refresh_prerequisites(self):
        """전제조건 바와 프리셋 행을 지금 상태로 다시 그린다(설계 7-1 [2], [3]).

        Returns:
            int: 활성인 프리셋 버튼 수.
        """
        prereq = self._prereq
        items = []
        if self._backend_rc is not None:
            items.append(("backend", PREREQ_BACKEND_DEAD % self._backend_rc))
        if prereq is None:
            self.prereq_bar.show_items(items)
            self.preset_row.set_states(
                [(p, False, "전제조건 탐지가 아직 붙지 않았습니다")
                 for p in detect_mod.PRESET_ORDER]
            )
            return 0
        items.extend(prereq.unmet_items())
        self.prereq_bar.show_items(items)
        return self.preset_row.set_states(prereq.preset_states())

    def _note_init_detect(self):
        """첫 init 원본으로 툴킷/MCP/스킬 탐지를 채운다(설계 6-4).

        게이트 요약에는 plugins/skills 가 없어서 원본이 필요하다. 원본은
        백엔드가 보관하고 있고(process.last_init_event) 이 함수는 gate_result
        슬롯 안에서 불린다 - init 1건당 시그널을 새로 만들지 않기 위함이다.
        """
        prereq = self._prereq
        backend = self.backend
        if prereq is None or backend is None:
            return False
        init_event = getattr(backend, "last_init_event", None)
        if not isinstance(init_event, dict):
            return False
        prereq.note_init(init_event)
        self._on_machine_note("prereq_detect", str(prereq.summary()))
        self.refresh_prerequisites()
        return True

    def _on_preset_clicked(self, preset):
        """프리셋 버튼(설계 6-1).

        입력 박스에 슬래시 명령을 넣고 포커스를 준다. 자동 전송은
        detect.PRESET_AUTOSEND 에 있는 것만 한다(connect-check 하나). 전송이
        거절되면(턴 중) 넣은 문자열을 그대로 남긴다 - 사용자가 턴이 끝난 뒤
        그대로 보낼 수 있어야 한다.

        Args:
            preset: 프리셋 이름.

        Returns:
            bool: 자동 전송까지 갔는가.
        """
        command = detect_mod.slash_command(preset)
        self.input_edit.setPlainText(command)
        self.input_edit.setFocus()
        # 커서를 끝으로 보낸다. 대상 인자를 이어 적는 것이 기본 사용법이다.
        cursor = self.input_edit.textCursor()
        cursor.movePosition(cursor.End)
        self.input_edit.setTextCursor(cursor)
        self._update_controls()
        if preset not in detect_mod.PRESET_AUTOSEND:
            return False
        return bool(self.send_message())

    def _judge_preset_turns(self):
        """닫힌 프리셋 턴의 스킬 마커를 판정한다(설계 6-2).

        판정식은 detect.MARKER_RE 하나다(사전 명세). result 로 닫힌 턴만 본다 -
        취소되거나 재spawn 으로 버려진 턴은 응답이 끝까지 오지 않았으므로
        "마커가 없다" 를 호출 실패로 읽으면 틀린다.

        0.1.4(V28-A48): 판정 입력이 turn.first_text_line() 에서
        turn.assistant_text() 로 바뀌었다. 판정 대상이 result 로 닫힌 턴이라는
        **범위는 그대로**이고, 그 턴 안에서 보는 **텍스트 범위만** 첫 줄에서
        응답 전체로 넓혔다. 모델이 스킬 호출 전에 안내 문장을 먼저 말하면
        마커가 중간 줄에 찍혀 거짓 음성이 났다.

        Returns:
            int: 이번 호출에서 새로 판정한 턴 수.
        """
        judged = 0
        for turn in self.machine.turns:
            if turn.turn_no in self._judged_turns:
                continue
            preset = self._preset_turns.get(turn.turn_no)
            if not preset or turn.closed_by != "result":
                continue
            self._judged_turns.add(turn.turn_no)
            judged += 1
            body = turn.assistant_text()
            ok, name, version, line_no = detect_mod.find_marker(body)
            self._marker_verdicts.append((turn.turn_no, preset, ok, name, version))
            # 첫 2회를 포함해 전부 진단 로그에 남긴다(설계 6-2 는 첫 2회를
            # 요구한다. D02 종결 자료가 되도록 회차 번호를 함께 적는다).
            # 0.1.4: 매칭된 마커 원문과 그것이 몇 번째 줄이었는지를 남긴다.
            # 거짓 음성이 "마커가 없었다" 인지 "중간 줄이어서 못 봤다" 인지
            # 로그만으로 가를 수 있어야 한다. 첫 줄도 함께 남겨 둔다 - 안내
            # 문장이 먼저 왔는지가 그 줄에서 바로 읽힌다.
            matched = ("[%s %s]" % (name, version)) if ok else "(none)"
            lines_n = len(body.splitlines())
            self._on_machine_note(
                "preset_marker",
                "n=%d turn=%d preset=%s ok=%s marker=%s matched=%s "
                "line=%d/%d first_line=%r"
                % (len(self._marker_verdicts), turn.turn_no, preset, ok,
                   name or "(none)", matched, line_no, lines_n,
                   (body or "").split("\n", 1)[0][:80]),
            )
            if ok:
                if name and name != preset:
                    # 판정식에는 넣지 않는다. 다른 스킬이 응답한 것은 사실로
                    # 남겨 두고 사용자에게는 호출된 스킬 이름을 보여 준다.
                    self._on_machine_note(
                        "preset_marker_name_mismatch",
                        "preset=%s marker=%s" % (preset, name))
                self.chat_view.add_notice(NOTICE_MARKER_OK % (name or preset))
                self.marker_bar.hide_bar()
            elif turn.turn_no not in self._marker_dismissed:
                self.marker_bar.show_miss(turn.turn_no, preset)
        return judged

    def _on_marker_fallback(self, preset):
        """[자연어로 다시 요청]. 스킬 이름과 출력 규칙을 풀어 보낸다(설계 6-2)."""
        turn_no = self.marker_bar.turn_no()
        if turn_no is not None:
            self._marker_dismissed.add(turn_no)
        prompt = detect_mod.fallback_prompt(preset)
        return bool(self.send_message(prompt))

    def _on_marker_dismissed(self):
        """마커 안내 바를 닫았다. 그 턴은 다시 띄우지 않는다."""
        turn_no = self.marker_bar.turn_no()
        if turn_no is not None:
            self._marker_dismissed.add(turn_no)
        self.marker_bar.hide_bar()

    # ------------------------------------------------------------------
    # cwd 변경 (S5-3)
    # ------------------------------------------------------------------

    def _on_cwd_clicked(self):
        """cwd 표시를 누르면 인라인 편집 행을 연다."""
        self.cwd_edit.setText(self._cwd)
        self.cwd_edit_row.setVisible(True)
        self.cwd_edit.setFocus()

    def _on_cwd_edit_cancel(self):
        """편집 행을 닫는다. 값은 바꾸지 않는다."""
        self.cwd_edit_row.setVisible(False)

    def _on_cwd_apply(self):
        """cwd 를 바꾸고 백엔드를 다시 띄운다(S5-3).

        cwd 는 모델의 파일 접근 범위와 CLAUDE.md 자동 탐색 범위를 동시에 정하므로
        (설계 2-3) 돌아가는 프로세스에 적용할 방법이 없다. 재spawn 이다. 맥락은
        `--resume` 가 가져온다(D01 PASS).

        Returns:
            bool: 실제로 바뀌었는가.
        """
        new_cwd = (self.cwd_edit.text() or "").strip()
        self.cwd_edit_row.setVisible(False)
        if not new_cwd or new_cwd == self._cwd:
            return False
        backend = self.backend
        if backend is None:
            # 아직 백엔드가 없으면 표시만 바꾼다. 첫 spawn 이 이 값을 쓴다.
            self.set_cwd(new_cwd)
            return True
        ok = backend.restart_with_cwd(new_cwd)
        if ok:
            self.set_cwd(new_cwd)
            self.machine.note_starting()
            self.chat_view.add_notice(NOTICE_CWD_CHANGED % new_cwd)
        else:
            self.chat_view.add_notice(NOTICE_CWD_FAILED % new_cwd)
        self._update_controls()
        self._update_status()
        return bool(ok)

    def note_project_changed(self, project_name, new_cwd):
        """QGIS 프로젝트가 바뀌었다(설계 8, S5-3).

        세 가지를 한다. 백엔드를 **죽이지 않는다** - 턴 중일 수 있고, 재시작
        시점은 사용자가 고른다.
            1. 전사에 경고를 남긴다. 모델이 들고 있는 레이어 지식이 무효가 됐다.
            2. 다음 사용자 메시지 앞에 붙일 한 줄을 백엔드에 예약한다.
            3. cwd 가 달라졌으면 stale 바를 띄운다(자동 재시작 없음).

        Args:
            project_name: 바뀐 프로젝트 이름.
            new_cwd: 새 프로젝트 기준 작업 폴더.

        Returns:
            bool: stale 바를 띄웠는가.
        """
        name = str(project_name or "(이름 없음)")
        self.chat_view.add_notice(NOTICE_PROJECT_CHANGED % name)
        backend = self.backend
        if backend is not None:
            backend.queue_notice_prefix(PREFIX_PROJECT_CHANGED % name)
        new_cwd = str(new_cwd or "")
        if not new_cwd or new_cwd == self._cwd:
            return False
        self.stale_bar.show_stale(name, new_cwd)
        return True

    def _on_stale_restart(self, new_cwd):
        """stale 바의 "새 폴더로 재시작". cwd 변경과 같은 경로를 쓴다(S5-3)."""
        if not new_cwd:
            return False
        self.cwd_edit.setText(str(new_cwd))
        return self._on_cwd_apply()

    # ------------------------------------------------------------------
    # 포스처 상승 재전송 (S5-4)
    # ------------------------------------------------------------------

    def elevate_and_resend(self):
        """포스처를 올려 재spawn 하고 같은 요청을 1회 다시 보낸다(S5-4).

        개별 도구 호출을 플러그인이 주입할 수는 없다. 그래서 재시도는 **원래
        사용자 의도를 W 포스처로 1회 재전송**하는 것이다(설계 3-5).

        이 경로가 D23 의 측정 대상이다. 상승이 거부를 뒤집는 것(D05-a)과
        `--resume` 가 맥락을 가져오는 것(D01)은 각각 실측됐고, 둘을 겹친 것이
        여기서 처음 돈다.

        Returns:
            bool: 상승과 재전송이 둘 다 됐는가.
        """
        backend = self.backend
        if backend is None:
            return False
        text = self._last_user_text
        spec = posture_mod.posture_spec(posture_mod.POSTURE_W)
        ok = backend.elevate(spec.name, spec.tools, spec.disallowed_tools)
        if not ok:
            self.chat_view.add_notice(NOTICE_ELEVATE_FAILED)
            self._update_controls()
            return False
        self._posture_name = spec.name
        self._elevate_count += 1
        self.machine.note_starting()
        self.chat_view.add_notice(NOTICE_ELEVATED)
        if not text:
            # 보낼 원문이 없으면 상승만 하고 끝낸다. 지어낸 요청을 보내지 않는다.
            self._update_controls()
            self._update_status()
            return False
        sent = self.send_message(posture_mod.ELEVATION_NOTICE + "\n" + text)
        # 재전송문이 아니라 원문을 기억한다. 두 번 올리면 안내문이 겹친다.
        self._last_user_text = text
        self._update_controls()
        self._update_status()
        return bool(sent)

    # ------------------------------------------------------------------
    # 백엔드 시그널 처리
    # ------------------------------------------------------------------

    def _on_events(self, batch):
        """50 ms 드레인 배치 하나를 먹고 한 번 그린다(설계 2-6).

        이벤트 1건당 갱신하지 않는다. 배치 하나에 렌더 1회가 이 구조의 전부다.
        """
        self._last_batch_n = len(batch or ())
        self.machine.feed_batch(batch or ())
        self.chat_view.sync(self.machine)
        # 마커 판정은 전사 동기화 뒤에 한다. 공지 한 줄이 그 턴 글 뒤에 와야
        # 읽는 순서가 맞다(설계 6-2).
        self._judge_preset_turns()
        self._update_denial_bar()
        self._update_chip()
        self._update_controls()
        self._update_status()

    def _on_stderr(self, raw):
        """stderr 한 줄. 진단에만 쌓고 전사에 섞지 않는다(설계 4-2)."""
        self._stderr_tail.append(raw)
        self._stderr_count += 1
        self._update_status()

    def _on_died(self, rc, tail):
        """백엔드 사망. 전사는 유지하고 공지 카드를 남긴다(설계 8)."""
        self.machine.note_died(rc, tail)
        text = "백엔드가 종료되었습니다 (rc=%s)." % rc
        if tail:
            text += "\nstderr 꼬리:\n" + tail
        self.chat_view.add_notice(text)
        # 전제조건 바의 "기동 실패" 항목(설계 7-1 [2]). 다시 뜨면 지운다.
        self._backend_rc = rc
        self.refresh_prerequisites()
        self._update_controls()
        self._update_status()

    def _on_gate(self, result):
        """기동 자기점검 판정을 배지에 반영하고, 깨지면 입력을 막는다(S5-1).

        설계 3-4 는 "하나라도 어긋나면 입력 박스를 열지 않는다" 를 요구한다.
        S4 는 배지와 툴팁까지만 했고 게이트가 깨져도 입력이 열려 있었다.
        여기가 그 인계 항목을 닫는 자리다. 실제 전송 차단은 두 겹이다 -
        백엔드의 send() 가 거부하고(process.gate_blocked) UI 도 버튼을 끈다.
        """
        self._gate = result
        # init 이 왔다는 신호이기도 하다. 탐지를 먼저 채워서 전제조건 바와
        # 프리셋이 같은 틱에 갱신되게 한다(설계 6-4).
        self._note_init_detect()
        if not isinstance(result, dict):
            return
        if result.get("ok"):
            self._gate_blocked = False
            self._gate_failed_checks = []
            self.badge_label.setText(
                "권한 확인 (%s · %s · 도구 %d)"
                % (result.get("permission_mode") or "-", self._posture_name,
                   len(result.get("tools") or ()))
            )
            self.badge_label.setToolTip("기동 자기점검 전 항목 통과")
        else:
            failed = [
                i.get("check")
                for i in (result.get("items") or ())
                if i.get("status") != "PASS"
            ]
            self._gate_failed_checks = failed
            self._gate_blocked = True
            self.badge_label.setText("권한 점검 실패")
            self.badge_label.setToolTip("어긋난 항목: " + ", ".join(str(f) for f in failed))
            joined = ", ".join(str(f) for f in failed)
            # 재시작을 예약했는지는 백엔드가 안다. 추측하지 않고 읽는다.
            retrying = bool(getattr(self.backend, "gate_restart_pending", False))
            self.chat_view.add_notice(
                (NOTICE_GATE_BLOCKED if retrying else NOTICE_GATE_BLOCKED_FINAL) % joined
            )
        self._update_controls()
        self._update_status()

    def _on_machine_note(self, tag, detail=""):
        """상태머신 진단 한 줄을 백엔드 로그북에 넘긴다.

        로그북은 spawn 마다 새로 열리므로 호출 시점에 찾는다. 없으면 버린다.
        """
        backend = self.backend
        book = getattr(backend, "logbook", None) if backend is not None else None
        if book is not None:
            book.diag("ui_" + str(tag), detail)

    # ------------------------------------------------------------------
    # 거부 재시도 바
    # ------------------------------------------------------------------

    def _update_denial_bar(self):
        """거부가 있는 가장 최근 턴에 바 하나를 붙인다(설계 3-5).

        거부마다 쌓지 않고 턴당 하나다. 사용자가 닫은 턴은 다시 띄우지 않는다.
        """
        target = None
        for turn in reversed(self.machine.turns):
            if turn.denials:
                target = turn
                break
        if target is None or target.turn_no in self._denial_dismissed:
            self.denial_bar.hide_bar()
        else:
            self.denial_bar.show_attempts(target.turn_no, target.denials)
        self._update_exclusion_bar()

    def _update_exclusion_bar(self):
        """제외가 있는 가장 최근 턴에 안내 바 하나를 붙인다(설계 3-5 표).

        거부 바와 독립이다. 한 턴에 거부와 제외가 같이 날 수 있고, 그때 두 바가
        같이 보여야 사용자가 "허용으로 풀리는 것" 과 "안 풀리는 것" 을 구분한다.
        """
        target = None
        for turn in reversed(self.machine.turns):
            if turn.exclusions:
                target = turn
                break
        if target is None or target.turn_no in self._exclusion_dismissed:
            self.exclusion_bar.hide_bar()
            return
        self.exclusion_bar.show_exclusions(target.turn_no, target.exclusions)

    def _on_exclusion_dismissed(self):
        """제외 안내 바를 닫았다. 그 턴은 다시 띄우지 않는다."""
        turn_no = self.exclusion_bar.turn_no()
        if turn_no is not None:
            self._exclusion_dismissed.add(turn_no)
        else:
            for turn in self.machine.turns:
                if turn.exclusions:
                    self._exclusion_dismissed.add(turn.turn_no)
        self.exclusion_bar.hide_bar()

    def _on_denial_retry(self):
        """"허용하고 다시 요청". 상승 경로는 S5 가 받는다."""
        turn_no = self.denial_bar.turn_no()
        self._dismiss_denial(turn_no)
        self.denial_retry_requested.emit()

    def _on_denial_keep(self):
        """"거부 유지". 바를 닫고 그 턴을 다시 띄우지 않는다."""
        self._dismiss_denial(self.denial_bar.turn_no())

    def _dismiss_denial(self, turn_no):
        """닫은 턴을 기억한다. 턴 번호를 모르면 지금 열린 턴들을 전부 닫는다."""
        if turn_no is not None:
            self._denial_dismissed.add(turn_no)
        else:
            for turn in self.machine.turns:
                if turn.denials:
                    self._denial_dismissed.add(turn.turn_no)
        self.machine.awaiting_approval = False
        self.denial_bar.hide_bar()

    # ------------------------------------------------------------------
    # 워치독 (설계 4-5)
    # ------------------------------------------------------------------

    def _on_watchdog_tick(self):
        """1초마다 침묵을 다시 보고 카운트다운을 쓴다.

        총 경과로 끊지 않는다. 같은 전처리 과업 실측이 141.7 s 라 총 경과
        기준은 정상 작업을 죽인다(설계 4-5).
        """
        # 게이트 실패 재시작이 끝나면 차단을 푼다(S5-1).
        # 풀지 않으면 교착이다. 새 백엔드의 init 은 사용자가 한 턴을 보낸 뒤에만
        # 오는데(D06 FAIL) 입력이 막혀 있으면 보낼 수가 없다. 그래서 재시작이
        # 끝난 시점에 "권한 미확인" 으로 되돌리고 첫 턴에서 다시 게이트를 돈다.
        # 전용 시그널을 만들지 않고 이 1초 틱에서 동기화한다.
        backend = self.backend
        if self._gate_blocked and backend is not None \
                and not getattr(backend, "gate_blocked", False) \
                and backend.is_running():
            self._gate_blocked = False
            self.badge_label.setText(BADGE_UNKNOWN)
            self.badge_label.setToolTip(
                "백엔드를 다시 띄웠습니다. 다음 턴의 init 에서 다시 점검합니다."
            )
            self._update_controls()

        # 백엔드가 다시 살아났으면 "기동 실패" 항목을 내린다. 재시작 경로가
        # 여럿이라(사망 자동 재시작, 취소, cwd 변경, 상승) 각 경로에서 지우는
        # 대신 이 1초 틱에서 한 번만 동기화한다.
        if self._backend_rc is not None and backend is not None \
                and backend.is_running():
            self._backend_rc = None
            self.refresh_prerequisites()

        turn = self.machine.current_turn
        if turn is None:
            self.watchdog_row.setVisible(False)
            self._silence_ack_s = 0.0
            self._update_status()
            return
        status, value = self.machine.watchdog()
        if status == "too_long":
            self.watchdog_label.setText(
                "턴이 %s 를 넘었습니다. 취소(백엔드 재시작)를 권합니다."
                % _mmss(machine_mod.TURN_TOTAL_MAX_S)
            )
            self.watchdog_row.setVisible(True)
        elif status == "silent" and value > self._silence_ack_s + machine_mod.SILENCE_WARN_S:
            elapsed = time.time() - (turn.started_ts or time.time())
            remaining = machine_mod.TURN_TOTAL_MAX_S - elapsed
            self.watchdog_label.setText(
                "응답이 없습니다 (침묵 %s). 총 상한까지 %s 남았습니다."
                % (_mmss(value), _mmss(remaining))
            )
            self.watchdog_row.setVisible(True)
        else:
            self.watchdog_row.setVisible(False)
        self._update_status()

    def _on_keep_waiting(self):
        """"계속 기다리기". 지금 침묵 길이를 기준으로 다시 120 s 를 센다."""
        _, value = self.machine.watchdog()
        self._silence_ack_s = float(value)
        self.watchdog_row.setVisible(False)

    # ------------------------------------------------------------------
    # 표시 갱신
    # ------------------------------------------------------------------

    def _ensure_backend(self):
        """백엔드가 없으면 공장으로 만들어 띄운다(설계 2-1: 첫 전송에서 spawn).

        Returns:
            BackendProcess or None
        """
        if self.backend is not None:
            if not self.backend.is_running():
                self.backend.start()
            return self.backend
        if self._backend_factory is None:
            return None
        backend = self._backend_factory()
        if backend is None:
            return None
        self.attach_backend(backend)
        if not backend.is_running():
            backend.start()
        return backend

    def _update_chip(self):
        """상태 칩. init 요약에서 모델/도구 수/MCP 를 가져온다(설계 4-2)."""
        chip = self.machine.chip
        if not chip:
            return
        servers = chip.get("mcp_servers") or ()
        self.chip_label.setText(
            "모델 %s  ·  도구 %d  ·  MCP %s"
            % (chip.get("model") or "-", chip.get("tools_n") or 0,
               ", ".join(servers) if servers else "없음")
        )

    def _update_controls(self):
        """전송/취소 버튼과 입력 placeholder 를 상태에 맞춘다.

        턴 중에는 전송을 막는다. 큐에 2개를 쌓지 않는다(설계 2-4).
        """
        has_factory = self._backend_factory is not None
        backend = self.backend
        busy = bool(backend is not None and backend.is_busy())
        alive = bool(backend is not None and backend.is_running())
        # 게이트 차단은 백엔드 쪽 사실이 우선이다. 독의 플래그는 백엔드가 아직
        # 없을 때(재시작 중)를 메우는 용도다.
        blocked = bool(getattr(backend, "gate_blocked", False)) or self._gate_blocked
        can_type = (has_factory or backend is not None) and not blocked
        self.input_edit.setEnabled(can_type)
        if blocked:
            placeholder = PLACEHOLDER_GATE_BLOCKED
        elif can_type:
            placeholder = PLACEHOLDER_READY
        else:
            placeholder = PLACEHOLDER_NO_BACKEND
        self.input_edit.setPlaceholderText(placeholder)
        has_text = bool(self.input_edit.toPlainText().strip())
        self.send_button.setEnabled(can_type and has_text and not busy)
        self.cancel_button.setEnabled(alive or busy)
        self.cwd_label.setEnabled(not busy)

    def _update_status(self):
        """[7] 상태 바 한 줄."""
        turn = self.machine.current_turn
        parts = ["상태 %s" % self.machine.state]
        if turn is not None:
            elapsed = time.time() - (turn.started_ts or time.time())
            parts.append("턴 %d 경과 %s" % (turn.turn_no, _mmss(elapsed)))
            parts.append("침묵 %s" % _mmss(self.machine.silence_s()))
        else:
            closed = self.machine.last_closed_turn
            if closed is not None and closed.started_ts and closed.ended_ts:
                parts.append(
                    "직전 턴 %d %s" % (closed.turn_no, _mmss(closed.ended_ts - closed.started_ts))
                )
        stage = self.machine.tool_stage()
        if stage:
            parts.append("도구 %s" % stage)
        if self._stderr_count:
            parts.append("stderr %d줄" % self._stderr_count)
        if self.machine.rate_limit_warnings:
            # 수치 표시는 비범위이고 경고 한 줄은 범위 안이다(설계 4-2, 9).
            parts.append(self.machine.rate_limit_warnings[-1])
        self.status_label.setText("  ·  ".join(parts))

    # ------------------------------------------------------------------
    # 조회 (검증 하네스가 읽는다)
    # ------------------------------------------------------------------

    def stats(self):
        """독 상태 요약. 완료 판정의 근거를 한 dict 로 모은다."""
        out = {
            "state": self.machine.state,
            "badge": self.badge_label.text(),
            "status": self.status_label.text(),
            "chip": self.chip_label.text(),
            # isVisible() 은 조상이 숨어 있으면 거짓이다. 여기서 알고 싶은 것은
            # "띄우기로 했는가" 이므로 isHidden() 의 반대를 쓴다.
            "denial_visible": not self.denial_bar.isHidden(),
            "denial_turn": self.denial_bar.turn_no(),
            "denial_text": self.denial_bar.label_text(),
            "exclusion_visible": not self.exclusion_bar.isHidden(),
            "exclusion_turn": self.exclusion_bar.turn_no(),
            "exclusion_text": self.exclusion_bar.label_text(),
            "gate_blocked": bool(self._gate_blocked),
            "gate_failed_checks": list(self._gate_failed_checks),
            "input_enabled": self.input_edit.isEnabled(),
            "placeholder": self.input_edit.placeholderText(),
            "posture": self._posture_name,
            "elevate_count": self._elevate_count,
            "cwd": self._cwd,
            "cwd_edit_visible": not self.cwd_edit_row.isHidden(),
            "stale_visible": not self.stale_bar.isHidden(),
            "stale_text": self.stale_bar.label_text(),
            "stale_target": self.stale_bar.target(),
            "watchdog_visible": not self.watchdog_row.isHidden(),
            "watchdog_text": self.watchdog_label.text(),
            "send_enabled": self.send_button.isEnabled(),
            "cancel_enabled": self.cancel_button.isEnabled(),
            "stderr_lines": self._stderr_count,
            "cancel_ms": self._cancel_elapsed_ms,
            "last_batch": self._last_batch_n,
            # S6
            "prereq_visible": not self.prereq_bar.isHidden(),
            "prereq_codes": list(self.prereq_bar.codes()),
            "prereq_text": self.prereq_bar.label_text(),
            "preset_states": self.preset_row.states(),
            "preset_turns": dict(self._preset_turns),
            "marker_visible": not self.marker_bar.isHidden(),
            "marker_turn": self.marker_bar.turn_no(),
            "marker_preset": self.marker_bar.preset(),
            "marker_text": self.marker_bar.label_text(),
            "marker_verdicts": list(self._marker_verdicts),
            "terminal_notice": self.terminal_notice_label.text(),
            "terminal_notice_hidden": self.terminal_notice_label.isHidden(),
            "input_text": self.input_edit.toPlainText(),
            # S7 브랜딩
            "theme_dark": bool(self.theme_dark),
            "brand_wordmark": self.brand_link.wordmark_text(),
            "brand_tooltip": self.brand_link.toolTip(),
            "dock_qss_len": len(self.body.styleSheet()),
        }
        out.update(self.chat_view.stats())
        return out
