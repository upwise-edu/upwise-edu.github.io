"""공공 API 수집 전담 MCP stdio 서버 (0.2.0, 설계 docs/2 2-3 결정 E4).

왜 별도 프로세스인가
    수집 1회는 바깥 HTTP GET 을 해야 한다. 독은 셸을 노출하지 않고 `WebFetch`
    도 노출하지 않으므로(설계 docs/2 2-3) 모델이 직접 네트워크를 칠 수단이
    없다. 그래서 플러그인이 두 번째 MCP 서버를 띄워 **egress 를 자기가 소유**
    한다. 모델은 "무엇을 어디서 받을지" 만 고르고, 돌아온 경로를
    `add_vector_layer` 에 넘긴다.

키 불변식 (이 파일의 존재 이유)
    API 키는 모델 컨텍스트에 들어가지 않는다. 한 번 들어가면 모델 제공자
    서버, CLI 자신의 세션 저장소, 우리 jsonl, 전사 네 곳에 동시에 남고 앞의
    둘은 지울 수 없다(장부 V28-A52 실측). 그래서
        * 키는 argv 에도 `--mcp-config` 에도 환경변수에도 담기지 않는다.
        * 이 서버가 QGIS 설정 INI 를 configparser 로 **직접** 읽는다.
        * 도구 결과와 로그의 URL 은 키 자리를 마스킹한다.
    env 로 받는 것은 INI 경로와 키 접두사뿐이다(설계 docs/2 5-3 K6).

stdlib 전용인 이유
    백엔드가 자식 환경에서 PYTHON 오염 4키를 제거하고(0.1.2, 장부 V28-30) 그
    정화가 손자인 이 서버까지 상속된다. `PYTHONPATH` 가 없는 환경에서 자기
    모듈을 찾아야 하므로 **단일 파일**로 두고 `-I` 로 띄운다. 패키지 상대
    import 도 쓰지 않는다 - `-I` 는 sys.path 에 스크립트 폴더만 남긴다.

인터프리터
    이 파일을 띄우는 command 는 `<QGIS_ROOT>/apps/Python312/python.exe` 계열
    **절대경로**다. QGIS 런처의 `bin/python3.exe` 는 `-I` 아래에서 표준
    라이브러리를 못 찾아 즉사한다(장부 V28-P18). 해석과 부트 프로브는
    backend/detect.resolve_collect_python 이 한다.

노출 도구 3종 (설계 docs/2 4-1. 폴링 도구는 두지 않는다 - 동기 반환이다)
    list_datasets      무엇을 받을 수 있나
    describe_dataset   그 데이터셋의 필수 인자가 무엇인가
    collect            서버가 받고 저장하고 요약을 돌려준다

쓰기 경로를 모델이 고르지 못한다
    저장 폴더는 서버가 정하고 돌려준다. 모델은 경로 인자를 받지 못한다
    (더미 서버 G3 패턴과 같다). 그래서 "파일이 생겼는가" 가 모델 발화가
    아니라 디스크 사실로 판정된다.

설계 정본: docs/2.collect_feature_design_v1.md 2, 4, 5
"""

import configparser
import csv
import json
import os
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

PROTOCOL_FALLBACK = "2025-06-18"

# 서버 이름. 플래그 조립 쪽(backend/posture.COLLECT_MCP_SERVER_NAME)과 같은
# 문자열이어야 도구 이름 접두사가 allowlist 와 맞는다.
SERVER_NAME = "upwise_collect"
SERVER_VERSION = "0.2.0"

# --------------------------------------------------------------- 환경변수 계약
# 전부 플러그인이 per-server env 블록으로 넣는다. **키는 여기 없다.**
ENV_SETTINGS_INI = "UPWISE_COLLECT_SETTINGS_INI"
ENV_KEY_PREFIX = "UPWISE_COLLECT_KEY_PREFIX"
ENV_WORKSPACE = "UPWISE_COLLECT_WORKSPACE"
ENV_REGISTRY = "UPWISE_COLLECT_REGISTRY"
ENV_LOG = "UPWISE_COLLECT_LOG"

# 산출물 고정 하위 폴더. cwd 가 아니라 **workspace 아래**다 - cwd 는 사용자의
# QGIS 프로젝트 폴더일 수 있고(장부 G8) 거기에 수집물을 쏟지 않는다.
COLLECTED_SUBDIR = "collected"
LOGS_SUBDIR = "_logs"

# 설정 키(QgsSettings 경로 표기). 서버는 INI 에서 이 경로를 찾는다.
SETTING_ENDPOINT_OVERRIDE = "upwise_chat/collect/endpoint_override"

# 한도 기본값(설계 docs/2 4-5). 측정값이 아니라 보수적으로 고른 설계 결정이다.
# 모델 루프가 키 쿼터와 디스크를 소모하는 경로를 서버가 막는 유일한 가드다.
LIMIT_PAGES = 50
LIMIT_BYTES = 50 * 1024 * 1024
LIMIT_SECONDS = 120.0
LIMIT_CALLS_PER_SESSION = 20

# HTTP 재시도(설계 docs/2 4-5). 401/403 은 재시도하지 않는다 - 키 거부를
# 반복해도 결과가 바뀌지 않고 쿼터만 쓴다.
RETRY_STATUS = (429, 500, 502, 503, 504)
RETRY_MAX = 3
RETRY_BACKOFF_S = (1.0, 2.0, 4.0)
HTTP_TIMEOUT_S = 60.0

# 타일 재귀 분할 상한(V-World WFS 는 maxFeatures 1000 상한만 있고 페이지
# 파라미터가 없다 - 강의 러너가 쓴 방식과 같다). 깊이를 제한해야 응답이
# 상한에 계속 걸리는 영역에서 무한 분할하지 않는다.
TILE_MAX_DEPTH = 3

# 키 형식 검사(설계 docs/2 5-3 단서 1). QSettings 는 INI 에서 특수문자를
# 인코딩하므로 디코딩이 애매할 수 있다. 공공 API 키는 영숫자와 하이픈이고,
# 그 밖이면 **추측하지 않고** 구조화 오류로 끝낸다.
KEY_RE = re.compile(r"^[A-Za-z0-9_-]{8,128}$")

# 레다크션 최소 길이(설계 docs/2 5-4). 짧은 값을 치환하면 본문이 잠식된다.
REDACT_MIN_LEN = 12
REDACT_TOKEN = "***REDACTED***"


# ---------------------------------------------------------------------- 로깅
class ServerLog:
    """파일 전용 서버 로그. stderr 를 쓰지 않는다.

    stderr 는 claude CLI 가 읽어 독의 진단 패널로 흘리므로, 수집 서버의 수십
    줄짜리 프로토콜 기록이 그 채널을 메운다. 그래서 파일로만 남긴다.
    """

    def __init__(self, path):
        """로그 파일 경로를 잡는다. 열기는 쓸 때 한다.

        Args:
            path: 로그 파일 절대경로. 빈 값이면 아무 것도 쓰지 않는다.
        """
        self.path = str(path or "")

    def write(self, kind, detail=""):
        """한 줄 즉시 flush. 로깅 실패가 서버를 죽이지 않는다."""
        if not self.path:
            return
        line = "%s\t%s\t%s" % (
            time.strftime("%Y-%m-%dT%H:%M:%S"), kind,
            str(detail).replace("\r", " ").replace("\n", " | "))
        try:
            parent = os.path.dirname(self.path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
                fh.flush()
        except Exception:  # noqa: BLE001 - 로깅 실패가 수집을 막지 않는다
            pass


class CollectCsvLog:
    """수집 1건마다 한 줄 쌓는 CSV (저장소 ALWAYS LOG 규칙).

    위치는 `<workspace>/collected/_logs/collect_<시각>.csv` 다. 항목마다 즉시
    flush 하므로 중단되어도 완료분과 실패분이 남는다.
    """

    COLUMNS = ["ts", "dataset", "params", "pages", "bytes", "features",
               "crs", "status", "elapsed_s", "url_masked", "error"]

    def __init__(self, root):
        """로그 폴더를 만들고 파일 경로를 정한다.

        Args:
            root: `<workspace>/collected` 폴더.
        """
        self.dir = os.path.join(str(root), LOGS_SUBDIR)
        self.path = os.path.join(
            self.dir, "collect_%s.csv" % time.strftime("%y%m%d_%H%M%S"))

    def row(self, **fields):
        """한 줄 기록. 헤더는 파일이 비었을 때만 쓴다."""
        try:
            os.makedirs(self.dir, exist_ok=True)
            fresh = (not os.path.exists(self.path)
                     or os.path.getsize(self.path) == 0)
            with open(self.path, "a", encoding="utf-8", newline="") as fh:
                writer = csv.writer(fh)
                if fresh:
                    writer.writerow(self.COLUMNS)
                writer.writerow([str(fields.get(c, "")) for c in self.COLUMNS])
                fh.flush()
        except Exception:  # noqa: BLE001 - 로깅 실패가 수집을 막지 않는다
            pass


# ------------------------------------------------------------------ 설정 읽기
def qsettings_unescape(raw):
    """QSettings INI 값에서 따옴표와 퍼센트 인코딩을 되돌린다.

    QSettings 는 공백이나 특수문자가 든 값을 따옴표로 싸고 비 ASCII 를
    `%XX` 또는 `%UXXXX` 로 적는다. 알 수 없는 이스케이프는 **추측하지 않고**
    예외로 올린다(설계 docs/2 5-3 단서 1).

    Args:
        raw: INI 에서 읽은 날 문자열.

    Returns:
        str: 되돌린 값.

    Raises:
        ValueError: 해석할 수 없는 이스케이프가 있을 때.
    """
    text = (raw or "").strip()
    if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
        text = text[1:-1]
    if "%" not in text:
        return text
    out = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch != "%":
            out.append(ch)
            i += 1
            continue
        tail = text[i + 1:i + 2].upper()
        if tail == "U" and re.match(r"^[0-9A-Fa-f]{4}", text[i + 2:i + 6] or ""):
            out.append(chr(int(text[i + 2:i + 6], 16)))
            i += 6
            continue
        if re.match(r"^[0-9A-Fa-f]{2}", text[i + 1:i + 3] or ""):
            out.append(chr(int(text[i + 1:i + 3], 16)))
            i += 3
            continue
        raise ValueError("unknown QSettings escape at %d" % i)
    return "".join(out)


def read_setting(ini_path, dotted_key):
    """QGIS 설정 INI 에서 값 하나를 읽는다.

    QSettings 는 `a/b/c` 경로를 INI 의 `[a]` 섹션 + `b\\c` 옵션으로 적는다.
    사본이 하나뿐인 자리이므로 서버가 직접 읽는다 - 키를 env 나 argv 로
    옮기면 복제가 생긴다(설계 docs/2 5-3).

    Args:
        ini_path: `QGIS3.ini` 절대경로.
        dotted_key: `upwise_chat/keys/vworld` 같은 설정 경로.

    Returns:
        tuple: (값 또는 "", 근거 문자열)
    """
    if not ini_path or not os.path.isfile(ini_path):
        return "", "settings ini not found"
    parser = configparser.RawConfigParser(strict=False)
    # QSettings 는 옵션 이름의 대소문자를 보존한다. configparser 기본
    # optionxform 은 소문자로 접으므로 비교를 깨뜨린다.
    parser.optionxform = str
    try:
        with open(ini_path, "r", encoding="utf-8", errors="replace") as fh:
            parser.read_file(fh)
    except Exception as exc:  # noqa: BLE001 - 설정 파싱 실패는 사유로 돌려준다
        return "", "settings ini unreadable: %r" % (exc,)
    parts = [p for p in str(dotted_key).split("/") if p]
    if len(parts) < 2:
        return "", "setting key needs at least one group"
    section = parts[0]
    rest = parts[1:]
    # QSettings 표기와 사람이 손으로 적은 표기 양쪽을 본다.
    wanted = ("\\".join(rest), "/".join(rest))
    for sec in parser.sections():
        if sec.lower() != section.lower():
            continue
        for option in parser.options(sec):
            if option.lower() in tuple(w.lower() for w in wanted):
                try:
                    return qsettings_unescape(parser.get(sec, option)), "ini"
                except ValueError as exc:
                    return "", "value unescape failed: %s" % exc
    return "", "setting absent"


def load_registry(path):
    """엔드포인트 레지스트리 JSON 을 읽는다.

    모델이 URL 을 만들지 않는다. 레지스트리 항목을 고른다(설계 docs/2 4-2).

    Args:
        path: 레지스트리 JSON 경로. 빈 값이면 이 파일 옆의 기본 파일.

    Returns:
        tuple: (dataset_id -> 항목 dict, 근거 문자열)
    """
    target = str(path or "")
    if not target:
        target = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "collect_registry.json")
    if not os.path.isfile(target):
        return {}, "registry not found: %s" % target
    try:
        with open(target, "r", encoding="utf-8") as fh:
            body = json.load(fh)
    except Exception as exc:  # noqa: BLE001 - 레지스트리 오류는 사유로 돌려준다
        return {}, "registry unreadable: %r" % (exc,)
    out = {}
    for entry in body.get("datasets") or ():
        if isinstance(entry, dict) and entry.get("id"):
            out[str(entry["id"])] = entry
    return out, "registry %s (n=%d)" % (target, len(out))


# -------------------------------------------------------------------- 유틸
def mask(text, secret):
    """문자열에서 키 값을 마스킹한다(설계 docs/2 5-4).

    정규식으로 "키처럼 보이는 것" 을 찾지 않는다 - 오탐이 본문을 깨뜨린다.
    설정에 저장된 값과 **완전 일치하는 부분문자열**만 바꾼다.
    """
    body = str(text or "")
    if secret and len(secret) >= REDACT_MIN_LEN:
        body = body.replace(secret, REDACT_TOKEN)
    return body


def parse_bbox(value):
    """bbox 인자를 (minx, miny, maxx, maxy) 로 정규화한다.

    Args:
        value: 길이 4 리스트, 또는 쉼표로 이은 문자열.

    Returns:
        tuple: 실수 4개.

    Raises:
        ValueError: 개수나 형식이 맞지 않거나 최소/최대가 뒤집혔을 때.
    """
    if isinstance(value, (list, tuple)):
        items = list(value)
    else:
        items = [p for p in str(value or "").replace(" ", "").split(",") if p]
    if len(items) != 4:
        raise ValueError("bbox needs 4 numbers (minx,miny,maxx,maxy)")
    nums = [float(x) for x in items]
    if nums[0] >= nums[2] or nums[1] >= nums[3]:
        raise ValueError("bbox min must be smaller than max")
    return tuple(nums)


def inside(root, path):
    """path 가 root 아래인가. 경로 탈출을 막는 접두 검사다.

    서버가 경로를 정하므로 모델이 깨뜨릴 입구는 없지만, 레지스트리 id 가
    경로 조각으로 쓰이므로 한 겹 더 본다.
    """
    root_abs = os.path.normcase(os.path.abspath(str(root)))
    path_abs = os.path.normcase(os.path.abspath(str(path)))
    return path_abs == root_abs or path_abs.startswith(root_abs + os.sep)


def safe_slug(text):
    """경로 조각으로 쓸 수 있게 영숫자와 하이픈만 남긴다."""
    return re.sub(r"[^A-Za-z0-9._-]", "_", str(text or "x"))[:64] or "x"


def write_atomic(path, payload):
    """`.part` 로 쓰고 rename 한다(설계 docs/2 4-3 원자성).

    수집 중 트리 kill 이 들어오면 반쪽 파일이 남는데, 그것을 완성본으로
    오인하면 다음 단계가 조용히 틀린다. 그래서 완료 시점에만 최종 이름이 된다.

    Args:
        path: 최종 파일 경로.
        payload: 쓸 바이트.

    Returns:
        int: 쓴 바이트 수.
    """
    tmp = path + ".part"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp, "wb") as fh:
        fh.write(payload)
        fh.flush()
        os.fsync(fh.fileno())
    if os.path.exists(path):
        os.remove(path)
    os.replace(tmp, path)
    return len(payload)


# --------------------------------------------------------------------- HTTP
def http_get(url, timeout=HTTP_TIMEOUT_S):
    """GET 1회. 응답 바이트를 그대로 돌려준다.

    `urllib` 기본 핸들러가 `HTTP_PROXY`/`HTTPS_PROXY` 를 존중한다(기관망
    대응, 설계 docs/2 4-5). 실패는 원문을 그대로 올린다 - 추정 진단을 쓰지
    않는다.

    Args:
        url: 전체 URL(키 포함. 호출자가 로그에 넣을 때 마스킹한다).
        timeout: 초.

    Returns:
        tuple: (상태 코드, 응답 바이트, content-type)

    Raises:
        urllib.error.URLError: 연결 자체가 실패했을 때.
    """
    req = urllib.request.Request(url, headers={"User-Agent": "upwise-chat-collect/0.2.0"})
    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return resp.getcode(), resp.read(), resp.headers.get("Content-Type", "")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(), exc.headers.get("Content-Type", "") if exc.headers else ""


def http_get_retry(url, log, secret):
    """재시도를 포함한 GET(설계 docs/2 4-5).

    429/5xx 는 지수 백오프 3회. 401/403 은 재시도하지 않고 분류해 올린다.

    Returns:
        tuple: (상태 코드 또는 0, 바이트, 사유 문자열)
    """
    last = ""
    for attempt in range(RETRY_MAX):
        try:
            code, body, _ctype = http_get(url)
        except (urllib.error.URLError, socket.timeout, ssl.SSLError, OSError) as exc:
            last = "transport: %r" % (exc,)
            log.write("http_error", "%s %s" % (mask(url, secret), last))
            if attempt + 1 >= RETRY_MAX:
                return 0, b"", last
            time.sleep(RETRY_BACKOFF_S[min(attempt, len(RETRY_BACKOFF_S) - 1)])
            continue
        log.write("http", "code=%s bytes=%d url=%s"
                  % (code, len(body), mask(url, secret)))
        if code in (401, 403):
            return code, body, "키가 거부됐습니다(HTTP %d)" % code
        if code in RETRY_STATUS and attempt + 1 < RETRY_MAX:
            last = "HTTP %d" % code
            time.sleep(RETRY_BACKOFF_S[min(attempt, len(RETRY_BACKOFF_S) - 1)])
            continue
        if code != 200:
            return code, body, "HTTP %d" % code
        return code, body, ""
    return 0, b"", last or "retries exhausted"


# ------------------------------------------------------------------ 수집 본체
class Collector:
    """수집 1회를 수행하고 요약을 계산한다.

    요약 수치를 서버가 계산하는 것이 요점이다(설계 docs/2 4-6). 모델이 세면
    전사의 숫자에 재현 경로가 없다.
    """

    def __init__(self, env, log):
        """환경 계약을 읽고 레지스트리를 적재한다.

        Args:
            env: os.environ 과 같은 매핑.
            log: ServerLog.
        """
        self.log = log
        self.ini_path = env.get(ENV_SETTINGS_INI, "")
        self.key_prefix = env.get(ENV_KEY_PREFIX, "upwise_chat/keys/")
        self.workspace = env.get(ENV_WORKSPACE, "") or os.getcwd()
        self.root = os.path.join(self.workspace, COLLECTED_SUBDIR)
        self.registry, self.registry_why = load_registry(env.get(ENV_REGISTRY, ""))
        self.csv_log = CollectCsvLog(self.root)
        self.calls = 0
        # 엔드포인트 오버라이드는 **설정에서만** 온다. 모델 인자로 받지 않는다.
        # 하네스가 로컬 http 서버로 전 경로를 재게 하는 유일한 입구다.
        self.endpoint_override, self.override_why = read_setting(
            self.ini_path, SETTING_ENDPOINT_OVERRIDE)
        self.log.write("init", "registry=%s workspace=%s override=%s(%s)"
                       % (self.registry_why, self.workspace,
                          bool(self.endpoint_override), self.override_why))

    # ------------------------------------------------------------------
    # 조회 도구
    # ------------------------------------------------------------------

    def list_datasets(self):
        """노출 데이터셋 목록. 키가 설정됐는지도 함께 알려준다.

        Returns:
            dict: 도구 결과 본문.
        """
        rows = []
        for ds_id in sorted(self.registry):
            entry = self.registry[ds_id]
            key_ok = True
            if entry.get("auth") != "none":
                secret, _why = self.read_key(entry.get("provider", ""))
                key_ok = bool(secret)
            rows.append({
                "id": ds_id,
                "provider": entry.get("provider", ""),
                "title": entry.get("title", ""),
                "geometry": entry.get("geometry", ""),
                "format": entry.get("format", ""),
                "default_crs": entry.get("default_crs", ""),
                "key_configured": key_ok,
                "notes": entry.get("notes", ""),
            })
        return {"datasets": rows, "n": len(rows),
                "output_root": self.root,
                "limits": {"pages": LIMIT_PAGES, "bytes": LIMIT_BYTES,
                           "seconds": LIMIT_SECONDS,
                           "calls_per_session": LIMIT_CALLS_PER_SESSION}}

    def describe_dataset(self, dataset_id):
        """데이터셋 하나의 인자 화이트리스트와 제약.

        Returns:
            dict: 도구 결과 본문.

        Raises:
            ToolError: 모르는 id 일 때.
        """
        entry = self.registry.get(str(dataset_id or ""))
        if entry is None:
            raise ToolError("unknown dataset id: %r (use list_datasets)"
                            % (dataset_id,))
        secret, why = self.read_key(entry.get("provider", ""))
        return {
            "id": entry.get("id"),
            "provider": entry.get("provider"),
            "title": entry.get("title", ""),
            "params": entry.get("params") or {},
            "required": entry.get("required") or [],
            "paging": entry.get("paging", "none"),
            "page_limit": entry.get("page_limit"),
            "format": entry.get("format", ""),
            "default_crs": entry.get("default_crs", ""),
            "notes": entry.get("notes", ""),
            # 키 **값** 은 돌려주지 않는다. 설정됐는지와 사유만 준다.
            "key_configured": bool(secret),
            "key_why": "" if secret else why,
        }

    # ------------------------------------------------------------------
    # 키
    # ------------------------------------------------------------------

    def read_key(self, provider):
        """제공자 키를 설정 INI 에서 읽는다. 값은 호출자 안에서만 쓴다.

        Args:
            provider: `vworld` 같은 제공자 이름.

        Returns:
            tuple: (키 또는 "", 사유 문자열)
        """
        if not provider:
            return "", "no provider"
        value, why = read_setting(self.ini_path,
                                  self.key_prefix + str(provider))
        if not value:
            return "", why
        if not KEY_RE.match(value):
            # 추측하지 않는다. 형식을 못 읽었으면 거기서 끝낸다.
            return "", "키 형식을 읽지 못했습니다(설정 값의 인코딩 확인 필요)"
        return value, "ini"

    # ------------------------------------------------------------------
    # 수집
    # ------------------------------------------------------------------

    def build_url(self, entry, secret, bbox, max_features, crs):
        """레지스트리 템플릿과 허용 인자로 URL 을 만든다.

        모델은 이 함수에 **URL 을 넘기지 못한다.** base 와 고정 파라미터는
        레지스트리가, 가변 파라미터는 화이트리스트가 정한다.

        Returns:
            str: 전체 URL(키 포함).
        """
        base = self.endpoint_override or entry.get("base_url", "")
        params = dict(entry.get("fixed_params") or {})
        if entry.get("typename"):
            params[entry.get("typename_param", "typename")] = entry["typename"]
        if entry.get("auth") == "key_query":
            params[entry.get("key_param", "key")] = secret
        if bbox is not None:
            params[entry.get("bbox_param", "bbox")] = \
                "%.8f,%.8f,%.8f,%.8f" % bbox
        if crs:
            params[entry.get("crs_param", "srsName")] = crs
        if max_features:
            params[entry.get("max_features_param", "maxFeatures")] = max_features
        return base + ("&" if "?" in base else "?") + urllib.parse.urlencode(params)

    def collect(self, dataset_id, bbox=None, max_features=None, crs=None):
        """수집 1회. 받고 저장하고 합치고 요약한다.

        Args:
            dataset_id: 레지스트리 id.
            bbox: minx,miny,maxx,maxy (데이터셋이 요구하면 필수).
            max_features: 페이지당 상한. 레지스트리 상한을 넘기지 못한다.
            crs: 요청 좌표계. 비우면 레지스트리 default_crs.

        Returns:
            dict: 저장 경로와 요약 수치.

        Raises:
            ToolError: 인자나 전제조건이 어긋났을 때.
        """
        started = time.time()
        if self.calls >= LIMIT_CALLS_PER_SESSION:
            raise ToolError("세션당 수집 호출 상한 %d 회를 넘었습니다"
                            % LIMIT_CALLS_PER_SESSION)
        entry = self.registry.get(str(dataset_id or ""))
        if entry is None:
            raise ToolError("unknown dataset id: %r (use list_datasets)"
                            % (dataset_id,))
        secret = ""
        if entry.get("auth") != "none":
            secret, why = self.read_key(entry.get("provider", ""))
            if not secret:
                raise ToolError(
                    "제공자 %s 의 API 키가 설정되지 않았습니다 (%s). QGIS 설정 "
                    "%s%s 에 키를 저장하세요."
                    % (entry.get("provider"), why, self.key_prefix,
                       entry.get("provider")))
        for name in entry.get("required") or ():
            if name == "bbox" and bbox is None:
                raise ToolError("이 데이터셋은 bbox 인자가 필수입니다")
        try:
            box = parse_bbox(bbox) if bbox is not None else None
        except ValueError as exc:
            raise ToolError("bbox 형식 오류: %s" % exc)
        cap = int(entry.get("page_limit") or 1000)
        try:
            per_page = int(max_features) if max_features else cap
        except (TypeError, ValueError):
            raise ToolError("max_features 는 정수여야 합니다")
        per_page = max(1, min(per_page, cap))
        want_crs = str(crs or entry.get("default_crs") or "")
        allowed_crs = entry.get("allowed_crs") or ()
        if allowed_crs and want_crs not in allowed_crs:
            raise ToolError("이 데이터셋이 받는 좌표계는 %s 입니다"
                            % ", ".join(allowed_crs))

        self.calls += 1
        stamp = time.strftime("%Y%m%d_%H%M%S")
        out_dir = os.path.join(self.root, safe_slug(entry.get("provider")),
                               safe_slug(entry.get("id")), stamp)
        if not inside(self.root, out_dir):
            raise ToolError("출력 경로가 작업 폴더를 벗어났습니다")
        os.makedirs(out_dir, exist_ok=True)

        state = {"pages": 0, "bytes": 0, "features": {}, "incomplete": False,
                 "stop_reason": "", "errors": [], "urls": []}
        if entry.get("paging") == "tile_subdivide" and box is not None:
            self._tile(entry, secret, box, per_page, want_crs, out_dir, state,
                       started, depth=0)
        else:
            self._one(entry, secret, box, per_page, want_crs, out_dir, state,
                      started)

        features = list(state["features"].values())
        merged_path, merged_bytes = self._merge(out_dir, features, want_crs)
        summary = self._summarize(entry, features, want_crs, box, per_page,
                                  state, out_dir, merged_path, merged_bytes,
                                  started)
        write_atomic(os.path.join(out_dir, "collect_meta.json"),
                     json.dumps(summary["meta"], ensure_ascii=False,
                                indent=2).encode("utf-8"))
        self.csv_log.row(
            ts=time.strftime("%Y-%m-%d %H:%M:%S"), dataset=entry.get("id"),
            params="bbox=%s max_features=%s crs=%s" % (box, per_page, want_crs),
            pages=state["pages"], bytes=state["bytes"],
            features=len(features), crs=want_crs,
            status="INCOMPLETE" if state["incomplete"] else "OK",
            elapsed_s="%.3f" % (time.time() - started),
            url_masked=(state["urls"] or [""])[0],
            error=" | ".join(state["errors"])[:400])
        self.log.write("collect_done", json.dumps(summary["result"],
                                                  ensure_ascii=False)[:1500])
        return summary["result"]

    def _one(self, entry, secret, box, per_page, crs, out_dir, state, started):
        """페이지 1장을 받아 원본 그대로 저장한다.

        Returns:
            int: 이 응답의 피처 수.
        """
        if self._over_limit(state, started):
            return 0
        url = self.build_url(entry, secret, box, per_page, crs)
        masked = mask(url, secret)
        state["urls"].append(masked)
        code, body, why = http_get_retry(url, self.log, secret)
        if why or code != 200:
            state["incomplete"] = True
            state["errors"].append("%s (%s)" % (why or "HTTP %s" % code, masked))
            return 0
        state["pages"] += 1
        # 원본 바이트를 그대로 남긴다. 합본은 파생물로 따로 둔다
        # (저장소 데이터 원본성 규칙).
        ext = "json" if "json" in str(entry.get("format", "")) else "txt"
        page_name = "page_%04d.%s" % (state["pages"], ext)
        state["bytes"] += write_atomic(os.path.join(out_dir, page_name), body)
        got = 0
        try:
            payload = json.loads(body.decode("utf-8", "replace"))
        except ValueError:
            state["incomplete"] = True
            state["errors"].append("응답이 JSON 이 아닙니다: %s" % page_name)
            return 0
        for feat in payload.get("features") or ():
            if not isinstance(feat, dict):
                continue
            fid = feat.get("id") or json.dumps(feat.get("properties"),
                                              sort_keys=True, ensure_ascii=False)
            state["features"][fid] = feat
            got += 1
        return got

    def _tile(self, entry, secret, box, per_page, crs, out_dir, state, started,
              depth):
        """상한에 걸린 타일을 2x2 로 재귀 분할한다.

        V-World WFS 는 페이지 파라미터 없이 maxFeatures 상한만 있다. 한 요청이
        상한을 꽉 채우면 잘린 것이므로 영역을 쪼개 다시 받는다(강의 러너가 쓴
        방식과 같은 보정이다).
        """
        got = self._one(entry, secret, box, per_page, crs, out_dir, state,
                        started)
        if got < per_page or depth >= TILE_MAX_DEPTH:
            if got >= per_page and depth >= TILE_MAX_DEPTH:
                state["incomplete"] = True
                state["errors"].append("타일 분할 상한(depth=%d)에서 멈췄습니다"
                                       % TILE_MAX_DEPTH)
            return
        minx, miny, maxx, maxy = box
        midx = (minx + maxx) / 2.0
        midy = (miny + maxy) / 2.0
        for sub in ((minx, miny, midx, midy), (midx, miny, maxx, midy),
                    (minx, midy, midx, maxy), (midx, midy, maxx, maxy)):
            if self._over_limit(state, started):
                return
            self._tile(entry, secret, sub, per_page, crs, out_dir, state,
                       started, depth + 1)

    def _over_limit(self, state, started):
        """한도를 넘었는가. 넘으면 부분 저장 상태로 멈춘다.

        부분 수집도 버리지 않고 저장하고 `incomplete=true` 를 적는다
        (저장소 데이터 원본성 규칙).
        """
        if state["pages"] >= LIMIT_PAGES:
            state["stop_reason"] = "pages>=%d" % LIMIT_PAGES
        elif state["bytes"] >= LIMIT_BYTES:
            state["stop_reason"] = "bytes>=%d" % LIMIT_BYTES
        elif time.time() - started >= LIMIT_SECONDS:
            state["stop_reason"] = "elapsed>=%.0fs" % LIMIT_SECONDS
        else:
            return False
        state["incomplete"] = True
        if state["stop_reason"] not in state["errors"]:
            state["errors"].append(state["stop_reason"])
        return True

    def _merge(self, out_dir, features, crs):
        """합본 GeoJSON 을 쓴다. 원본 페이지는 덮지 않는다.

        좌표계는 **받은 그대로**다. 서버가 재투영하지 않는다(설계 docs/2 4-4).
        EPSG 를 레거시 `crs` 멤버로 명시해 QGIS 가 원본 좌표계로 적재하게 한다.

        Returns:
            tuple: (합본 경로, 바이트 수)
        """
        urn = ""
        if crs.upper().startswith("EPSG:"):
            urn = "urn:ogc:def:crs:EPSG::" + crs.split(":", 1)[1]
        doc = {"type": "FeatureCollection", "features": features}
        if urn:
            doc["crs"] = {"type": "name", "properties": {"name": urn}}
        path = os.path.join(out_dir, "merged.geojson")
        n = write_atomic(path, json.dumps(doc, ensure_ascii=False).encode("utf-8"))
        return path, n

    def _summarize(self, entry, features, crs, box, per_page, state, out_dir,
                   merged_path, merged_bytes, started):
        """요약 수치를 서버가 계산한다(설계 docs/2 4-6).

        Returns:
            dict: result(도구 결과)와 meta(사이드카) 두 묶음.
        """
        fields = []
        for feat in features[:200]:
            for name in (feat.get("properties") or {}):
                if name not in fields:
                    fields.append(name)
        bbox_out = None
        for feat in features:
            for x, y in iter_coords((feat.get("geometry") or {}).get("coordinates")):
                if bbox_out is None:
                    bbox_out = [x, y, x, y]
                else:
                    bbox_out[0] = min(bbox_out[0], x)
                    bbox_out[1] = min(bbox_out[1], y)
                    bbox_out[2] = max(bbox_out[2], x)
                    bbox_out[3] = max(bbox_out[3], y)
        result = {
            "dataset": entry.get("id"),
            "title": entry.get("title", ""),
            "saved_dir": out_dir,
            "layer_path": merged_path,
            "pages": state["pages"],
            "features": len(features),
            "fields": fields,
            "bbox": bbox_out,
            "crs": crs,
            "bytes_raw": state["bytes"],
            "bytes_merged": merged_bytes,
            "incomplete": bool(state["incomplete"]),
            "stop_reason": state["stop_reason"],
            "errors": state["errors"][:5],
            "elapsed_s": round(time.time() - started, 3),
            "load_hint": ("add_vector_layer 에 layer_path 를 그대로 넘기세요. "
                          "좌표계는 %s 입니다." % crs),
        }
        meta = dict(result)
        meta.update({
            "requested_bbox": list(box) if box else None,
            "max_features": per_page,
            "provider": entry.get("provider"),
            "url_masked": (state["urls"] or [""])[0],
            "requested_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "plugin_version": SERVER_VERSION,
            "endpoint_override": bool(self.endpoint_override),
        })
        return {"result": result, "meta": meta}


def iter_coords(node):
    """GeoJSON 좌표 트리에서 (x, y) 쌍을 모두 꺼낸다.

    BBOX 를 서버가 계산해야 하므로(설계 docs/2 4-6) 중첩 깊이를 가정하지 않고
    훑는다.
    """
    if not isinstance(node, (list, tuple)) or not node:
        return
    if isinstance(node[0], (int, float)) and len(node) >= 2:
        yield float(node[0]), float(node[1])
        return
    for child in node:
        for pair in iter_coords(child):
            yield pair


class ToolError(Exception):
    """도구 결과로 돌려줄 구조화 오류. 스택을 모델에 보내지 않는다."""


# ---------------------------------------------------------------- MCP 프로토콜
TOOLS = [
    # description 은 모델이 읽는 데이터다. 절차의 대부분이 여기 들어 있어
    # 스킬이 없어도 기능이 동작한다(설계 docs/2 6-1 P-C 안전망).
    {
        "name": "list_datasets",
        "description": ("List the public datasets this plugin can collect, with "
                        "whether the provider API key is configured. Call this "
                        "first. Returns no secrets."),
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "describe_dataset",
        "description": ("Describe one dataset: which arguments you may pass, "
                        "which are required, the paging mode and the coordinate "
                        "reference system. Ask the user for any missing "
                        "argument instead of guessing a default."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "dataset_id": {"type": "string",
                               "description": "id from list_datasets"},
            },
            "required": ["dataset_id"],
        },
    },
    {
        "name": "collect",
        "description": ("Download one dataset into the plugin workspace and "
                        "return the saved file path plus a summary (pages, "
                        "feature count, field names, bbox, CRS, bytes, whether "
                        "the result is incomplete). The server picks the output "
                        "path; you cannot pass one. Pass the returned "
                        "layer_path to add_vector_layer. Use the returned "
                        "numbers verbatim; do not recount."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "dataset_id": {"type": "string",
                               "description": "id from list_datasets"},
                "bbox": {"type": "string",
                         "description": ("minx,miny,maxx,maxy in the dataset "
                                         "CRS (lon/lat for EPSG:4326)")},
                "max_features": {"type": "integer",
                                 "description": "per-request cap, clamped by the server"},
                "crs": {"type": "string",
                        "description": "request CRS, defaults to the dataset default"},
            },
            "required": ["dataset_id"],
        },
    },
]


def send(obj, log):
    """JSON-RPC 한 줄 송신. 개행은 \\n 고정이다."""
    body = json.dumps(obj, ensure_ascii=False)
    log.write("SEND", body[:1200])
    sys.stdout.write(body + "\n")
    sys.stdout.flush()


def tool_result(rid, payload, is_error=False):
    """MCP tools/call 응답 한 건. 본문은 JSON 텍스트 블록 하나다."""
    text = payload if isinstance(payload, str) else json.dumps(
        payload, ensure_ascii=False, indent=2)
    return {"jsonrpc": "2.0", "id": rid,
            "result": {"content": [{"type": "text", "text": text}],
                       "isError": bool(is_error)}}


def call_tool(collector, name, args):
    """도구 1건 실행. 결과 본문을 돌려준다.

    Returns:
        tuple: (본문, 오류인가)
    """
    args = args or {}
    try:
        if name == "list_datasets":
            return collector.list_datasets(), False
        if name == "describe_dataset":
            return collector.describe_dataset(args.get("dataset_id")), False
        if name == "collect":
            return collector.collect(
                args.get("dataset_id"), bbox=args.get("bbox"),
                max_features=args.get("max_features"),
                crs=args.get("crs")), False
        return {"error": "unknown tool: %s" % name}, True
    except ToolError as exc:
        return {"error": str(exc)}, True
    except Exception as exc:  # noqa: BLE001 - 서버가 죽으면 세션이 degraded 된다
        collector.log.write("tool_exception", "%s %r" % (name, exc))
        return {"error": "수집 중 오류: %r" % (exc,)}, True


def handle(req, collector, log):
    """요청 1건 처리. 알림이면 None 을 돌려준다."""
    method = req.get("method", "")
    rid = req.get("id")

    if method == "initialize":
        params = req.get("params") or {}
        ver = params.get("protocolVersion") or PROTOCOL_FALLBACK
        return {"jsonrpc": "2.0", "id": rid,
                "result": {"protocolVersion": ver,
                           "capabilities": {"tools": {"listChanged": False}},
                           "serverInfo": {"name": SERVER_NAME,
                                          "version": SERVER_VERSION}}}
    if method in ("notifications/initialized", "initialized"):
        return None
    if method == "ping":
        return {"jsonrpc": "2.0", "id": rid, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": rid, "result": {"tools": TOOLS}}
    if method == "tools/call":
        params = req.get("params") or {}
        payload, is_err = call_tool(collector, params.get("name"),
                                    params.get("arguments"))
        return tool_result(rid, payload, is_err)
    if method in ("resources/list", "prompts/list"):
        key = "resources" if method.startswith("resources") else "prompts"
        return {"jsonrpc": "2.0", "id": rid, "result": {key: []}}
    if rid is None:
        return None
    log.write("unknown_method", method)
    return {"jsonrpc": "2.0", "id": rid,
            "error": {"code": -32601, "message": "method not found: %s" % method}}


def main():
    """stdin 의 JSON-RPC 줄을 끝까지 처리한다."""
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
    sys.stdin.reconfigure(encoding="utf-8")
    log = ServerLog(os.environ.get(ENV_LOG, ""))
    log.write("START", "pid=%d python=%s" % (os.getpid(), sys.executable))
    collector = Collector(os.environ, log)
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        log.write("RECV", line[:1200])
        try:
            req = json.loads(line)
        except ValueError:
            continue
        try:
            resp = handle(req, collector, log)
        except Exception as exc:  # noqa: BLE001 - 핸들러 예외로 서버가 죽지 않는다
            log.write("HANDLER_ERR", repr(exc))
            continue
        if resp is not None:
            send(resp, log)
    log.write("STOP", "stdin closed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
