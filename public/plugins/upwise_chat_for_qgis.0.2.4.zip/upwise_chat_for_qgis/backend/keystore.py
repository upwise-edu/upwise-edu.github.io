"""공공 API 키 저장소 (0.2.1, 설계 docs/2 5-2, 5-3).

이 모듈만 키 **값**을 만진다
    키를 읽고 쓰는 창구를 하나로 묶는다. UI 는 이 모듈을 통해서만 값을
    만지고, 진단 로그와 요약에는 `summary()` 가 돌려주는 **불리언**만 나간다.
    값이 두 군데서 다뤄지면 한쪽이 언젠가 로그에 찍힌다.

저장 위치: `QgsSettings`(QGIS3.ini). 설계 5-2 의 결정이다
    사본이 하나뿐이고 플러그인 설정의 표준 자리다. **평문**이라는 한계는
    설정 패널의 안내 한 줄과 이 docstring 에 적는다. 암호화 저장
    (`QgsAuthManager`)은 0.2.x 후보다 - 마스터 비밀번호 프롬프트가 모달일
    위험이 있고(모달 금지), 자식 프로세스가 복호화해 읽을 수 없다.

    cwd 의 평문 파일(`.env`)은 **금지**다. 0.1.4 가 내장 읽기 3종을
    사전승인했으므로 cwd 의 파일은 모델이 `Read` 로 읽을 수 있다(S9a M-5
    실측). cwd 에 키를 두는 것은 키를 모델에 주는 것과 같다.

전달: 서버가 INI 를 직접 읽는다(K6). 플러그인은 경로와 접두사만 넘긴다
    그래서 **저장 직후 `sync()` 를 반드시 부른다**(설계 5-3 단서 2).
    `QgsSettings` 는 메모리에 캐시하므로 sync 없이는 파일에 값이 없고,
    서버가 빈 값을 읽어 "키가 설정되지 않았습니다" 로 끝난다.

형식 검사
    `KEY_RE` 는 `collect_server.KEY_RE` 와 같은 식이다. 서버가 받아들이지
    않는 값을 저장해 두면 "저장은 됐는데 수집이 안 되는" 상태가 된다.
    그래서 저장 시점에 거절하고 허용 문자를 사유에 적는다. 추측하지 않는다
    (설계 5-3 단서 1).

설계 정본: docs/2.collect_feature_design_v1.md 4-2, 5-2, 5-3
"""

import json
import os
import re

from . import posture

# 키를 담는 QgsSettings 경로 접두사. posture 가 정본이고(서버에 넘기는 env 와
# 같은 값이어야 한다) 여기서 다시 적지 않는다.
KEY_PREFIX = posture.COLLECT_KEY_PREFIX

# 엔드포인트 기본 URL 오버라이드(고급). `collect_server.SETTING_ENDPOINT_OVERRIDE`
# 와 같은 경로다. 서버는 이 값이 있으면 레지스트리의 base_url 대신 쓴다.
ENDPOINT_OVERRIDE_KEY = "upwise_chat/collect/endpoint_override"

# 레지스트리 JSON 파일명. 패키지 폴더 안에 있고 서버도 같은 파일을 읽는다.
REGISTRY_FILENAME = "collect_registry.json"

# 형식 검사식. collect_server.KEY_RE 와 **같은 식이어야 한다**(하네스 판정).
KEY_RE = re.compile(r"^[A-Za-z0-9_-]{8,128}$")

# 거절 사유 문구. 허용 문자를 적어 사용자가 무엇을 고칠지 알게 한다.
KEY_FORMAT_REASON = (
    "키 형식이 맞지 않습니다. 영문/숫자/밑줄/하이픈 8-128자만 저장합니다."
)
KEY_EMPTY_REASON = "키를 입력하세요."
SETTINGS_UNAVAILABLE_REASON = (
    "QGIS 설정을 열 수 없습니다. QGIS 안에서 다시 시도하세요."
)
URL_FORMAT_REASON = "http:// 또는 https:// 로 시작하는 주소만 저장합니다."

# 마스킹 표시. 값의 어느 글자도 보여주지 않는다 - 패널이 화면 공유나 캡처에
# 들어갈 수 있어서, 끝 몇 자리를 보여 주는 흔한 UX 를 쓰지 않는다.
MASK_BODY = "*" * 8
MASK_FMT = "%s (%d자)"


def registry_path():
    """패키지가 동봉한 레지스트리 JSON 경로."""
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        REGISTRY_FILENAME)


def load_providers(path=None):
    """레지스트리에서 제공자 목록을 읽는다.

    설정 패널의 행 순서가 여기서 나온다. 레지스트리가 정본이므로 제공자를
    UI 코드에 적지 않는다 - 데이터셋을 더해도 패널이 따라온다.

    Args:
        path: 레지스트리 경로. None 이면 동봉본.

    Returns:
        tuple: ({"id","title","signup","key_setting","needs_key"}, ...)
            id 알파벳 순.
    """
    target = str(path or registry_path())
    try:
        with open(target, "r", encoding="utf-8") as fh:
            body = json.load(fh)
    except Exception:  # noqa: BLE001 - 레지스트리를 못 읽어도 패널은 떠야 한다
        return ()
    providers = body.get("providers") or {}
    # 키가 필요한 제공자인가. auth="none" 인 데이터셋만 가진 제공자는 키 행을
    # 띄울 이유가 없다.
    needs = {}
    for entry in body.get("datasets") or ():
        if not isinstance(entry, dict):
            continue
        pid = str(entry.get("provider") or "")
        if not pid:
            continue
        needs[pid] = needs.get(pid, False) or (entry.get("auth") != "none")
    out = []
    for pid in sorted(providers):
        meta = providers[pid] or {}
        out.append({
            "id": pid,
            "title": str(meta.get("title") or pid),
            "signup": str(meta.get("signup") or ""),
            "key_setting": str(meta.get("key_setting") or key_setting(pid)),
            "needs_key": bool(needs.get(pid, True)),
        })
    return tuple(out)


def key_setting(provider):
    """제공자 하나의 설정 경로. 서버가 찾는 것과 같은 문자열이다."""
    return KEY_PREFIX + str(provider)


def settings_object():
    """QgsSettings 하나. QGIS 밖에서는 None 이다.

    logbook.qgis_profile_root 와 같은 방식이다 - qgis.core 를 함수 안에서
    import 하고 실패하면 떨어뜨린다. 설정을 못 열어서 독이 안 뜨는 일은 없다.
    """
    try:
        from qgis.core import QgsSettings

        return QgsSettings()
    except Exception:  # noqa: BLE001 - 설정 객체 생성 실패는 사유로 돌려준다
        return None


def _resolve(settings):
    """주입된 설정 객체 또는 QgsSettings. 하네스가 1번 인자를 쓴다."""
    return settings if settings is not None else settings_object()


def read_key(provider, settings=None):
    """제공자 키를 읽는다. 없으면 빈 문자열이다.

    Args:
        provider: 제공자 이름.
        settings: QSettings 호환 객체. None 이면 QgsSettings.

    Returns:
        str
    """
    store = _resolve(settings)
    if store is None:
        return ""
    try:
        value = store.value(key_setting(provider), "")
    except Exception:  # noqa: BLE001 - 읽기 실패를 "키 없음" 으로 떨어뜨린다
        return ""
    return "" if value is None else str(value)


def save_key(provider, value, settings=None):
    """키를 저장하고 **곧바로 sync() 한다**(설계 5-3 단서 2).

    sync 를 안 부르면 서버가 빈 값을 읽는다. 이 메서드가 그 단서의 집행
    지점이고, 하네스가 sync 호출 수를 센다.

    Args:
        provider: 제공자 이름.
        value: 저장할 키.
        settings: QSettings 호환 객체. None 이면 QgsSettings.

    Returns:
        tuple: (성공 여부, 사유 문자열). 사유에 **키 값을 넣지 않는다.**
    """
    text = ("" if value is None else str(value)).strip()
    if not text:
        return False, KEY_EMPTY_REASON
    if not KEY_RE.match(text):
        return False, KEY_FORMAT_REASON
    store = _resolve(settings)
    if store is None:
        return False, SETTINGS_UNAVAILABLE_REASON
    try:
        store.setValue(key_setting(provider), text)
        store.sync()
    except Exception as exc:  # noqa: BLE001 - 사유만 돌려준다
        return False, "설정에 쓰지 못했습니다: %r" % (exc,)
    return True, "저장했습니다"


def delete_key(provider, settings=None):
    """키를 지우고 곧바로 sync() 한다.

    Returns:
        tuple: (성공 여부, 사유 문자열)
    """
    store = _resolve(settings)
    if store is None:
        return False, SETTINGS_UNAVAILABLE_REASON
    try:
        store.remove(key_setting(provider))
        store.sync()
    except Exception as exc:  # noqa: BLE001
        return False, "설정에서 지우지 못했습니다: %r" % (exc,)
    return True, "지웠습니다"


def read_endpoint_override(settings=None):
    """엔드포인트 기본 URL 오버라이드. 없으면 빈 문자열."""
    store = _resolve(settings)
    if store is None:
        return ""
    try:
        value = store.value(ENDPOINT_OVERRIDE_KEY, "")
    except Exception:  # noqa: BLE001
        return ""
    return "" if value is None else str(value)


def save_endpoint_override(url, settings=None):
    """오버라이드를 저장한다. http(s) 가 아니면 거절한다.

    Returns:
        tuple: (성공 여부, 사유 문자열)
    """
    text = ("" if url is None else str(url)).strip()
    if not text:
        return False, URL_FORMAT_REASON
    if not (text.startswith("http://") or text.startswith("https://")):
        return False, URL_FORMAT_REASON
    store = _resolve(settings)
    if store is None:
        return False, SETTINGS_UNAVAILABLE_REASON
    try:
        store.setValue(ENDPOINT_OVERRIDE_KEY, text)
        store.sync()
    except Exception as exc:  # noqa: BLE001
        return False, "설정에 쓰지 못했습니다: %r" % (exc,)
    return True, "저장했습니다"


def delete_endpoint_override(settings=None):
    """오버라이드를 지운다.

    Returns:
        tuple: (성공 여부, 사유 문자열)
    """
    store = _resolve(settings)
    if store is None:
        return False, SETTINGS_UNAVAILABLE_REASON
    try:
        store.remove(ENDPOINT_OVERRIDE_KEY)
        store.sync()
    except Exception as exc:  # noqa: BLE001
        return False, "설정에서 지우지 못했습니다: %r" % (exc,)
    return True, "지웠습니다"


def mask(value):
    """저장된 값의 마스킹 표시. 값의 글자를 하나도 내보내지 않는다.

    Returns:
        str: 예 "******** (25자)". 빈 값이면 빈 문자열.
    """
    text = "" if value is None else str(value)
    if not text:
        return ""
    return MASK_FMT % (MASK_BODY, len(text))


def secrets(providers=None, settings=None):
    """레다크션에 넘길 키 값들.

    **이 함수의 반환값은 레다크터에만 들어간다.** 로그, 진단, UI 문구에
    쓰지 않는다.

    Returns:
        tuple: 저장된 키 값들(중복 제거).
    """
    rows = providers if providers is not None else load_providers()
    out = []
    for row in rows:
        value = read_key(row["id"], settings=settings)
        if value and value not in out:
            out.append(value)
    return tuple(out)


def key_state(providers=None, settings=None):
    """어느 제공자에 키가 있고 어느 쪽이 비었는가.

    Returns:
        tuple: (설정된 제공자 id 튜플, 비어 있는 제공자 id 튜플)
            키가 필요없는 제공자(auth=none 전용)는 양쪽에 들어가지 않는다.
    """
    rows = providers if providers is not None else load_providers()
    configured = []
    missing = []
    for row in rows:
        if not row.get("needs_key", True):
            continue
        if read_key(row["id"], settings=settings):
            configured.append(row["id"])
        else:
            missing.append(row["id"])
    return tuple(configured), tuple(missing)


def summary(providers=None, settings=None):
    """진단 로그가 찍는 요약. **키 값이 들어가지 않는다.**

    Returns:
        dict: 제공자별 설정 여부와 오버라이드 존재 여부.
    """
    rows = providers if providers is not None else load_providers()
    configured, missing = key_state(rows, settings=settings)
    return {
        "providers": [row["id"] for row in rows],
        "configured": list(configured),
        "missing": list(missing),
        "endpoint_override": bool(read_endpoint_override(settings=settings)),
    }
