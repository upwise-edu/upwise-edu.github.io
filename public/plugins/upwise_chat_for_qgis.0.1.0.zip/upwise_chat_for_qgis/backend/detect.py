"""전제조건 탐지 (설계 6-4).

네 가지를 본다.

    claude CLI   파일 경로. 유일하게 spawn 전에 알 수 있는 것이다.
    툴킷         `init.plugins` 1순위. 2순위는 사용자 settings.json 의 부분문자열.
    MCP 연결     `init.mcp_servers` 에서 name=qgis 의 status.
    cwd 전제     프리셋마다 다른 폴더 조건(설계 6-3 표).

왜 init 이 1순위인가
    툴킷 탐지에 `claude plugin` 하위명령을 쓰면 프로세스를 하나 더 띄워야 하고
    출력 형식이 미측이다(D19). S2 녹화에서 init 에 plugins 가 실려 온 것이
    관측됐으므로(장부 V28-18) 이미 받는 이벤트로 끝낼 수 있다.

왜 첫 턴 전에는 알 수 없는가
    입력을 보내기 전에는 init 이 오지 않는다(D06 FAIL). 그래서 툴킷, MCP,
    스킬 세 항목은 첫 턴까지 UNKNOWN 이고 UI 는 "확인 중" 으로 둔다.
    탐지 실패를 "없음" 으로 단정하지 않는다 - 오탐으로 기능을 막지 않는다.

하지 않는 것
    포트 9876 을 직접 열어 보지 않는다. QGIS MCP 는 단일 소켓 직렬이라
    탐지용 연결이 슬롯을 점유해 실제 클라이언트를 wedge 시킬 위험이 있다.
    이득(이미 init 으로 알 수 있다)보다 손실이 비대칭으로 크다(설계 6-4).
    로그인 상태도 탐지하지 않는다 - `claude auth` 가 미측이라(D07) 없는 명령을
    지어내지 않는다. 기동 실패 시 stderr 원문을 보여 주는 것이 전부다.

S6 이 더한 것
    프리셋 5종의 슬래시 문자열(6-1), 마커 판정식(6-2), 전제조건 표의 나머지
    축(6-3: 실습 패키지), 그리고 전제조건 바가 읽는 미충족 목록(7-1 [2]).
    전부 문자열과 경로 판정뿐이고 프로세스를 띄우지 않는다. 그래서 과금 없이
    재생으로 검증된다.

설계 정본: docs/1.mvp_design_v1.md 6-1, 6-2, 6-3, 6-4, 7-1
"""

import json
import os
import re
import shutil
from pathlib import Path

from . import posture

# 세 상태. 탐지 실패와 "없음" 을 구분한다. UNKNOWN 은 기능을 막지 않는다.
FOUND = "FOUND"
MISSING = "MISSING"
UNKNOWN = "UNKNOWN"

# 툴킷 플러그인 이름. 툴킷 `.claude-plugin/plugin.json` 의 name 이고 프리셋
# 슬래시 명령의 접두사와 같다(설계 6-1).
TOOLKIT_NAME = "upwise-qgis-mcp-toolkit"

# 툴킷 스킬 5종 정확명(설계 6-1). init.skills / init.slash_commands 사전 판정에 쓴다.
TOOLKIT_SKILLS = (
    "qgis-connect-check",
    "qgis-collect",
    "qgis-preprocess",
    "qgis-verify",
    "qgis-style",
)

# claude CLI 알려진 위치. shutil.which 가 먼저이고 이것은 폴백이다.
# 실측 경로다(1차 스파이크에서 확인된 설치 위치).
CLAUDE_KNOWN_PATHS = (
    r"%USERPROFILE%\.local\bin\claude.exe",
    r"%LOCALAPPDATA%\Programs\claude\claude.exe",
)

# 프리셋별 cwd 전제조건(설계 6-3 표). 값은 cwd 기준 상대 경로이고, 빈 튜플은
# 폴더 조건이 없다는 뜻이다. collect 는 실습 패키지 절대경로라 여기서 다루지
# 않는다 - 사용자 설정값이고 v2.2 백로그 미해결 항목이다(설계 6-3 각주).
PRESET_PATH_REQS = {
    "qgis-connect-check": (),
    "qgis-style": (),
    "qgis-preprocess": ("00.origins",),
    "qgis-verify": ("04.verify",),
    "qgis-collect": (),
}

# MCP 연결이 필요한 프리셋(설계 6-3 표).
PRESET_NEEDS_MCP = {
    "qgis-connect-check": False,
    "qgis-style": True,
    "qgis-preprocess": True,
    "qgis-verify": True,
    "qgis-collect": False,
}

# 실습 패키지 폴더가 필요한 프리셋(설계 6-3 표의 collect 행). 러너
# `scripts/collect/collect_all.py` 가 강의 패키지에만 있어 플러그인 단독으로는
# 성립하지 않는다(툴킷 v2.2 백로그 1번).
PRESET_NEEDS_PACKAGE = {
    "qgis-connect-check": False,
    "qgis-style": False,
    "qgis-preprocess": False,
    "qgis-verify": False,
    "qgis-collect": True,
}

# 실습 패키지 기본 위치(설계 6-3). 설정으로 덮을 수 있고 UI 는 S6 범위가
# 아니다(설계 9: 고급 설정은 설정 파일로만).
PRACTICE_PACKAGE_DEFAULT = r"C:\qgis_mcp_class"

# 버튼 순서와 라벨(설계 6-1 의 나열 순서). connect-check 가 맨 앞인 이유는
# 그것만 전제조건이 없고 나머지의 선행 점검 역할을 하기 때문이다.
PRESET_ORDER = (
    "qgis-connect-check",
    "qgis-collect",
    "qgis-preprocess",
    "qgis-verify",
    "qgis-style",
)

PRESET_LABELS = {
    "qgis-connect-check": "연결 점검",
    "qgis-collect": "수집",
    "qgis-preprocess": "전처리",
    "qgis-verify": "검증",
    "qgis-style": "스타일",
}

# 자동 전송하는 프리셋. connect-check 하나뿐이다(설계 6-1). 나머지 4개는
# 대상(어느 pN, 어느 레이어)을 암묵 인자로 받으므로(F10) 자동 전송하면
# 범위가 틀린 실행이 된다. 그래서 입력 박스에 넣고 포커스만 준다.
PRESET_AUTOSEND = ("qgis-connect-check",)

# 슬래시 명령 접두사. 툴킷 plugin.json 의 name 과 같다(설계 6-1).
SLASH_PREFIX = "/" + TOOLKIT_NAME + ":"

# 스킬 출력 마커 판정식(설계 6-2, F9). 스킬 5종 전부 첫 줄에
# `[qgis-<이름> 2.1.0]` 을 쓰도록 강제한다("예외 없다"). 그래서 슬래시 명령이
# stdin 경로에서 먹는지가 미측(D02)인 채로도 호출 성공을 런타임에 판정할 수 있다.
#
# 사전 명세: 판정식은 **이 정규식 하나**다. 마커의 스킬 이름이 누른 프리셋과
# 같은지는 판정에 넣지 않는다(설계 6-2 가 요구한 식이 아니다). 이름 불일치는
# 진단 로그에만 남긴다.
MARKER_RE = re.compile(r"^\[qgis-[a-z-]+ \d+\.\d+\.\d+\]")

# 마커를 못 찾았을 때의 안내와 버튼(설계 6-2).
MARKER_OK_TEXT = "스킬이 호출되었습니다: %s"
MARKER_FAIL_TEXT = "스킬이 호출되지 않았습니다. 자연어로 다시 요청할 수 있습니다."
MARKER_FALLBACK_BUTTON = "자연어로 다시 요청"

# 폴백 프롬프트(설계 6-2 의 예문을 그대로 쓴다). 스킬 이름과 출력 규칙을
# 풀어 써서 슬래시 경로가 아니어도 같은 절차를 타게 한다.
FALLBACK_PROMPT = (
    "%s 의 %s 스킬 절차대로 수행하고 첫 줄에 스킬 마커를 적어라."
)


def slash_command(preset):
    """프리셋 하나의 슬래시 명령 문자열(설계 6-1).

    Args:
        preset: 스킬 front matter name. 예: "qgis-style".

    Returns:
        str: 예 "/upwise-qgis-mcp-toolkit:qgis-style".
    """
    return SLASH_PREFIX + str(preset)


def preset_for_text(text):
    """보낸 문장이 어느 프리셋에서 나왔는지 본다.

    버튼을 눌러도 사용자가 손으로 고쳐 보낼 수 있으므로(자동 전송은
    connect-check 하나뿐이다) 전송 시점의 문장으로 판정한다. 그래야 마커
    판정(6-2)을 프리셋 턴에만 걸 수 있다.

    Returns:
        str: 프리셋 이름. 프리셋 호출이 아니면 빈 문자열.
    """
    body = (text or "").lstrip()
    if not body.startswith(SLASH_PREFIX):
        return ""
    rest = body[len(SLASH_PREFIX):]
    for preset in PRESET_ORDER:
        if rest == preset or rest.startswith(preset + " ") or rest.startswith(preset + "\n"):
            return preset
    return ""


def parse_marker(text):
    """첫 줄에서 스킬 마커를 읽는다(설계 6-2 판정식).

    Args:
        text: 그 턴 첫 assistant 텍스트 블록의 본문.

    Returns:
        tuple: (맞았는가, 스킬 이름, 버전). 안 맞으면 (False, "", "").
    """
    body = (text or "")
    first = body.split("\n", 1)[0].strip()
    if not MARKER_RE.match(first):
        return False, "", ""
    inner = first[1:first.index("]")]
    name, _sep, version = inner.partition(" ")
    return True, name, version


def fallback_prompt(preset):
    """마커가 안 보일 때 보낼 자연어 프롬프트(설계 6-2).

    Args:
        preset: 프리셋 이름.

    Returns:
        str
    """
    return FALLBACK_PROMPT % (TOOLKIT_NAME, str(preset))


def find_claude_exe(configured=None):
    """claude 실행 파일을 찾는다(설계 6-4).

    순서는 설정값 -> PATH -> 알려진 위치다. 설정값을 먼저 보는 이유는 사용자가
    고른 것을 PATH 가 덮지 않게 하기 위함이다.

    `--version` 을 여기서 돌리지 않는다. 259 MB PE 라 최초 실행이 느리고
    Defender 스캔이 겹친다. 검증이 필요하면 verify_claude_exe 를 워커
    스레드에서 부른다.

    Args:
        configured: 설정에 저장된 경로. 빈 값이면 건너뛴다.

    Returns:
        tuple: (상태, 경로 또는 "", 근거 문자열)
    """
    if configured:
        p = Path(os.path.expandvars(str(configured)))
        if p.is_file():
            return FOUND, str(p), "configured"
        return MISSING, "", "configured path not a file: %s" % p

    which = shutil.which("claude")
    if which:
        return FOUND, which, "PATH"

    for raw in CLAUDE_KNOWN_PATHS:
        p = Path(os.path.expandvars(raw))
        if p.is_file():
            return FOUND, str(p), "known path"
    return MISSING, "", "not in PATH and not at known locations"


def verify_claude_exe(exe, runner, timeout_s=90.0):
    """`--version` 으로 실행 가능 여부를 본다. 워커 스레드에서 부른다.

    프로세스 기동을 이 모듈이 직접 하지 않는다. runner 를 받아서 부른다 -
    그래야 테스트가 가짜 runner 를 넣어 과금 없이 돌 수 있고, 플랫폼별
    creationflags 같은 정책이 process 계층에 한 군데로 모인다.

    Args:
        exe: 실행 파일 경로.
        runner: callable(argv, timeout_s) -> (returncode, stdout, stderr).
        timeout_s: 상한. 기본 90 s 는 PoC 에서 쓴 값이다(최초 실행이 느리다).

    Returns:
        tuple: (상태, 버전 문자열 또는 "", 근거)
    """
    if not exe:
        return MISSING, "", "no exe"
    try:
        rc, out, err = runner([str(exe), "--version"], timeout_s)
    except Exception as exc:  # noqa: BLE001 - 탐지 실패가 기동을 막지 않는다
        return UNKNOWN, "", "runner raised %r" % (exc,)
    if rc == 0:
        return FOUND, (out or "").strip()[:200], "rc=0"
    return UNKNOWN, "", "rc=%s stderr=%s" % (rc, (err or "").strip()[:200])


def toolkit_from_init(init_event):
    """init.plugins 에서 툴킷을 찾는다. 1순위 경로다(설계 6-4).

    plugins 의 스키마는 관측이고 보장이 아니다(장부 V28-18). 그래서 구조를
    가정하지 않고 직렬화한 문자열에서 이름을 찾는다. 수강생 환경에 필드가
    없으면 UNKNOWN 이고, 그때도 프리셋을 막지 않는다.

    Returns:
        tuple: (상태, 버전 문자열 또는 "", 근거)
    """
    if not isinstance(init_event, dict):
        return UNKNOWN, "", "init not a dict"
    plugins = init_event.get("plugins")
    if plugins is None:
        return UNKNOWN, "", "init has no plugins field"
    blob = json.dumps(plugins, ensure_ascii=False)
    if TOOLKIT_NAME not in blob:
        return MISSING, "", "plugins present but toolkit name absent"
    version = ""
    # 리스트 of dict 가 관측된 형태다. 아니면 버전 없이 FOUND 로 둔다.
    if isinstance(plugins, list):
        for entry in plugins:
            if not isinstance(entry, dict):
                continue
            if TOOLKIT_NAME in json.dumps(entry, ensure_ascii=False):
                version = str(entry.get("version") or "")
                break
    return FOUND, version, "init.plugins"


def toolkit_from_settings(settings_path=None):
    """2순위. 사용자 settings.json 의 직렬화 문자열에서 이름을 찾는다.

    `enabledPlugins` 키가 있는 것은 실측이고(F6) 그 스키마는 미측이다. 그래서
    키를 파고들지 않고 파일 전체 문자열에서 찾는다 - 둔감하게 둔 것이 의도다.
    """
    path = Path(settings_path) if settings_path else (
        Path(os.path.expanduser("~")) / ".claude" / "settings.json")
    if not path.is_file():
        return UNKNOWN, "", "settings.json not found: %s" % path
    try:
        body = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return UNKNOWN, "", "read failed %r" % (exc,)
    if TOOLKIT_NAME in body:
        return FOUND, "", "settings.json substring"
    return MISSING, "", "settings.json has no toolkit name"


def mcp_status_from_init(init_event, server_name=posture.QGIS_MCP_SERVER_NAME):
    """init.mcp_servers 에서 서버 하나의 status 를 읽는다(설계 3-4 게이트 4).

    Returns:
        tuple: (상태, status 문자열, 근거)
    """
    if not isinstance(init_event, dict):
        return UNKNOWN, "", "init not a dict"
    servers = init_event.get("mcp_servers")
    if servers is None:
        return UNKNOWN, "", "init has no mcp_servers field"
    if not isinstance(servers, list):
        return UNKNOWN, "", "mcp_servers not a list"
    for entry in servers:
        if isinstance(entry, dict) and entry.get("name") == server_name:
            status = str(entry.get("status") or "")
            return (FOUND if status == "connected" else MISSING), status, "init.mcp_servers"
    return MISSING, "", "server %r absent (n=%d)" % (server_name, len(servers))


def skills_from_init(init_event):
    """init.skills / init.slash_commands 에서 툴킷 스킬 5종을 찾는다(설계 6-4).

    사전 판정용이다. 있으면 버튼을 누르기 전에 호출 가능 여부를 알 수 있고,
    없으면 6-2 의 사후 마커 판정만 쓴다. 관측 필드이므로 부재가 정상이다.

    S6 정정: 찾는 문자열을 **접두사까지 붙인 정확명**으로 바꿨다. 실녹화에서
    등재 형태가 `upwise-qgis-mcp-toolkit:qgis-collect` 였다(장부 V28-18).
    맨이름만 찾으면 다른 플러그인의 같은 이름 스킬도 걸린다.

    Returns:
        tuple: (상태, 찾은 스킬 이름들, 근거)
    """
    if not isinstance(init_event, dict):
        return UNKNOWN, (), "init not a dict"
    blob_parts = []
    for key in ("skills", "slash_commands"):
        value = init_event.get(key)
        if value is not None:
            blob_parts.append(json.dumps(value, ensure_ascii=False))
    if not blob_parts:
        return UNKNOWN, (), "init has neither skills nor slash_commands"
    blob = " ".join(blob_parts)
    hits = tuple(name for name in TOOLKIT_SKILLS
                 if (TOOLKIT_NAME + ":" + name) in blob)
    if not hits:
        return MISSING, (), "fields present but no toolkit skill name"
    return FOUND, hits, "init fields"


def cwd_requirements(cwd, preset):
    """프리셋 하나의 cwd 폴더 전제조건을 본다(설계 6-3).

    Args:
        cwd: 백엔드 작업 폴더.
        preset: 스킬 이름(front matter name).

    Returns:
        tuple: (충족 여부, 빠진 경로들)
    """
    reqs = PRESET_PATH_REQS.get(preset, ())
    if not reqs:
        return True, ()
    if not cwd:
        return False, tuple(reqs)
    root = Path(cwd)
    missing = tuple(r for r in reqs if not (root / r).exists())
    return (not missing), missing


class Prerequisites(object):
    """탐지 결과 묶음. UI 가 읽는 단일 창구다.

    claude 경로만 spawn 전에 채워지고, 나머지는 첫 턴의 init 에서 채워진다
    (D06 FAIL). 그래서 note_init() 전에는 toolkit/mcp/skills 가 UNKNOWN 이다.
    """

    def __init__(self, cwd="", configured_exe=None, package_dir=None):
        """
        Args:
            cwd: 백엔드 작업 폴더. 프리셋 폴더 조건의 기준이다(설계 6-3).
            configured_exe: 설정에 저장된 claude 경로. 없으면 PATH 를 본다.
            package_dir: 실습 패키지 폴더. 없으면 설계 6-3 의 기본 경로.
        """
        self.cwd = str(cwd or "")
        self.claude_status, self.claude_exe, self.claude_why = find_claude_exe(
            configured_exe)
        self.claude_version = ""
        self.package_dir = str(package_dir or PRACTICE_PACKAGE_DEFAULT)
        # 첫 init 을 받았는가. 받기 전에는 툴킷/MCP/스킬이 "확인 중" 이고
        # 전제조건 바에 미충족으로 적지 않는다(D06 FAIL).
        self.init_seen = False
        self.toolkit_status = UNKNOWN
        self.toolkit_version = ""
        self.toolkit_why = "init not received yet (D06)"
        self.mcp_status = UNKNOWN
        self.mcp_detail = ""
        self.mcp_why = "init not received yet (D06)"
        self.skills_status = UNKNOWN
        self.skills_found = ()
        self.skills_why = "init not received yet (D06)"

    def note_init(self, init_event):
        """첫 init 으로 툴킷, MCP, 스킬 세 항목을 채운다."""
        self.toolkit_status, self.toolkit_version, self.toolkit_why = (
            toolkit_from_init(init_event))
        if self.toolkit_status == UNKNOWN:
            # init 에 필드가 없는 환경이면 2순위로 떨어진다.
            self.toolkit_status, self.toolkit_version, self.toolkit_why = (
                toolkit_from_settings())
        self.mcp_status, self.mcp_detail, self.mcp_why = mcp_status_from_init(
            init_event)
        self.skills_status, self.skills_found, self.skills_why = (
            skills_from_init(init_event))
        self.init_seen = True

    def set_cwd(self, cwd):
        """cwd 가 바뀌면 프리셋 활성 상태를 다시 계산해야 한다(설계 6-3)."""
        self.cwd = str(cwd or "")

    def package_present(self):
        """실습 패키지 폴더가 있는가(설계 6-3 collect 행).

        Python 3 와 `.env` 는 보지 않는다. QGIS 는 자기 파이썬을 들고 오므로
        `which` 한 번의 불일치로 버튼을 막으면 오탐이 기능을 막는 쪽이 되고
        (설계 6-4 마지막 원칙), `.env` 의 키 이름 점검은 스킬 자신이 한다.
        """
        if not self.package_dir:
            return False
        return Path(self.package_dir).is_dir()

    def preset_state(self, preset):
        """프리셋 하나가 지금 활성인가. 비활성이면 이유를 함께 준다.

        오탐으로 기능을 막지 않는다 - 툴킷이 UNKNOWN 이면 활성으로 둔다(설계 6-4).

        Returns:
            tuple: (활성 여부, 이유 문자열)
        """
        if self.claude_status != FOUND:
            return False, "claude CLI 를 찾지 못했습니다"
        if self.toolkit_status == MISSING:
            return False, "툴킷(%s)이 설치되어 있지 않습니다" % TOOLKIT_NAME
        if PRESET_NEEDS_MCP.get(preset) and self.mcp_status == MISSING:
            return False, "QGIS 에서 Run MCP 를 누르세요"
        ok, missing = cwd_requirements(self.cwd, preset)
        if not ok:
            return False, "작업 폴더에 %s 가 없습니다" % ", ".join(missing)
        # 실습 패키지 축(설계 6-3 collect 행). 폴더 축 뒤에 둔다 - collect 는
        # 폴더 조건이 없으므로 순서가 다른 프리셋의 이유를 바꾸지 않는다.
        if PRESET_NEEDS_PACKAGE.get(preset) and not self.package_present():
            return False, "실습 패키지 폴더를 지정하세요 (%s)" % (
                self.package_dir or "미지정")
        # 사전 판정(설계 6-4). init 이 스킬 목록을 실어 왔을 때만 본다.
        # UNKNOWN 은 막지 않는다 - 오탐으로 기능을 막지 않는 것이 원칙이고,
        # 그 경우 6-2 의 사후 마커 판정만으로 간다.
        if self.skills_status == MISSING:
            return False, "이 세션에 툴킷 스킬이 등재되지 않았습니다"
        if self.skills_status == FOUND and preset not in self.skills_found:
            return False, "이 세션에 %s 스킬이 등재되지 않았습니다" % preset
        if self.mcp_status == UNKNOWN and PRESET_NEEDS_MCP.get(preset):
            return True, "확인 중 (첫 턴의 init 에서 확인됩니다)"
        return True, ""

    def preset_states(self):
        """프리셋 5종의 (활성, 이유) 를 순서대로 돌려준다(설계 7-1 [3]).

        Returns:
            list[tuple]: (프리셋 이름, 활성 여부, 이유 문자열)
        """
        return [(p,) + tuple(self.preset_state(p)) for p in PRESET_ORDER]

    def unmet_items(self):
        """전제조건 바가 띄울 미충족 항목만 돌려준다(설계 7-1 [2]).

        첫 init 전에는 툴킷/MCP/스킬을 적지 않는다. 그때는 "미충족" 이 아니라
        "확인 중" 이고(D06 FAIL), 확인 중인 것을 미충족으로 적으면 기동할 때마다
        경고가 떠 있다.

        Returns:
            list[tuple]: (코드, 사용자에게 보일 한 줄)
        """
        items = []
        if self.claude_status != FOUND:
            items.append((
                "claude",
                "claude CLI 를 찾지 못했습니다. 터미널에서 claude 를 한 번 실행해 "
                "설치와 로그인 상태를 확인하세요.",
            ))
        if not self.init_seen:
            return items
        if self.toolkit_status == MISSING:
            items.append((
                "toolkit",
                "툴킷(%s)이 설치되어 있지 않습니다." % TOOLKIT_NAME,
            ))
        elif self.toolkit_status == UNKNOWN:
            items.append((
                "toolkit",
                "툴킷(%s)을 확인하지 못했습니다. 프리셋은 그대로 쓸 수 있습니다."
                % TOOLKIT_NAME,
            ))
        if self.mcp_status == MISSING:
            items.append((
                "mcp",
                "QGIS MCP 가 연결되지 않았습니다. QGIS 에서 Run MCP 를 누르세요.",
            ))
        return items

    def summary(self):
        """진단 로그와 검증 하네스가 읽는 한 dict."""
        return {
            "claude": self.claude_status,
            "claude_exe": self.claude_exe,
            "claude_why": self.claude_why,
            "toolkit": self.toolkit_status,
            "toolkit_version": self.toolkit_version,
            "toolkit_why": self.toolkit_why,
            "mcp": self.mcp_status,
            "mcp_detail": self.mcp_detail,
            "skills": self.skills_status,
            "skills_found": list(self.skills_found),
            "cwd": self.cwd,
            "package_dir": self.package_dir,
            "package_present": self.package_present(),
            "init_seen": self.init_seen,
        }
