"""전사 영역 위젯 (설계 7-1 [4], 4-2, 4-4).

무엇을 그리는가
    사용자 말풍선, 모델 텍스트 블록, 생각 블록(접힘), 도구 카드(접힘),
    턴 구분선, 로컬 공지(백엔드 종료 등). 그릴 재료는 전부 TurnMachine 이
    들고 있고 이 위젯은 그것을 읽어 위젯으로 옮긴다.

어떻게 그리는가 - 증분이다
    sync() 는 50 ms 드레인마다 불린다. 그래서 전사를 매번 다시 만들지 않고,
    블록 키로 위젯을 찾아 **바뀐 것만** 갱신한다. 텍스트 블록은 스트리밍으로
    자라기만 하므로, 이미 그린 접두를 넘는 부분만 커서로 삽입한다.

    왜 QLabel 이 아닌가 (측정으로 고른 것이다)
        같은 조건(앞선 블록 40개, 델타 2,500건, 틱당 10건, 최종 37,500자)에서
        QLabel.setText(전문) 은 틱당 평균 25.0 ms / 최대 44.5 ms 였다. 드레인
        간격이 50 ms 이므로 예산을 거의 다 쓴다. QTextEdit 증분 삽입 + 높이
        추종은 평균 9.2 ms / 최대 29.2 ms 였다. 그래서 텍스트는 QTextEdit 다.
        (측정 2026-10-10, QT_QPA_PLATFORM=offscreen, QGIS 3.44.14 번들 Qt 5.15.13)

    사용자 말풍선과 공지는 한 번 쓰고 바뀌지 않으므로 QLabel 이다.

상한 (설계 4-4)
    블록 위젯은 최근 200개만 유지하고 그 위는 접는다. 전체는 session_*.jsonl
    에 남아 있다. 도구 결과는 protocol 이 이미 4,000자로 자른 사본을 주고,
    잘린 경우 "전문 보기" 로 원문을 임시 파일에 열어 준다.

금지 API(설계 3-5): QMessageBox, QDialog.exec(), QProgressDialog, 중첩 이벤트 루프.
Qt import 는 전부 qgis.PyQt 셰임 경로로 한다(설계 7-4).

설계 정본: docs/1.mvp_design_v1.md 4-2, 4-3, 4-4, 7-1
"""

import json
import tempfile
import time
from pathlib import Path

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QDesktopServices, QTextCursor
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..backend import protocol

# 전사에 위젯으로 유지하는 블록 수 상한(설계 4-4). protocol 의 값을 그대로 쓴다.
BLOCK_WIDGET_MAX = protocol.TRANSCRIPT_BLOCK_MAX

# 도구 카드 머리에 항상 보이는 인자 미리보기 길이(설계 4-2 tool_use 행).
ARGS_PREVIEW_CHARS = 200

# 전사 레이아웃 여백과 행 간격(px). 고정 px 는 여백뿐이고 글꼴은 QGIS 배율을
# 그대로 따른다(설계 7-3).
VIEW_MARGIN = 6
ROW_SPACING = 6

# 위험 표시 테두리색. 거부/오류 카드에만 쓴다(설계 4-2 tool_result 행의 "빨간
# 테두리"). 브랜드 팔레트 확정은 S7 범위이므로 여기서는 중립적인 빨강 하나만
# 쓰고 독 전역 스타일시트는 건드리지 않는다(설계 7-3).
ERROR_BORDER_COLOR = "#c0392b"

# 도구 상태별 표시 문구. ToolSearch 는 따로 구분한다(설계 4-2 ToolSearch 행).
STAGE_LABELS = {
    "searching_tools": "도구 찾는 중",
    "running": "실행 중",
}


def _format_args(tool_input):
    """도구 인자 dict 를 사람이 읽을 JSON 문자열로 만든다.

    한글이 \\uXXXX 로 깨지지 않게 ensure_ascii=False 다. 직렬화가 안 되는 값이
    섞여 있어도 카드가 안 그려지는 일은 없어야 하므로 default=str 로 떨어뜨린다.
    """
    if not tool_input:
        return "{}"
    try:
        return json.dumps(tool_input, ensure_ascii=False, indent=2, default=str)
    except (TypeError, ValueError):
        return str(tool_input)


class GrowingTextView(QTextEdit):
    """내용 높이를 따라가는 읽기 전용 텍스트 뷰.

    스크롤은 전사 영역 하나만 쓰고 이 위젯은 스크롤바를 갖지 않는다. 그래서
    높이를 문서 높이에 맞춘다. 갱신은 증분이다(모듈 docstring 의 측정 참조).
    """

    def __init__(self, parent=None):
        """읽기 전용, 스크롤바 없음, 높이 고정 정책으로 만든다."""
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setLineWrapMode(QTextEdit.WidgetWidth)
        self._rendered = ""
        self._fixed_height = -1

    def rendered_text(self):
        """지금 화면에 들어가 있는 문자열. 중복 검사와 검증에 쓴다."""
        return self._rendered

    def set_text_incremental(self, text):
        """바뀐 부분만 반영한다.

        이미 그린 문자열이 새 문자열의 접두면 꼬리만 커서로 삽입한다. 아니면
        전문을 다시 넣는다(권위 텍스트가 스트리밍 버퍼와 다른 경우).

        Returns:
            bool: 실제로 갱신했는가.
        """
        text = text if isinstance(text, str) else ("" if text is None else str(text))
        if text == self._rendered:
            return False
        if self._rendered and text.startswith(self._rendered):
            cursor = self.textCursor()
            cursor.movePosition(QTextCursor.End)
            cursor.insertText(text[len(self._rendered):])
        else:
            self.setPlainText(text)
        self._rendered = text
        self._fit_height()
        return True

    def _fit_height(self):
        """문서 높이에 맞춰 고정 높이를 다시 잡는다.

        값이 바뀔 때만 setFixedHeight 를 부른다. 매번 부르면 resizeEvent 가
        다시 들어와 레이아웃이 왕복한다.
        """
        doc = self.document()
        doc.setTextWidth(max(1, self.viewport().width()))
        want = int(doc.size().height()) + 2 * int(doc.documentMargin()) + 2
        if want != self._fixed_height:
            self._fixed_height = want
            self.setFixedHeight(want)

    def resizeEvent(self, event):  # noqa: N802 - Qt 가 요구하는 고정 이름
        """폭이 바뀌면 줄바꿈이 바뀌므로 높이를 다시 잡는다."""
        super().resizeEvent(event)
        self._fit_height()


class CollapsibleSection(QWidget):
    """제목 버튼 하나로 본문을 접고 펴는 영역.

    모달 없이 상세를 숨기는 수단이다. 생각 블록과 도구 카드가 쓴다.
    """

    def __init__(self, title, parent=None, expanded=False):
        """
        Args:
            title: 제목 버튼 문구.
            parent: 부모 위젯.
            expanded: 처음에 펴 둘지. 생각 블록과 도구 카드는 둘 다 접힘이다
                (설계 4-2 thinking_delta 행, tool_use 행).
        """
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        self._button = QToolButton(self)
        self._button.setText(title)
        self._button.setCheckable(True)
        self._button.setChecked(bool(expanded))
        self._button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._button.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._button.setAutoRaise(True)
        self._button.toggled.connect(self._on_toggled)
        layout.addWidget(self._button)

        self._body = QWidget(self)
        self._body_layout = QVBoxLayout(self._body)
        self._body_layout.setContentsMargins(12, 0, 0, 0)
        self._body_layout.setSpacing(4)
        self._body.setVisible(bool(expanded))
        layout.addWidget(self._body)

    def set_title(self, title):
        """제목을 바꾼다. 도구 상태가 바뀔 때 쓴다."""
        if self._button.text() != title:
            self._button.setText(title)

    def title(self):
        """지금 제목 문구."""
        return self._button.text()

    def add_body_widget(self, widget):
        """본문에 위젯을 더한다."""
        self._body_layout.addWidget(widget)

    def is_expanded(self):
        """펴져 있는가. 검증 하네스가 읽는다."""
        return self._button.isChecked()

    def _on_toggled(self, checked):
        """화살표 방향과 본문 가시성을 맞춘다."""
        self._button.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        self._body.setVisible(bool(checked))


class ToolCardWidget(QFrame):
    """도구 호출 1건의 카드(설계 4-2 tool_use/tool_result 행).

    머리에 이름과 상태, 인자 200자 미리보기를 항상 보여주고, 펴면 인자 전문과
    결과가 나온다. 결과는 protocol 이 4,000자로 자른 사본이고 잘렸으면
    "전문 보기" 로 원문을 임시 파일에 연다(설계 4-4).
    """

    def __init__(self, parent=None):
        """빈 카드를 만든다. 내용은 update_from() 이 채운다."""
        super().__init__(parent)
        # S7. 독 qss 가 이 이름으로 카드 배경과 테두리를 건다(설계 7-3 "카드
        # 배경" 행). 오류 테두리는 update_from 이 더 구체적인 선택자로 덮는다.
        self.setObjectName("UpwiseChatToolCard")
        self.setFrameShape(QFrame.StyledPanel)
        self._error_style = False
        self._raw_body = ""
        self._full_args = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(2)

        self._section = CollapsibleSection("", self, expanded=False)
        layout.addWidget(self._section)

        # 접혀 있어도 보이는 미리보기. 어떤 인자로 불렀는지가 가장 궁금한 값이다.
        self._preview = QLabel("", self)
        self._preview.setWordWrap(True)
        self._preview.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self._preview)

        self._args_view = GrowingTextView(self)
        self._section.add_body_widget(self._args_view)
        self._result_view = GrowingTextView(self)
        self._section.add_body_widget(self._result_view)

        row = QWidget(self)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        self._full_button = QPushButton("전문 보기", row)
        self._full_button.setToolTip("잘리지 않은 원문을 임시 파일로 연다")
        self._full_button.clicked.connect(self._on_open_full)
        self._full_button.setVisible(False)
        row_layout.addWidget(self._full_button)
        row_layout.addStretch(1)
        self._section.add_body_widget(row)

    def update_from(self, card):
        """ToolCard 상태를 위젯에 반영한다.

        Args:
            card: machine.ToolCard.

        Returns:
            bool: 무언가 바뀌었는가.
        """
        changed = False
        self._section.set_title(self._title_for(card))

        args_text = _format_args(card.tool_input)
        if args_text != self._full_args:
            self._full_args = args_text
            preview = args_text[:ARGS_PREVIEW_CHARS]
            if len(args_text) > ARGS_PREVIEW_CHARS:
                preview += " ..."
            self._preview.setText(preview)
            self._args_view.set_text_incremental("인자\n" + args_text)
            changed = True

        if card.closed:
            body = card.result_display or ""
            if card.result_truncated:
                body += "\n... (%d자에서 잘림. 전문 보기를 누르세요)" % len(body)
            if self._result_view.set_text_incremental("결과\n" + body):
                changed = True
            self._raw_body = card.result_raw or ""
            # 잘린 결과와 오류 결과는 원문을 열 수 있게 둔다. 거부 사유 전문이
            # 오류 본문으로 오기 때문이다(설계 3-5 항목 3).
            want_full = bool(card.result_truncated or card.is_error)
            if self._full_button.isVisible() != want_full:
                self._full_button.setVisible(want_full)
                changed = True

        want_error = bool(card.is_error) or bool(card.denied)
        if want_error != self._error_style:
            self._error_style = want_error
            # 스타일시트는 이 카드 위젯에만 건다. 독 전역이나 QGIS 전역에
            # 적용하지 않는다(설계 7-3).
            #
            # 선택자가 `QFrame#UpwiseChatToolCard` 인 이유(S7, V28-A33 정정):
            # Qt 는 조상 스타일시트와 자기 것을 합치지만, 충돌할 때 이기는 것은
            # **위젯 자신의 styleSheet** 다. 조상(독 qss)이 `#UpwiseChatToolCard`
            # 로 카드 테두리를 걸고 있어도 자기 규칙이 덮는다. 즉 형 선택자
            # (`QFrame`)만 써도 오류 테두리는 그려진다 - verifier 15/15 실측.
            # ID 를 함께 적는 것은 의도를 드러내는 명시성 취향이고, 덮어쓰기의
            # 필요조건이 아니다. (이전 주석은 "조상 ID 규칙이 형 선택자를
            # 이긴다" 고 적었는데 실측과 반대였다.)
            self.setStyleSheet(
                "QFrame#UpwiseChatToolCard { border: 1px solid %s; }" % ERROR_BORDER_COLOR
                if want_error
                else ""
            )
            changed = True
        return changed

    # ------------------------------------------------------------------
    # 조회 (검증 하네스가 읽는다)
    # ------------------------------------------------------------------

    def preview_text(self):
        """접혀 있어도 보이는 인자 미리보기 문구."""
        return self._preview.text()

    def args_text(self):
        """펼쳤을 때 보이는 인자 전문 문구."""
        return self._args_view.rendered_text()

    def result_text(self):
        """펼쳤을 때 보이는 결과 문구. cat -n 접두가 제거된 사본이다."""
        return self._result_view.rendered_text()

    def title_text(self):
        """카드 제목(도구 이름과 상태)."""
        return self._section.title()

    def is_expanded(self):
        """카드가 펴져 있는가. 기본은 접힘이다."""
        return self._section.is_expanded()

    def full_button_visible(self):
        """"전문 보기" 버튼을 띄우기로 했는가.

        isVisible() 은 카드가 접혀 있으면(본문이 숨어 있으면) 거짓이 된다.
        여기서 알고 싶은 것은 버튼 자체의 표시 결정이므로 isHidden() 의 반대다.
        """
        return not self._full_button.isHidden()

    def has_error_style(self):
        """거부/오류 테두리가 걸려 있는가."""
        return self._error_style

    def _title_for(self, card):
        """카드 제목. 상태를 사람 말로 적는다."""
        if card.denied:
            state = "거부됨"
        elif getattr(card, "excluded", False):
            # 제외는 거부가 아니다. 사용자가 "허용" 으로 풀 수 없는 상태이므로
            # 제목에서도 갈라 쓴다(설계 3-5).
            state = "포스처에 없음"
        elif card.closed and card.is_error:
            state = "오류"
        elif card.closed:
            state = "완료"
        else:
            state = STAGE_LABELS.get(card.stage, "실행 중")
        return "도구 · %s · %s" % (card.name or "(이름 없음)", state)

    def _on_open_full(self):
        """원문을 임시 파일에 쓰고 운영체제 기본 프로그램으로 연다(설계 4-4).

        모달 대화상자를 쓰지 않는 유일한 "전문 보기" 경로다.
        """
        if not self._raw_body:
            return
        path = Path(tempfile.gettempdir()) / (
            "upwise_chat_tool_result_%s.txt" % time.strftime("%y%m%d_%H%M%S")
        )
        try:
            path.write_text(self._raw_body, encoding="utf-8")
        except OSError:
            # 쓰기 실패가 독을 멈추게 하지 않는다. 결과는 jsonl 에도 있다.
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


class ChatView(QScrollArea):
    """전사 영역. 행을 append 만 하고 재배치하지 않는다.

    append 만으로 시간순이 맞는 이유: 사용자 말풍선은 전송 시점에, 모델 블록은
    상태머신이 발견한 순서대로 들어온다. 그래서 발견 순서가 곧 화면 순서다.
    """

    def __init__(self, parent=None):
        """스크롤 영역과 내부 레이아웃을 만든다."""
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self._body = QWidget()
        self._body.setObjectName("UpwiseChatTranscriptBody")
        self._layout = QVBoxLayout(self._body)
        self._layout.setContentsMargins(VIEW_MARGIN, VIEW_MARGIN, VIEW_MARGIN, VIEW_MARGIN)
        self._layout.setSpacing(ROW_SPACING)
        # 꼬리 스트레치. 행은 항상 이 스트레치 앞에 끼운다.
        self._layout.addStretch(1)
        self.setWidget(self._body)

        # 접힘 안내 라벨. 블록 상한을 넘겼을 때만 보인다(설계 4-4).
        self._fold_label = QLabel("", self._body)
        self._fold_label.setWordWrap(True)
        self._fold_label.setVisible(False)
        self._layout.insertWidget(0, self._fold_label)

        # 행 장부. kind 는 "user", "notice", "separator", "block", "card".
        self._rows = []
        self._by_key = {}
        self._seen_turns = set()
        self._folded_n = 0

        # 측정값. S4 완료 판정 "렌더 끊김 없음" 의 근거다.
        self.render_ms = []
        self.sync_calls = 0
        self.updates = 0

    # ------------------------------------------------------------------
    # 로컬 행 (독이 직접 넣는 것)
    # ------------------------------------------------------------------

    def add_user_message(self, text):
        """사용자 말풍선. 전송 즉시 그린다(설계 4-2 user 행: replay 는 렌더 금지)."""
        label = QLabel("나: " + (text or ""), self._body)
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._append_row("user", None, label)
        return label

    def add_notice(self, text):
        """로컬 공지. 백엔드 종료, 취소 마감 같은 플러그인 쪽 사실을 적는다."""
        label = QLabel(text or "", self._body)
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._append_row("notice", None, label)
        return label

    # ------------------------------------------------------------------
    # 상태머신 동기화
    # ------------------------------------------------------------------

    def sync(self, machine):
        """상태머신의 전사를 위젯에 반영한다. 바뀐 것만 만진다.

        Args:
            machine: backend.machine.TurnMachine.

        Returns:
            int: 갱신한 행 수.
        """
        t0 = time.perf_counter()
        at_bottom = self._at_bottom()
        changed = 0
        for turn in machine.turns:
            if turn.turn_no not in self._seen_turns:
                self._seen_turns.add(turn.turn_no)
                self._append_separator(turn.turn_no)
                changed += 1
            for rb in turn.blocks:
                if rb.kind == "tool_use":
                    card = turn.cards.get(rb.tool_use_id)
                    if card is not None and self._sync_card(card):
                        changed += 1
                elif rb.kind in ("text", "thinking"):
                    if self._sync_block(rb):
                        changed += 1
            # tool_use 를 못 본 결과로 생긴 카드는 블록이 없다. 턴 끝에 붙인다.
            for cid in turn.card_order:
                card = turn.cards.get(cid)
                if card is not None and card.orphan and self._sync_card(card):
                    changed += 1
        self._enforce_cap()
        if at_bottom:
            self._scroll_to_bottom()
        self.sync_calls += 1
        self.updates += changed
        self.render_ms.append((time.perf_counter() - t0) * 1000.0)
        return changed

    def _sync_block(self, rb):
        """텍스트/생각 블록 하나를 반영한다."""
        key = ("block", rb.key)
        row = self._by_key.get(key)
        if row is None:
            if rb.kind == "thinking":
                # 생각은 기본 접힘이다(설계 4-2 thinking_delta 행).
                section = CollapsibleSection("생각 중", self._body, expanded=False)
                view = GrowingTextView(section)
                section.add_body_widget(view)
                row = self._append_row("block", key, section, view=view, block_kind=rb.kind)
            else:
                view = GrowingTextView(self._body)
                row = self._append_row("block", key, view, view=view, block_kind=rb.kind)
        view = row["view"]
        return view.set_text_incremental(rb.text())

    def _sync_card(self, card):
        """도구 카드 하나를 반영한다."""
        key = ("card", card.tool_use_id or id(card))
        row = self._by_key.get(key)
        if row is None:
            widget = ToolCardWidget(self._body)
            row = self._append_row("card", key, widget)
        return row["widget"].update_from(card)

    def _append_separator(self, turn_no):
        """턴 구분선."""
        line = QFrame(self._body)
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        self._append_row("separator", None, line, turn_no=turn_no)

    # ------------------------------------------------------------------
    # 내부 - 행 장부와 상한
    # ------------------------------------------------------------------

    def _append_row(self, kind, key, widget, **extra):
        """행을 꼬리 스트레치 앞에 끼우고 장부에 남긴다.

        extra 의 키 이름은 "kind" 와 겹치지 않아야 한다. 겹치면 행 종류가
        덮어써져서 상한 계산이 틀어진다(그래서 블록 종류는 block_kind 다).
        """
        self._layout.insertWidget(self._layout.count() - 1, widget)
        row = {"kind": kind, "key": key, "widget": widget}
        row.update(extra)
        self._rows.append(row)
        if key is not None:
            self._by_key[key] = row
        return row

    def _enforce_cap(self):
        """블록/카드 위젯을 최근 200개로 제한한다(설계 4-4).

        세는 대상은 블록과 카드다. 구분선과 공지는 내용이 아니므로 상한의
        분모에 넣지 않지만, 앞쪽 블록이 접힐 때 함께 걷어낸다.
        """
        content = [r for r in self._rows if r["kind"] in ("block", "card")]
        over = len(content) - BLOCK_WIDGET_MAX
        if over <= 0:
            return
        dropped = 0
        kept = []
        for row in self._rows:
            if dropped < over and row["kind"] in ("block", "card", "separator", "user", "notice"):
                if row["kind"] in ("block", "card"):
                    dropped += 1
                self._drop_row(row)
                continue
            kept.append(row)
        self._rows = kept
        self._folded_n += dropped
        self._fold_label.setText(
            "이전 %d개 블록은 접었습니다. 전문은 세션 기록 파일에 있습니다." % self._folded_n
        )
        self._fold_label.setVisible(True)

    def _drop_row(self, row):
        """행 위젯을 떼어내고 장부에서 지운다."""
        if row["key"] is not None:
            self._by_key.pop(row["key"], None)
        widget = row["widget"]
        self._layout.removeWidget(widget)
        widget.setParent(None)
        widget.deleteLater()

    def _at_bottom(self):
        """스크롤이 이미 바닥에 있는가. 사용자가 위를 읽고 있으면 끌어내리지 않는다."""
        bar = self.verticalScrollBar()
        return bar.value() >= bar.maximum() - 4

    def _scroll_to_bottom(self):
        """바닥으로 내린다."""
        bar = self.verticalScrollBar()
        bar.setValue(bar.maximum())

    # ------------------------------------------------------------------
    # 조회 (검증 하네스가 읽는다)
    # ------------------------------------------------------------------

    def stats(self):
        """렌더 비용과 행 구성 요약."""
        times = sorted(self.render_ms)
        n = len(times)
        return {
            "rows": len(self._rows),
            "blocks": len([r for r in self._rows if r["kind"] == "block"]),
            "cards": len([r for r in self._rows if r["kind"] == "card"]),
            "folded": self._folded_n,
            "sync_calls": self.sync_calls,
            "updates": self.updates,
            "render_max_ms": times[-1] if n else 0.0,
            "render_mean_ms": (sum(times) / n) if n else 0.0,
            "render_p95_ms": times[int(n * 0.95)] if n else 0.0,
        }

    def row_texts(self):
        """행마다 (종류, 보이는 글) 목록. 검증 하네스가 읽는다.

        전사에 무엇이 실제로 쓰였는지를 밖에서 확인할 창구가 필요하다.
        위젯 종류가 섞여 있으므로 text() 가 있는 것만 읽는다.
        """
        out = []
        for row in self._rows:
            widget = row.get("widget")
            getter = getattr(widget, "text", None)
            try:
                text = getter() if callable(getter) else ""
            except Exception:  # noqa: BLE001 - 조회가 하네스를 멈추지 않게 한다
                text = ""
            out.append((row["kind"], text or ""))
        return out

    def card_widgets(self):
        """지금 살아 있는 도구 카드 위젯 목록. 추가 순서다."""
        return [r["widget"] for r in self._rows if r["kind"] == "card"]

    def block_views(self):
        """지금 살아 있는 텍스트/생각 블록의 (종류, 뷰) 목록."""
        return [
            (r.get("block_kind"), r.get("view"))
            for r in self._rows
            if r["kind"] == "block"
        ]

    def thinking_sections(self):
        """생각 블록의 접힘 영역 위젯 목록. 기본 접힘 확인에 쓴다."""
        return [
            r["widget"]
            for r in self._rows
            if r["kind"] == "block" and r.get("block_kind") == "thinking"
        ]

    def fold_notice_visible(self):
        """접힘 안내를 띄우기로 했는가(설계 4-4 상한 적용 여부)."""
        return not self._fold_label.isHidden()

    def rendered_text(self):
        """화면에 들어간 텍스트 블록만 이어 붙인 값. 중복 검사용이다."""
        parts = []
        for row in self._rows:
            if row["kind"] == "block" and row.get("block_kind") != "thinking":
                view = row.get("view")
                if view is not None:
                    parts.append(view.rendered_text())
        return "\n".join(parts)
