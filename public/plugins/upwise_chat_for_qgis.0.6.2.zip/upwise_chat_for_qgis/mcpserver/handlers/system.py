# --- UPWISE vendor header -------------------------------------------------
# Source: qgis_mcp_plugin 0.15.0 - Copyright (c) Nicolas Karasiak
# Upstream: https://github.com/nkarasiak/qgis-mcp, tag v0.15.0, taken 2026-10-11
# License: GPL-2.0-or-later (see LICENSE.upstream). UPWISE is a licensee here,
#   not the copyright holder, and redistributes under the same terms.
# Changed by UPWISE 2026-10-21 (GPLv2 section 2(a) notice): the execute_code
#   handler body no longer compiles or exec()s the caller's string; it refuses
#   by name instead - design 3-3 point 11.
# Below this block the file is upstream bytes except where marked "UPWISE".
# --- end UPWISE vendor header ---------------------------------------------
"""Handlers for QGIS itself: health, versions, message log, plugins, settings."""

import contextlib
import io
import os
import sys
import time
import traceback

try:
    from datetime import UTC, datetime
except ImportError:
    from datetime import datetime, timezone

    UTC = timezone.utc  # noqa: UP017  (fallback path: datetime.UTC unavailable pre-3.11)

from typing import ClassVar

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsMessageLog,
    QgsProject,
    QgsRasterLayer,
    QgsSettings,
    QgsVectorLayer,
)
from qgis.utils import active_plugins, available_plugins, pluginMetadata, reloadPlugin

from ..compat import MSG_INFO
from ..constants import plugin_version
from ..errors import CommandError
from ..registry import command


class _CodeDeadline(Exception):
    """Raised by the execute_code trace function once the budget is spent."""


class SystemHandlers:
    """QGIS health, versions, message log, plugin list and settings."""

    # Below the client's TIMEOUT_LONG (60s) for the same reason as
    # ProcessingHandlers._PROCESSING_TIMEOUT: the plugin gives up, and says why,
    # before the client abandons the request and the result is lost (#43).
    _CODE_TIMEOUT = 55
    _CODE_FILENAME = "<qgis_mcp execute_code>"

    def _deadline_tracer(self, deadline):
        """Trace function that raises _CodeDeadline once *deadline* has passed.

        Checked on every function call anywhere and on every line of the script's
        own frames (module level and the functions it defines), never on lines
        inside library code, so the cost is proportional to the script rather
        than to what it calls. A single blocking call (time.sleep, a GDAL warp)
        cannot be interrupted this way: it returns when it returns, and the
        check fires right after.
        """

        def trace(frame, event, arg):
            # Only before work starts (a call, a line), never on return: a script
            # that finishes late has finished, and saying it was cancelled would
            # send the caller looking for work that was actually done.
            if event in ("call", "line") and time.monotonic() >= deadline:
                raise _CodeDeadline
            return trace if frame.f_code.co_filename == self._CODE_FILENAME else None

        return trace

    @command
    def ping(self, **kwargs):
        return {"pong": True}

    @command
    def diagnose(self, **kwargs):
        """Run diagnostic checks and return health status."""
        checks = []
        overall = "healthy"

        def check(name, detail_of, fail_status="error", fail_overall="degraded"):
            """Append one check, degrading the overall status when it raises."""
            nonlocal overall
            try:
                checks.append({"name": name, "status": "ok", "detail": detail_of()})
            except Exception as e:
                checks.append({"name": name, "status": fail_status, "detail": str(e)})
                if overall != "error":
                    overall = fail_overall

        def qgis_info():
            from qgis.PyQt.QtCore import QT_VERSION_STR as qt_ver

            return {
                "qgis_version": Qgis.version(),
                "python_version": sys.version.split()[0],
                "qt_version": qt_ver,
            }

        def active_providers():
            registry = QgsApplication.processingRegistry()
            return [p.id() for p in registry.providers() if p.isActive()]

        def project_info():
            project = QgsProject.instance()
            return {
                "loaded": bool(project.fileName()),
                "path": project.fileName() or None,
                "layer_count": len(project.mapLayers()),
            }

        # 1. QGIS info. Its failure is fatal; every other check only degrades.
        check("qgis", qgis_info, fail_overall="error")

        # 2. Plugin version
        check("plugin_version", plugin_version)

        # 3. Connected clients
        client_count = len(self.clients)
        checks.append({"name": "connected_clients", "status": "ok", "detail": client_count})

        # 3b. Which MCP server versions have talked to this plugin. The client
        # adds its own comparison (version_match), but reporting it from the
        # plugin's side covers several clients on one QGIS, where only some are
        # out of date - and it is empty against a server older than 0.10.
        seen = sorted(self.client_versions)
        drifted = [v for v in seen if v != plugin_version()]
        detail = {"seen": seen, "plugin": plugin_version(), "drifted": drifted}
        # The update command each drifted client announced for itself. Absent
        # against a client too old to send one.
        fixes = {v: self.client_fixes[v] for v in drifted if v in self.client_fixes}
        if fixes:
            detail["fixes"] = fixes
        checks.append(
            {
                "name": "client_versions",
                "status": "mismatch" if drifted else "ok",
                "detail": detail,
            }
        )

        # 4. Processing providers
        check("processing_providers", active_providers, fail_status="degraded")

        # 5. Project status
        check("project", project_info)

        return {"status": overall, "checks": checks}

    @command
    def get_qgis_info(self, **kwargs):
        info = {
            "qgis_version": Qgis.version(),
            "profile_folder": QgsApplication.qgisSettingsDirPath(),
            "plugins_count": len(active_plugins),
            # Identity, so a client driving several QGIS windows can tell which one
            # answered rather than inferring it from the port. The pid is unique and
            # stable; the window title is what the user reads in the taskbar and
            # already carries the project name.
            "pid": os.getpid(),
        }
        if self.iface is not None:
            with contextlib.suppress(Exception):
                info["window_title"] = self.iface.mainWindow().windowTitle()
        return info

    @command
    def execute_code(self, code, timeout=None, **kwargs):
        # UPWISE change (design 3-3 point 11): upstream compiled the caller's
        # string and ran it with exec() under a deadline tracer. This build
        # never exposes the tool - exposure.py BLOCKED_COMMANDS holds
        # execute_code and server._dispatch refuses it by name before any
        # handler runs - so that body was unreachable, while Bandit B102 (Exec
        # used) is a blocking finding in the plugins.qgis.org upload scan. The
        # refusal below repeats the dispatcher's own wording through the
        # structured CommandError channel. The signature, the decorator and the
        # surrounding file are left alone so the upstream diff stays mechanical;
        # _CodeDeadline and _deadline_tracer are likewise left in place for the
        # reason stated under "Left alone on purpose" in VENDOR.md.
        raise CommandError("Command not exposed by this build: execute_code")

    _LEVEL_MAP: ClassVar[dict[int, str]] = {
        0: "info",
        1: "warning",
        2: "critical",
        3: "success",
        4: "none",
    }

    def _capture_message(self, message, tag, level, *_extra):
        """Capture a message log entry into the deque.

        QGIS 4.x messageReceivedWithFormat sends a 4th arg (StringFormat);
        *_extra absorbs it so the same handler works for both signals.
        """
        self._message_log.append(
            {
                "tag": tag,
                "message": message,
                "level": self._LEVEL_MAP.get(int(level), str(level)),
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

    @command
    def get_message_log(self, level=None, tag=None, limit=100, **kwargs):
        entries = list(self._message_log)
        entries.reverse()  # newest first
        if level:
            # An unknown level ("error") used to filter everything out silently.
            level = level.lower()
            if level not in self._LEVEL_MAP.values():
                raise CommandError(
                    f"Unknown level: {level!r}. Use one of {sorted(self._LEVEL_MAP.values())}"
                )
            entries = [e for e in entries if e["level"] == level]
        if tag:
            entries = [e for e in entries if e["tag"] == tag]
        total = len(entries)
        entries = entries[:limit]
        return {
            "messages": entries,
            "count": len(entries),
            "total": total,
            "truncated": total > len(entries),
        }

    @command
    def list_plugins(self, enabled_only=False, **kwargs):
        names = active_plugins if enabled_only else available_plugins
        result = [
            {
                "name": name,
                "enabled": name in active_plugins,
                "version": pluginMetadata(name, "version") or "",
                "path": pluginMetadata(name, "path") or "",
            }
            for name in sorted(names)
        ]
        return {"plugins": result, "count": len(result)}

    @command
    def get_plugin_info(self, plugin_name, **kwargs):
        if plugin_name not in available_plugins and plugin_name not in active_plugins:
            raise CommandError(f"Plugin not found: {plugin_name}")
        return {
            "name": plugin_name,
            "enabled": plugin_name in active_plugins,
            "version": pluginMetadata(plugin_name, "version") or "",
            "description": pluginMetadata(plugin_name, "description") or "",
            "author": pluginMetadata(plugin_name, "author") or "",
            "path": pluginMetadata(plugin_name, "path") or "",
        }

    @command
    def reload_plugin(self, plugin_name, **kwargs):
        if plugin_name == "qgis_mcp_plugin":
            raise CommandError("Cannot reload MCP plugin (would break the connection)")
        if plugin_name not in active_plugins:
            raise CommandError(f"Plugin not active: {plugin_name}")
        started = reloadPlugin(plugin_name)
        # A plugin whose code no longer loads is dropped from active_plugins
        # (QGIS 4 also returns False); its error only reaches the message bar.
        if started is False or plugin_name not in active_plugins:
            raise CommandError(
                f"Plugin {plugin_name} failed to start after reload; see the QGIS message log"
            )
        return {"reloaded": plugin_name, "ok": True}

    @command
    def get_setting(self, key, **kwargs):
        settings = QgsSettings()
        value = settings.value(key)
        return {
            "key": key,
            "value": value,
            "exists": settings.contains(key),
        }

    @command
    def set_setting(self, key, value, **kwargs):
        settings = QgsSettings()
        settings.setValue(key, value)
        return {"ok": True, "key": key}
