# --- UPWISE vendor header -------------------------------------------------
# Source: qgis_mcp_plugin 0.15.0 - Copyright (c) Nicolas Karasiak
# Upstream: https://github.com/nkarasiak/qgis-mcp, tag v0.15.0, taken 2026-10-11
# License: GPL-2.0-or-later (see LICENSE.upstream). UPWISE is a licensee here,
#   not the copyright holder, and redistributes under the same terms.
# Not changed by UPWISE: strip this block and the file is upstream byte for
#   byte. VENDOR.md records both digests.
# --- end UPWISE vendor header ---------------------------------------------
"""Handlers for the project: load/save, CRS, variables, bookmarks, map themes."""

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsExpressionContextUtils,
    QgsMessageLog,
    QgsProject,
    QgsRectangle,
)

from ..compat import MSG_INFO
from ..errors import CommandError
from ..registry import command


def _project_error(project):
    """QGIS's reason for the last failed read/write, as a message suffix."""
    error = project.error()
    return f": {error}" if error else ""


class ProjectHandlers:
    """The current project: files, CRS, variables, bookmarks, map themes."""

    @command
    def get_project_info(self, **kwargs):
        project = QgsProject.instance()

        info = {
            "filename": project.fileName(),
            "title": project.title(),
            "layer_count": len(project.mapLayers()),
            "crs": project.crs().authid(),
            "layers": [],
        }

        layers = list(project.mapLayers().values())
        for layer in layers[:10]:
            layer_info = {
                "id": layer.id(),
                "name": layer.name(),
                "type": self._get_layer_type(layer),
                "visible": layer.isValid() and self._is_visible(project, layer.id()),
            }
            info["layers"].append(layer_info)
        # Only the first 10 are listed; layer_count has the real total.
        info["layers_truncated"] = len(layers) > len(info["layers"])

        return info

    @command
    def save_project(self, path=None, **kwargs):
        project = QgsProject.instance()

        if not path and not project.fileName():
            raise CommandError("No project path specified and no current project path")

        save_path = path or project.fileName()
        if project.write(save_path):
            QgsMessageLog.logMessage(f"Project saved: {save_path}", self.LOG_TAG, MSG_INFO)
            return {"saved": save_path}
        else:
            raise CommandError(f"Failed to save project to {save_path}{_project_error(project)}")

    @command
    def load_project(self, path, **kwargs):
        project = QgsProject.instance()
        ok, unavailable = self._read_project(path)
        if ok:
            self.iface.mapCanvas().refresh()
            QgsMessageLog.logMessage(f"Project loaded: {path}", self.LOG_TAG, MSG_INFO)
            response = {"loaded": path, "layer_count": len(project.mapLayers())}
            if unavailable:
                response["unavailable_layers"] = unavailable
            return response
        else:
            raise CommandError(f"Failed to load project from {path}{_project_error(project)}")

    @command
    def create_new_project(self, path, **kwargs):
        # File > New, not project.clear(): clear() skips the defaults File > New
        # applies, leaving no CRS and ellipsoid NONE so every later measurement
        # was planimetric. It also only ran for a saved project, so an unsaved
        # one's layers carried over into the "empty" project.
        if not self.iface.newProject(False):
            raise CommandError("QGIS did not create a new project")
        project = QgsProject.instance()
        project.setFileName(path)
        self.iface.mapCanvas().refresh()
        if project.write():
            QgsMessageLog.logMessage(f"Project created: {path}", self.LOG_TAG, MSG_INFO)
            return {
                "created": f"Project created and saved successfully at: {path}",
                "layer_count": len(project.mapLayers()),
                "crs": project.crs().authid(),
                "ellipsoid": project.ellipsoid(),
            }
        else:
            raise CommandError(f"Failed to save project to {path}{_project_error(project)}")

    @command
    def get_project_variables(self, **kwargs):
        scope = QgsExpressionContextUtils.projectScope(QgsProject.instance())
        variables = {}
        for name in scope.variableNames():
            variables[name] = self._convert_attribute(scope.variable(name))
        return {"variables": variables}

    @command
    def set_project_variable(self, key, value, **kwargs):
        QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(), key, value)
        return {"ok": True, "key": key, "value": value}

    @command
    def set_project_crs(self, crs, **kwargs):
        """Set the project CRS."""
        new_crs = QgsCoordinateReferenceSystem(crs)
        if not new_crs.isValid():
            raise CommandError(f"Invalid CRS: {crs}")
        QgsProject.instance().setCrs(new_crs)
        return {"ok": True, "crs": new_crs.authid(), "description": new_crs.description()}

    @command
    def get_bookmarks(self, **kwargs):
        """Get spatial bookmarks from the project."""
        bm = QgsProject.instance().bookmarkManager()
        bookmarks = []
        for b in bm.bookmarks():
            extent = b.extent()
            bookmarks.append(
                {
                    "id": b.id(),
                    "name": b.name(),
                    "group": b.group(),
                    "extent": {
                        "xmin": extent.xMinimum(),
                        "ymin": extent.yMinimum(),
                        "xmax": extent.xMaximum(),
                        "ymax": extent.yMaximum(),
                    },
                    "crs": extent.crs().authid() if extent.crs().isValid() else None,
                }
            )
        return {"bookmarks": bookmarks, "count": len(bookmarks)}

    @command
    def add_bookmark(self, name, xmin, ymin, xmax, ymax, crs=None, group="", **kwargs):
        """Add a spatial bookmark; the extent is in *crs*, else the project CRS."""
        from qgis.core import QgsBookmark, QgsReferencedRectangle

        # EPSG:4326 used to be assumed, so projected coordinates without a crs
        # made a bookmark off the globe. The project CRS is what every other
        # extent tool defaults to.
        if crs:
            crs_obj = QgsCoordinateReferenceSystem(crs)
            if not crs_obj.isValid():
                raise CommandError(f"Invalid CRS: {crs}")
        else:
            crs_obj = QgsProject.instance().crs()
        extent = QgsReferencedRectangle(QgsRectangle(xmin, ymin, xmax, ymax), crs_obj)
        bookmark = QgsBookmark()
        bookmark.setName(name)
        bookmark.setGroup(group)
        bookmark.setExtent(extent)
        result = QgsProject.instance().bookmarkManager().addBookmark(bookmark)
        # addBookmark returns (id, success) tuple in QGIS 3.x+
        bookmark_id = result[0] if isinstance(result, (list, tuple)) else result
        if isinstance(result, (list, tuple)) and not result[1]:
            raise CommandError(f"QGIS did not add bookmark '{name}'")
        return {"ok": True, "id": bookmark_id, "name": name, "crs": crs_obj.authid()}

    @command
    def remove_bookmark(self, bookmark_id, **kwargs):
        """Remove a spatial bookmark by ID."""
        bm = QgsProject.instance().bookmarkManager()
        if not bm.removeBookmark(bookmark_id):
            raise CommandError(f"Bookmark not found: {bookmark_id}")
        return {"ok": True, "id": bookmark_id}

    @command
    def get_map_themes(self, **kwargs):
        """Get map themes (visibility presets)."""
        collection = QgsProject.instance().mapThemeCollection()
        themes = collection.mapThemes()
        result = []
        for name in themes:
            layer_ids = collection.mapThemeVisibleLayerIds(name)
            result.append(
                {
                    "name": name,
                    "visible_layer_count": len(layer_ids),
                    "visible_layer_ids": layer_ids,
                }
            )
        return {"themes": result, "count": len(result)}

    @command
    def add_map_theme(self, name, **kwargs):
        """Create a map theme from the current layer visibility state."""
        from qgis.core import QgsMapThemeCollection

        collection = QgsProject.instance().mapThemeCollection()
        root = QgsProject.instance().layerTreeRoot()
        model = self.iface.layerTreeView().layerTreeModel()
        record = QgsMapThemeCollection.createThemeFromCurrentState(root, model)
        if collection.hasMapTheme(name):
            collection.update(name, record)
            return {"ok": True, "name": name, "action": "updated"}
        else:
            collection.insert(name, record)
            return {"ok": True, "name": name, "action": "created"}

    @command
    def remove_map_theme(self, name, **kwargs):
        """Remove a map theme."""
        collection = QgsProject.instance().mapThemeCollection()
        if not collection.hasMapTheme(name):
            raise CommandError(f"Map theme not found: {name}")
        collection.removeMapTheme(name)
        return {"ok": True, "name": name}

    @command
    def apply_map_theme(self, name, **kwargs):
        """Apply a map theme (restore its layer visibility state)."""
        collection = QgsProject.instance().mapThemeCollection()
        if not collection.hasMapTheme(name):
            raise CommandError(f"Map theme not found: {name}")
        root = QgsProject.instance().layerTreeRoot()
        model = self.iface.layerTreeView().layerTreeModel()
        collection.applyTheme(name, root, model)
        self.iface.mapCanvas().refresh()
        return {"ok": True, "name": name}
