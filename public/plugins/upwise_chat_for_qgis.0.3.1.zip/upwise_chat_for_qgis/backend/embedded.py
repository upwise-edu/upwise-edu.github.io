"""내장 QGIS 소켓 서버의 수명주기 (0.3.0, 설계 docs/5 3-2·5-3).

Copyright (c) 2026 UPWISE. GPL-2.0-or-later.

무엇을 하나
    `mcpserver/` 의 소켓 서버를 띄우고 내리고, 세션 토큰을 내고, bind 후
    회수한 실포트를 들고 있는다. 상류 `plugin.py` 의 해당 부분을 가져오지
    않고 새로 쓴 이유는 그쪽이 **우리 제품의 정책이 아니라 상류의 UI** 라서다
    (툴바 액션·Run MCP 버튼·포트 스핀박스·아이콘 배지, 설계 3-2). 우리 독이
    그 자리이고, UI 가 없으니 더 짧다.

여기 없는 것
    독 배선·전제조건 문구·`--mcp-config` 조립은 **S10c 의 다른 파일**이 한다
    (`plugin.py`·`backend/posture.py`·`ui/`). 이 모듈은 상태와 자체 점검만
    들고 있고 UI 를 모른다.

자체 점검 (0.3.0 S10c, 설계 5-4 결정 D-B6 (b))
    0.2.x 는 "연결됐는가" 를 `qgis-connect-check` **스킬**에 물었다 - 유료
    1턴이고, 그 스킬은 남의 플러그인 버전을 조회해 3갈래로 보고했다. 내장
    서버는 우리 것이므로 플러그인이 **직접** 안다: `self_check()` 가 서버
    핸들러를 불러 포트·버전·레이어 수를 돌려준다. 모델 턴 0, 유료 토큰 0,
    결정적이다.

    **자기 소켓에 접속하지 않는다**(설계 함정 1). 서버는 GUI 스레드의
    `QTimer` 로 응답하므로 같은 스레드에서 블로킹 connect/recv 를 하면
    응답할 타이머가 그 스레드에 묶여 **교착**한다. 핸들러 직접 호출이
    소켓을 타지 않는 유일한 길이다.

토큰
    플러그인 적재마다 새로 난다. `UPWISE_QGIS_TOKEN` 으로 이 프로세스 환경에
    둔다 - 상류가 쓰는 `QGIS_MCP_TOKEN` 이 아니다. 같은 QGIS 프로세스에
    사용자의 상류 플러그인이 있으면 그쪽이 `QGIS_MCP_TOKEN` 을 매 명령마다
    다시 읽으므로, 그 이름을 쓰면 우리가 남의 서버 인증을 켜 버리고 그쪽
    uvx 피어가 토큰을 몰라 끊긴다(mcpserver/VENDOR.md 수정 10).

    **토큰의 한계를 과장하지 않는다.** 토큰은 `--mcp-config` 의 per-server env
    로 설정 파일에 평문으로 간다. 같은 사용자로 도는 프로세스에 대해서는
    경계가 아니다 - 상류도 같은 말을 한다. 토큰이 막는 것은 (a) 다른 사용자,
    (b) 포트를 훑는 비표적 접속이다. 같은 사용자 경로를 좁히는 것은 토큰이
    아니라 **노출 집합 축소와 서버측 거절**이다(`mcpserver/exposure.py`).

포트
    기본은 0(ephemeral)이고 bind 후 실포트를 회수한다. 9876 을 기본값으로
    쓰지 않는 이유는 `SO_EXCLUSIVEADDRUSE` 로 둘이 못 잡아서다 - 우리가 먼저
    잡으면 사용자의 Run MCP 가 실패하고, 사용자 눈에는 우리 플러그인이 남의
    기능을 깬 것으로 보인다(설계 함정 4). 고급 사용자를 위해 QgsSettings 키로
    고정할 수 있게는 두었다.
"""

import os
import secrets

from qgis.core import QgsMessageLog, QgsSettings

from ..mcpserver.compat import MSG_CRITICAL, MSG_INFO
from ..mcpserver.constants import SETTINGS_PREFIX
from ..mcpserver.server import TOKEN_ENV, QgisMCPServer

LOG_TAG = "UPWISE Chat"

# 호스트는 고정이다. 비loopback 은 서버가 거절하고(상류 유지분), 애초에
# 내장 서버를 네트워크에 낼 이유가 없다.
HOST = "127.0.0.1"

# 포트 고정용 고급 설정 키. 기본값 0 은 ephemeral 이다. 독에 노출하지 않는다 -
# 바꿔야 하는 사용자는 터미널에서 내장 서버에 붙으려는 경우뿐이고 그것은
# 선택 항목이다(설계 5-3).
PORT_SETTING_KEY = "%s/port" % SETTINGS_PREFIX

# 세션 토큰 길이(바이트). token_urlsafe 는 이것을 base64url 로 늘린다.
TOKEN_BYTES = 32


class EmbeddedServer:
    """내장 소켓 서버 하나의 수명주기.

    플러그인 인스턴스마다 하나다. 서버 객체를 둘 만들어도 재진입 가드는
    프로세스 전역이므로(VENDOR.md 수정 7) 디스패치가 겹치지 않는다.
    """

    def __init__(self, iface=None, on_clients_changed=None):
        """상태만 잡는다. 소켓은 `start()` 에서 연다.

        Args:
            iface: QGIS iface. 핸들러가 캔버스를 만질 때 쓴다.
            on_clients_changed: 클라이언트 수가 바뀔 때 부를 콜백.
        """
        self.iface = iface
        self.on_clients_changed = on_clients_changed
        self.server = None
        self.token = ""
        self.start_error = None

    # ------------------------------------------------------------- 상태 조회

    @property
    def running(self):
        """소켓이 열려 있고 타이머가 도는가."""
        return bool(self.server is not None and self.server.running)

    @property
    def port(self):
        """bind 후 회수한 실포트. 안 떴으면 0."""
        return int(self.server.port) if self.running else 0

    def bridge_env(self):
        """브리지에 넘길 per-server env (설계 4-3).

        조립은 S10c 의 `posture` 가 한다. 여기서는 **우리가 아는 값만** 돌려
        준다 - 로그 경로와 자산 경로는 플러그인 프로필을 아는 쪽이 채운다.

        Returns:
            dict: 호스트·포트·토큰. 서버가 안 떴으면 빈 dict - 뜨지 못할
                설정을 적으면 `status=failed` 가 사유를 흐린다(설계 4-3).
        """
        if not self.running:
            return {}
        return {
            "UPWISE_QGIS_HOST": HOST,
            "UPWISE_QGIS_PORT": str(self.port),
            TOKEN_ENV: self.token,
        }

    # ------------------------------------------------------------- 자체 점검

    def self_check(self):
        """내장 서버에 직접 물어 한 줄 보고를 만든다 (설계 5-4 (b)·8-3 (j)).

        소켓을 타지 않는다. 서버 객체의 `diagnose` 핸들러를 **그대로 부른다** -
        `@command` 로 등재된 메서드이고 소켓 경로와 같은 코드다. 그래서
        "점검은 통과하는데 모델 호출은 실패" 같은 갈림이 생기지 않는다.

        디스패치 가드를 존중한다. 재진입 가드가 켜져 있으면(다른 호출이 핸들러
        안에서 이벤트 루프를 펌프하는 중) 점검을 **건너뛴다**. 끼어들면
        상류가 자기 가드로 막으려 했던 교차 디스패치를 우리가 만든다
        (설계 2-5·함정 2).

        Returns:
            dict: state 는 "OK"·"BUSY"·"DOWN"·"ERROR" 중 하나.
                text 는 독에 그대로 띄우는 한 줄. detail 은 진단 로그용이고
                **토큰 값은 들어가지 않는다**(on/off 만).
        """
        if not self.running:
            return {
                "state": "DOWN",
                "text": "내장 QGIS 서버가 꺼져 있습니다: %s" % (
                    self.start_error or "사유 미기록"),
                "detail": {"running": False, "why": self.start_error or ""},
            }

        # 가드 조회 자체가 예외를 내면 점검이 아니라 버그다 - 그 경우도
        # 보고로 끝낸다(점검이 QGIS 를 멈추게 하지 않는다).
        try:
            busy = bool(self.server._in_dispatch)  # noqa: SLF001 - 상류 공개 속성
        except Exception as exc:  # noqa: BLE001
            return {"state": "ERROR",
                    "text": "내장 서버 상태를 읽지 못했습니다: %r" % (exc,),
                    "detail": {"running": True, "why": repr(exc)}}
        if busy:
            return {
                "state": "BUSY",
                "text": "내장 QGIS 서버가 작업 중입니다. 잠시 뒤 다시 누르세요.",
                "detail": {"running": True, "in_dispatch": True,
                           "port": self.port},
            }

        try:
            result = self.server.diagnose()
        except Exception as exc:  # noqa: BLE001 - 핸들러 예외도 보고로 끝낸다
            QgsMessageLog.logMessage(
                "self check raised: %r" % (exc,), LOG_TAG, MSG_CRITICAL)
            return {"state": "ERROR",
                    "text": "내장 서버 점검이 실패했습니다: %r" % (exc,),
                    "detail": {"running": True, "why": repr(exc)}}

        checks = {}
        for entry in (result or {}).get("checks") or ():
            if isinstance(entry, dict) and isinstance(entry.get("name"), str):
                checks[entry["name"]] = entry.get("detail")
        qgis_version = (checks.get("qgis") or {}).get("qgis_version") \
            if isinstance(checks.get("qgis"), dict) else None
        layer_count = (checks.get("project") or {}).get("layer_count") \
            if isinstance(checks.get("project"), dict) else None
        plugin_version = checks.get("plugin_version")
        detail = {
            "running": True,
            "port": self.port,
            "token": "on" if self.token else "off",
            "status": (result or {}).get("status"),
            "qgis_version": qgis_version,
            "plugin_version": plugin_version,
            "layer_count": layer_count,
            "clients": checks.get("connected_clients"),
        }
        text = ("내장 QGIS 서버 정상 - 포트 %d, 토큰 on, 플러그인 %s, "
                "QGIS %s, 레이어 %s개" % (
                    self.port, plugin_version or "unknown",
                    qgis_version or "unknown",
                    layer_count if layer_count is not None else "?"))
        return {"state": "OK", "text": text, "detail": detail}

    # --------------------------------------------------------------- 수명주기

    def start(self):
        """토큰을 내고 소켓을 연다.

        Returns:
            bool: 떴으면 True. 실패 사유는 `start_error` 에 남는다.
        """
        if self.running:
            return True
        self.start_error = None

        # 적재마다 새 토큰이다. 재사용하면 이전 세션의 설정 파일에 남은 토큰이
        # 계속 유효해진다.
        self.token = secrets.token_urlsafe(TOKEN_BYTES)
        os.environ[TOKEN_ENV] = self.token

        port = self._configured_port()
        self.server = QgisMCPServer(
            host=HOST, port=port, iface=self.iface,
            on_clients_changed=self.on_clients_changed)
        try:
            started = self.server.start()
        except Exception as exc:  # noqa: BLE001 - 적재가 예외로 멈추면 독이 안 뜬다
            self.start_error = "embedded server raised on start: %r" % (exc,)
            QgsMessageLog.logMessage(self.start_error, LOG_TAG, MSG_CRITICAL)
            self._forget()
            return False

        if not started:
            # 서버가 사유를 적어 둔다(포트 점유·토큰 부재·비loopback).
            self.start_error = self.server.start_error or "embedded server did not start"
            QgsMessageLog.logMessage(self.start_error, LOG_TAG, MSG_CRITICAL)
            self._forget()
            return False

        QgsMessageLog.logMessage(
            "embedded QGIS server on %s:%d, token auth on" % (HOST, self.port),
            LOG_TAG, MSG_INFO)
        return True

    def stop(self):
        """소켓·타이머·체크포인트 임시폴더를 내리고 토큰을 지운다.

        `server.stop()` 이 소켓·타이머·클라이언트·체크포인트 임시폴더를 전부
        정리한다(상류 코드 그대로). 우리가 더 하는 것은 환경에서 토큰을 빼는
        것뿐이다 - 남겨 두면 다음 적재의 서버가 뜨기 전에 낡은 토큰이 유효한
        것처럼 보인다.
        """
        if self.server is not None:
            try:
                self.server.stop()
            except Exception as exc:  # noqa: BLE001 - unload 가 예외로 멈추면 안 된다
                QgsMessageLog.logMessage(
                    "embedded server raised on stop: %r" % (exc,), LOG_TAG, MSG_CRITICAL)
        self._forget()

    def _forget(self):
        """서버 참조와 토큰을 버린다."""
        self.server = None
        self.token = ""
        os.environ.pop(TOKEN_ENV, None)

    @staticmethod
    def _configured_port():
        """고급 설정에 고정 포트가 있으면 그것, 없으면 0(ephemeral).

        QgsSettings 접두사는 우리 것이다(`upwise_chat/embedded_server`).
        상류의 `qgis_mcp/port` 를 읽지도 쓰지도 않는다 - 그쪽은 사용자가
        설치한 플러그인의 설정이다(VENDOR.md 수정 1).
        """
        try:
            value = QgsSettings().value(PORT_SETTING_KEY, 0, type=int)
        except Exception:  # noqa: BLE001 - 설정 읽기 실패가 기동을 막지 않는다
            return 0
        # 1024 미만은 특권 포트다. 0 과 유효 범위만 받는다.
        if value and 1024 <= int(value) <= 65535:
            return int(value)
        return 0
