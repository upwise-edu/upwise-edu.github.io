"""비모달 키 설정 패널 (0.2.1, 설계 docs/2 8 "S9c 키 설정 UI").

왜 독 안의 패널인가
    1순위가 독 안의 **비모달 설정 패널**이다(설계 8). 모달은 금지다 - 모달
    팝업이 자동화를 정지시킨다(설계 3-5). `QFileDialog` 도 쓰지 않는다. 그래서
    이 패널은 떠 있는 동안에도 QGIS 조작이 되고, 지도에서 좌표를 보며 키를
    넣을 수 있다. QGIS 옵션 페이지는 2순위이고 이번 범위가 아니다.

패널이 보여 주는 것 (설계 8 필드 목록)
    제공자별 키 입력(마스킹 표시) / 저장 / 삭제
    "저장 위치와 평문 여부" 안내 한 줄
    사용자 엔드포인트 템플릿(고급, 접힘)

키 값을 다루는 규칙
    * 입력 위젯은 `QLineEdit.Password` 다. 화면에 글자가 남지 않는다.
    * **저장 성공 즉시 입력 칸을 비운다.** 패널이 화면 공유나 캡처에 들어갈
      수 있고, 위젯에 남은 값은 지울 이유가 없는 사본이다.
    * 상태 표시는 `keystore.mask()` 를 쓴다. 값의 어느 글자도 내보내지 않는다
      (끝 네 자리를 보여 주는 흔한 UX 를 일부러 쓰지 않는다).
    * 이 모듈은 **값을 로그에 넘기지 않는다.** 밖으로 내는 시그널
      `keys_changed(int)` 의 인자는 설정된 제공자 **수**다.

저장은 keystore 가 한다
    `QgsSettings` 쓰기와 `sync()` 는 `backend/keystore` 하나가 맡는다(설계
    5-3 단서 2: sync 를 안 부르면 수집 서버가 빈 값을 읽는다). 패널은 결과
    문구만 그린다.

고급 칸의 범위 (좁혔다 - 보고 대상)
    여기서 넣는 것은 **엔드포인트 기본 URL 오버라이드 하나**다
    (`collect_server.SETTING_ENDPOINT_OVERRIDE`, 서버가 이미 읽는 값).
    설계 4-2 가 적은 "레지스트리에 사용자 데이터셋 항목을 병합" 은 서버
    기능이고 0.2.1 범위가 아니다. 이 칸은 기관 프록시/대역 테스트용이다.

금지 API(설계 3-5): QMessageBox, QDialog.exec(), QProgressDialog, QFileDialog,
중첩 이벤트 루프. Qt import 는 전부 qgis.PyQt 셰임 경로로 한다(설계 7-4).

설계 정본: docs/2.collect_feature_design_v1.md 5-2, 5-3, 8
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..backend import keystore
from .chat_view import CollapsibleSection

# 패널 머리말.
PANEL_HEADER = "공공 API 키"

# "저장 위치와 평문 여부" 안내 한 줄(설계 8 필드 목록의 항목). 사실만 적는다 -
# 평문이라는 것을 숨기지 않는 것이 설계 5-2 의 조건이다.
STORAGE_NOTICE = (
    "키는 이 PC 의 QGIS 설정 파일(QGIS3.ini)에 평문으로 저장됩니다. "
    "사본은 그 파일 하나뿐이고, 채팅과 전사와 로그에는 들어가지 않습니다."
)

# 키를 채팅에 붙여 넣지 말라는 한 줄. 붙여 넣는 순간 모델 제공자 서버와 CLI
# 자체 세션 저장소에 남고 우리가 지울 수 없다(S9a 실측, 설계 5-1 L2/L3).
PASTE_WARNING = (
    "키를 채팅 입력창에 붙여 넣지 마세요. 한 번 들어가면 지울 수 없는 곳에 "
    "남습니다. 수집은 이 칸에 넣은 키로만 돌아갑니다."
)

# 제공자 행의 상태 문구.
STATE_SET = "저장됨 %s"
STATE_UNSET = "키가 설정되지 않았습니다"
STATE_NOT_NEEDED = "키가 필요하지 않습니다"

# 고급 칸.
ADVANCED_TITLE = "고급: 엔드포인트 기본 주소 바꾸기"
ADVANCED_NOTICE = (
    "레지스트리의 기본 주소 대신 쓸 주소입니다. 기관 프록시 대역이나 시험용 "
    "서버가 아니면 비워 두세요. 모든 데이터셋 요청에 함께 적용됩니다."
)
ADVANCED_SET = "설정됨: %s"
ADVANCED_UNSET = "설정되지 않았습니다(레지스트리 기본 주소를 씁니다)"

# 입력 칸 placeholder.
KEY_PLACEHOLDER = "키를 붙여 넣고 [저장] 을 누르세요"
URL_PLACEHOLDER = "https://..."


class KeyPanel(QFrame):
    """제공자별 키를 넣고 지우는 비모달 패널.

    시그널 하나만 낸다.

        keys_changed(int)  저장/삭제가 성공했다. 인자는 **설정된 제공자 수**다.
            키 값은 시그널에도 담지 않는다.
    """

    keys_changed = pyqtSignal(int)

    def __init__(self, parent=None, providers=None, settings=None):
        """행을 만들고 현재 상태를 읽어 그린다. 기본은 숨은 상태다.

        Args:
            parent: 부모 위젯.
            providers: 제공자 목록. None 이면 레지스트리에서 읽는다.
                하네스가 행 구성을 고정하는 주입점이다.
            settings: QSettings 호환 객체. None 이면 QgsSettings.
                하네스가 임시 INI 로 실제 Qt 저장/sync 를 재게 하는 주입점이다.
        """
        super().__init__(parent)
        self.setObjectName("UpwiseChatKeyPanel")
        self.setFrameShape(QFrame.StyledPanel)

        self._settings = settings
        self._providers = tuple(providers) if providers is not None \
            else keystore.load_providers()
        self._rows = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(4)

        head = QLabel(PANEL_HEADER, self)
        head.setObjectName("UpwiseChatKeyPanelHeader")
        layout.addWidget(head)

        self._notice = QLabel(STORAGE_NOTICE, self)
        self._notice.setObjectName("UpwiseChatKeyPanelNotice")
        self._notice.setWordWrap(True)
        self._notice.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self._notice)

        self._warning = QLabel(PASTE_WARNING, self)
        self._warning.setObjectName("UpwiseChatKeyPanelWarning")
        self._warning.setWordWrap(True)
        layout.addWidget(self._warning)

        layout.addWidget(self._build_rows())

        # 마지막 동작의 결과 한 줄. 모달을 쓸 수 없으므로 결과를 여기 적는다.
        self._message = QLabel("", self)
        self._message.setObjectName("UpwiseChatKeyPanelMessage")
        self._message.setWordWrap(True)
        layout.addWidget(self._message)

        layout.addWidget(self._build_advanced())

        self.refresh()
        self.setVisible(False)

    # ------------------------------------------------------------------
    # 위젯 구성
    # ------------------------------------------------------------------

    def _build_rows(self):
        """제공자 행들. 그리드로 두어 라벨/칸/버튼이 세로로 맞는다."""
        holder = QWidget(self)
        grid = QGridLayout(holder)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(4)
        grid.setVerticalSpacing(2)

        for i, row in enumerate(self._providers):
            pid = row["id"]
            title = QLabel(row.get("title") or pid, holder)
            title.setWordWrap(True)
            # 발급 안내 주소는 툴팁에만 둔다. 패널에 링크 위젯을 더하지 않는다
            # (범위를 넓히지 않는다).
            tip = [row.get("key_setting") or ""]
            if row.get("signup"):
                tip.append("발급: " + row["signup"])
            title.setToolTip("\n".join(t for t in tip if t))
            grid.addWidget(title, i * 2, 0, 1, 3)

            field = QLineEdit(holder)
            field.setObjectName("UpwiseChatKeyField_" + pid)
            # 마스킹 표시. 입력 중에도 글자가 화면에 남지 않는다.
            field.setEchoMode(QLineEdit.Password)
            field.setPlaceholderText(KEY_PLACEHOLDER)
            field.setEnabled(bool(row.get("needs_key", True)))
            # Enter 로도 저장된다. 버튼을 찾아 누르게 하지 않는다.
            field.returnPressed.connect(
                lambda pid=pid: self.save_provider(pid))
            grid.addWidget(field, i * 2 + 1, 0)

            save = QPushButton("저장", holder)
            save.setObjectName("UpwiseChatKeySave_" + pid)
            save.setEnabled(bool(row.get("needs_key", True)))
            # clicked 는 bool 을 넘긴다. 기본값 인자로 삼킨다(S4 실측).
            save.clicked.connect(
                lambda _checked=False, pid=pid: self.save_provider(pid))
            grid.addWidget(save, i * 2 + 1, 1)

            drop = QPushButton("삭제", holder)
            drop.setObjectName("UpwiseChatKeyDelete_" + pid)
            drop.clicked.connect(
                lambda _checked=False, pid=pid: self.delete_provider(pid))
            grid.addWidget(drop, i * 2 + 1, 2)

            state = QLabel("", holder)
            state.setObjectName("UpwiseChatKeyState_" + pid)
            state.setWordWrap(True)
            grid.addWidget(state, i * 2 + 1, 3)

            self._rows[pid] = {"field": field, "save": save, "delete": drop,
                               "state": state, "meta": row}
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(3, 1)
        return holder

    def _build_advanced(self):
        """고급 칸. 기본 접힘이다(설계 8 "고급, 접힘")."""
        section = CollapsibleSection(ADVANCED_TITLE, self, expanded=False)
        self._advanced = section

        body = QWidget(section)
        layout = QVBoxLayout(body)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        note = QLabel(ADVANCED_NOTICE, body)
        note.setWordWrap(True)
        layout.addWidget(note)

        row = QWidget(body)
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        self._url_field = QLineEdit(row)
        self._url_field.setObjectName("UpwiseChatEndpointField")
        self._url_field.setPlaceholderText(URL_PLACEHOLDER)
        self._url_field.returnPressed.connect(self.save_endpoint)
        row_layout.addWidget(self._url_field, 1)
        self._url_save = QPushButton("저장", row)
        self._url_save.setObjectName("UpwiseChatEndpointSave")
        self._url_save.clicked.connect(lambda _checked=False: self.save_endpoint())
        row_layout.addWidget(self._url_save)
        self._url_delete = QPushButton("삭제", row)
        self._url_delete.setObjectName("UpwiseChatEndpointDelete")
        self._url_delete.clicked.connect(
            lambda _checked=False: self.delete_endpoint())
        row_layout.addWidget(self._url_delete)
        layout.addWidget(row)

        self._url_state = QLabel("", body)
        self._url_state.setWordWrap(True)
        layout.addWidget(self._url_state)

        section.add_body_widget(body)
        return section

    # ------------------------------------------------------------------
    # 동작
    # ------------------------------------------------------------------

    def save_provider(self, provider):
        """한 제공자의 키를 저장한다. 성공하면 입력 칸을 비운다.

        Returns:
            bool: 저장 성공 여부.
        """
        row = self._rows.get(provider)
        if row is None:
            return False
        ok, why = keystore.save_key(provider, row["field"].text(),
                                    settings=self._settings)
        if ok:
            # 위젯에 값을 남기지 않는다. 지울 이유가 없는 사본이다.
            row["field"].clear()
        self._message.setText("%s: %s" % (provider, why))
        self.refresh()
        if ok:
            self._emit_changed()
        return ok

    def delete_provider(self, provider):
        """한 제공자의 키를 지운다.

        Returns:
            bool: 삭제 성공 여부.
        """
        row = self._rows.get(provider)
        if row is None:
            return False
        ok, why = keystore.delete_key(provider, settings=self._settings)
        row["field"].clear()
        self._message.setText("%s: %s" % (provider, why))
        self.refresh()
        if ok:
            self._emit_changed()
        return ok

    def save_endpoint(self):
        """고급 칸의 엔드포인트 기본 주소를 저장한다.

        Returns:
            bool: 저장 성공 여부.
        """
        ok, why = keystore.save_endpoint_override(self._url_field.text(),
                                                  settings=self._settings)
        self._message.setText("엔드포인트: %s" % why)
        self.refresh()
        return ok

    def delete_endpoint(self):
        """고급 칸의 엔드포인트 기본 주소를 지운다.

        Returns:
            bool: 삭제 성공 여부.
        """
        ok, why = keystore.delete_endpoint_override(settings=self._settings)
        self._url_field.clear()
        self._message.setText("엔드포인트: %s" % why)
        self.refresh()
        return ok

    def refresh(self):
        """설정에서 지금 상태를 읽어 상태 문구를 다시 그린다.

        Returns:
            int: 키가 설정된 제공자 수.
        """
        configured = 0
        for pid, row in self._rows.items():
            if not row["meta"].get("needs_key", True):
                row["state"].setText(STATE_NOT_NEEDED)
                row["delete"].setEnabled(False)
                continue
            value = keystore.read_key(pid, settings=self._settings)
            if value:
                configured += 1
                row["state"].setText(STATE_SET % keystore.mask(value))
            else:
                row["state"].setText(STATE_UNSET)
            row["delete"].setEnabled(bool(value))
        override = keystore.read_endpoint_override(settings=self._settings)
        self._url_state.setText(ADVANCED_SET % override if override
                                else ADVANCED_UNSET)
        self._url_delete.setEnabled(bool(override))
        return configured

    def _emit_changed(self):
        """설정된 제공자 수를 실어 올린다. 키 값은 담지 않는다."""
        configured, _missing = keystore.key_state(self._providers,
                                                  settings=self._settings)
        self.keys_changed.emit(len(configured))

    # ------------------------------------------------------------------
    # 조회 (검증 하네스가 읽는다)
    # ------------------------------------------------------------------

    def providers(self):
        """패널이 띄운 제공자 id 들."""
        return tuple(row["id"] for row in self._providers)

    def field(self, provider):
        """제공자 입력 칸. 하네스가 키를 넣는다."""
        row = self._rows.get(provider)
        return row["field"] if row else None

    def state_text(self, provider):
        """제공자 행의 상태 문구."""
        row = self._rows.get(provider)
        return row["state"].text() if row else ""

    def message_text(self):
        """마지막 동작 결과 한 줄."""
        return self._message.text()

    def notice_text(self):
        """저장 위치/평문 안내 한 줄."""
        return self._notice.text()

    def warning_text(self):
        """채팅 붙여넣기 금지 한 줄."""
        return self._warning.text()

    def advanced_expanded(self):
        """고급 칸이 펴져 있는가. 기본은 접힘이다."""
        return self._advanced.is_expanded()

    def endpoint_state_text(self):
        """고급 칸의 상태 문구."""
        return self._url_state.text()

    def stats(self):
        """패널 상태 요약. **키 값이 들어가지 않는다.**"""
        echo_modes = {pid: int(row["field"].echoMode())
                      for pid, row in self._rows.items()}
        return {
            "key_panel_visible": not self.isHidden(),
            "key_panel_providers": list(self.providers()),
            "key_panel_states": {pid: self.state_text(pid)
                                 for pid in self._rows},
            "key_panel_echo_modes": echo_modes,
            "key_panel_field_texts_empty": all(
                not row["field"].text() for row in self._rows.values()),
            "key_panel_message": self.message_text(),
            "key_panel_advanced_expanded": self.advanced_expanded(),
            "key_panel_endpoint_state": self.endpoint_state_text(),
        }
